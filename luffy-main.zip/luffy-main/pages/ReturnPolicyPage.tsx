import React, { useEffect } from 'react';
import { NavLink } from 'react-router-dom';

const ReturnPolicyPage: React.FC = () => {
    useEffect(() => {
        window.scrollTo(0, 0);
    }, []);

    return (
        <div className="bg-white dark:bg-gray-900 py-12 md:py-16">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8">
                <div className="max-w-3xl mx-auto">
                    <header className="text-center mb-10">
                        <h1 className="text-4xl md:text-5xl font-serif font-bold text-brand-dark dark:text-brand-light">
                            Return & Refund Policy
                        </h1>
                        <p className="mt-4 text-lg text-gray-600 dark:text-gray-300">
                            Your satisfaction is our priority. If you're not completely happy with your purchase, we're here to help.
                        </p>
                    </header>

                    <div className="prose lg:prose-lg max-w-none text-gray-800 dark:text-gray-300 dark:prose-invert leading-relaxed space-y-8">
                        <section>
                            <h2 className="font-serif text-2xl font-bold text-brand-dark dark:text-brand-light">42-Hour Return Window</h2>
                            <p>
                                You have <strong>42 hours</strong> from the date of delivery to initiate a return for a full refund. Unfortunately, if 42 hours have gone by since your delivery, we cannot offer you a refund or exchange.
                            </p>
                        </section>

                        <section>
                            <h2 className="font-serif text-2xl font-bold text-brand-dark dark:text-brand-light">Eligibility for a Return</h2>
                            <p>To be eligible for a return, your item must meet the following criteria:</p>
                            <ul>
                                <li>The item must be unused, unopened, and in the same condition that you received it.</li>
                                <li>It must be in its original packaging.</li>
                                <li>Proof of purchase or order number is required.</li>
                            </ul>
                            <p className="p-4 bg-yellow-50 border-l-4 border-yellow-400 text-yellow-800 dark:bg-yellow-900/50 dark:text-yellow-300 rounded-md">
                                <strong>Please note:</strong> For hygiene and safety reasons, any product that has been opened or used cannot be returned.
                            </p>
                        </section>

                        <section>
                            <h2 className="font-serif text-2xl font-bold text-brand-dark dark:text-brand-light">How to Initiate a Return</h2>
                            <p>
                                To start the return process, please contact our customer support team within the 42-hour window. You can reach us via our{' '}
                                <NavLink to="/contact" className="text-brand-primary dark:text-brand-secondary hover:underline font-semibold">Contact Page</NavLink>.
                            </p>
                            <p>
                                In your message, please include your order number, the item(s) you wish to return, and the reason for the return. Our team will guide you through the next steps.
                            </p>
                        </section>
                        
                        <section>
                            <h2 className="font-serif text-2xl font-bold text-brand-dark dark:text-brand-light">Refunds</h2>
                            <p>
                                Once your return is received and inspected, we will send you an email to notify you that we have received your returned item. We will also notify you of the approval or rejection of your refund.
                            </p>
                            <p>
                                If you are approved, then your refund will be processed, and a credit will automatically be applied to your original method of payment (e.g., M-Pesa) within 5-7 business days.
                            </p>
                        </section>

                        <section>
                            <h2 className="font-serif text-2xl font-bold text-brand-dark dark:text-brand-light">Exchanges</h2>
                            <p>
                                We only replace items if they are defective or damaged upon arrival. If you receive a damaged item and need to exchange it for the same product, please contact us immediately upon delivery with photos of the damage.
                            </p>
                        </section>
                        
                        <section>
                            <h2 className="font-serif text-2xl font-bold text-brand-dark dark:text-brand-light">Questions?</h2>
                            <p>
                                If you have any questions about our Return Policy, please don't hesitate to{' '}
                                <NavLink to="/contact" className="text-brand-primary dark:text-brand-secondary hover:underline font-semibold">get in touch</NavLink>. We're always here to assist you.
                            </p>
                        </section>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default ReturnPolicyPage;
