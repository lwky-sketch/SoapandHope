import React, { useState, useEffect } from 'react';
import { useCart } from '../context/CartContext';
import { NavLink, useNavigate } from 'react-router-dom';

const LockClosedIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M16.5 10.5V6.75a4.5 4.5 0 00-9 0v3.75m-.75 11.25h10.5a2.25 2.25 0 002.25-2.25v-6.75a2.25 2.25 0 00-2.25-2.25H6.75a2.25 2.25 0 00-2.25 2.25v6.75a2.25 2.25 0 002.25 2.25z" />
  </svg>
);

const CheckoutPage: React.FC = () => {
    const {
        cartItems,
        cartTotal,
        isFreebieEarned,
        completePurchase,
        cartCount,
        applyPromoCode,
        removePromoCode,
        promoDiscount,
        finalTotal,
        promoError,
        appliedPromoCode 
    } = useCart();
    const [step, setStep] = useState(1);
    const [mpesaNumber, setMpesaNumber] = useState('');
    const [isProcessing, setIsProcessing] = useState(false);
    const [promoCodeInput, setPromoCodeInput] = useState('');
    const navigate = useNavigate();
    const originalTotal = cartItems.reduce((acc, item) => acc + item.price * item.quantity, 0);

    useEffect(() => {
        if (cartCount === 0 && step !== 3) {
            navigate('/products');
        }
        window.scrollTo(0, 0);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [cartCount, step]);
    
    const handleApplyPromo = (e: React.FormEvent) => {
        e.preventDefault();
        applyPromoCode(promoCodeInput);
    };

    const handlePlaceOrder = () => {
        // Basic validation for a Kenyan phone number
        if (!mpesaNumber.match(/^(?:254|0)?(7|1)\d{8}$/)) {
            alert("Please enter a valid Safaricom phone number (e.g., 0712345678 or 254712345678).");
            return;
        }
        setIsProcessing(true);
        // Simulate M-Pesa STK Push by waiting for a few seconds
        setTimeout(() => {
            console.log(`Simulating STK push to M-Pesa number: ${mpesaNumber}`);
            completePurchase();
            setIsProcessing(false);
            setStep(3); // Go to confirmation step
        }, 4000); // 4-second delay to simulate transaction
    }

    if (step === 3) {
        return (
            <div className="bg-white dark:bg-gray-900 text-center py-20">
                <h1 className="text-3xl font-bold font-serif text-green-600 mb-4">Payment Successful!</h1>
                <p className="text-gray-700 dark:text-gray-300 mb-8">Your order has been placed. A confirmation has been sent to your email.</p>
                <NavLink to="/" className="bg-brand-primary text-white font-bold py-3 px-6 rounded-md hover:bg-opacity-80 transition-colors">
                    Continue Shopping
                </NavLink>
            </div>
        );
    }
    
    return (
        <div className="bg-gray-50 dark:bg-gray-900 py-8 sm:py-12">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8">
                <h1 className="text-center text-4xl font-serif font-bold text-brand-dark dark:text-brand-light mb-8">Checkout</h1>
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
                    {/* Left Side: Form */}
                    <div className="bg-white dark:bg-gray-800 p-8 rounded-lg shadow-md">
                        <div className="flex mb-6">
                            <button onClick={() => !isProcessing && setStep(1)} disabled={isProcessing} className={`flex-1 pb-2 text-center font-semibold border-b-2 ${step === 1 ? 'border-brand-primary dark:border-brand-secondary text-brand-primary dark:text-brand-secondary' : 'border-gray-300 dark:border-gray-700 text-gray-500 dark:text-gray-400'} disabled:cursor-not-allowed`}>
                                1. Shipping
                            </button>
                            <button onClick={() => !isProcessing && setStep(2)} disabled={isProcessing} className={`flex-1 pb-2 text-center font-semibold border-b-2 ${step === 2 ? 'border-brand-primary dark:border-brand-secondary text-brand-primary dark:text-brand-secondary' : 'border-gray-300 dark:border-gray-700 text-gray-500 dark:text-gray-400'} disabled:cursor-not-allowed`}>
                                2. Payment
                            </button>
                        </div>

                        {step === 1 && (
                            <form onSubmit={(e) => {e.preventDefault(); setStep(2)}}>
                                <h2 className="text-xl font-bold mb-4 dark:text-white">Shipping Information</h2>
                                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                    <input type="text" placeholder="First Name" className="p-2 border rounded-md w-full dark:bg-gray-700 dark:border-gray-600 dark:text-gray-200" required />
                                    <input type="text" placeholder="Last Name" className="p-2 border rounded-md w-full dark:bg-gray-700 dark:border-gray-600 dark:text-gray-200" required />
                                    <input type="email" placeholder="Email" className="p-2 border rounded-md w-full sm:col-span-2 dark:bg-gray-700 dark:border-gray-600 dark:text-gray-200" required />
                                    <input type="text" placeholder="Address" className="p-2 border rounded-md w-full sm:col-span-2 dark:bg-gray-700 dark:border-gray-600 dark:text-gray-200" required />
                                    <input type="text" placeholder="City" className="p-2 border rounded-md w-full dark:bg-gray-700 dark:border-gray-600 dark:text-gray-200" required />
                                    <input type="text" placeholder="Postal Code" className="p-2 border rounded-md w-full dark:bg-gray-700 dark:border-gray-600 dark:text-gray-200" required />
                                </div>
                                <button type="submit" className="mt-6 w-full bg-brand-primary text-white font-bold py-3 rounded-md hover:bg-opacity-80">
                                    Continue to Payment
                                </button>
                            </form>
                        )}

                        {step === 2 && (
                            <div>
                                <h2 className="text-xl font-bold mb-4 dark:text-white">M-Pesa Payment</h2>
                                <p className="text-gray-600 dark:text-gray-300 mb-4">Enter your M-Pesa phone number. You will receive a prompt on your phone to enter your PIN and complete the transaction.</p>
                                <div className="space-y-4">
                                    <input 
                                        type="tel" 
                                        value={mpesaNumber}
                                        onChange={(e) => setMpesaNumber(e.target.value)}
                                        placeholder="e.g. 0712345678" 
                                        className="p-3 border rounded-md w-full text-lg dark:bg-gray-700 dark:border-gray-600 dark:text-gray-200" 
                                        required 
                                        disabled={isProcessing}
                                    />
                                    <button 
                                        onClick={handlePlaceOrder} 
                                        disabled={isProcessing || !mpesaNumber} 
                                        className="w-full bg-green-500 text-white font-bold py-3 rounded-md hover:bg-green-600 disabled:bg-gray-400 disabled:cursor-not-allowed flex items-center justify-center transition-colors"
                                    >
                                        {isProcessing ? (
                                            <>
                                                <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                                                </svg>
                                                <span>Processing Payment...</span>
                                            </>
                                        ) : (
                                            `Pay Ksh ${finalTotal.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} with M-Pesa`
                                        )}
                                    </button>
                                </div>
                            </div>
                        )}
                    </div>
                    {/* Right Side: Order Summary */}
                    <div className="bg-white dark:bg-gray-800 p-8 rounded-lg shadow-md h-fit lg:sticky top-24">
                        <h2 className="text-xl font-bold mb-4 border-b dark:border-gray-700 pb-4 dark:text-white">Order Summary</h2>
                        <div className="space-y-3 max-h-60 overflow-y-auto pr-2">
                            {cartItems.map(item => (
                                <div key={item.id} className="flex justify-between items-center text-sm">
                                    <div className="flex items-center gap-2">
                                        <img src={item.images[0]} alt={item.name} className="w-12 h-12 rounded-md object-cover" />
                                        <div>
                                            <p className="font-semibold dark:text-white">{item.name}</p>
                                            <p className="text-gray-500 dark:text-gray-400">Qty: {item.quantity}</p>
                                        </div>
                                    </div>
                                    <p className="dark:text-white">Ksh {(item.price * item.quantity).toLocaleString()}</p>
                                </div>
                            ))}
                        </div>
                        <div className="mt-4 pt-4 border-t dark:border-gray-700">
                            <form onSubmit={handleApplyPromo} className="flex gap-2 mb-2">
                                <input 
                                    type="text"
                                    value={promoCodeInput}
                                    onChange={(e) => setPromoCodeInput(e.target.value)}
                                    placeholder="Promo Code"
                                    className="w-full px-3 py-2 text-sm border rounded-md focus:outline-none focus:ring-2 focus:ring-brand-primary disabled:bg-gray-100 dark:bg-gray-700 dark:border-gray-600 dark:text-gray-200"
                                    disabled={!!appliedPromoCode}
                                />
                                <button type="submit" className="bg-brand-dark hover:bg-opacity-80 text-white font-bold px-4 rounded-md transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed" disabled={!!appliedPromoCode}>
                                    Apply
                                </button>
                            </form>
                            {promoError && <p className="text-red-500 text-xs mt-1">{promoError}</p>}
                            {appliedPromoCode && (
                                <div className="bg-green-100 text-green-800 p-2 rounded-md mt-2 text-sm flex justify-between items-center">
                                    <span>Promo code <strong>'{appliedPromoCode}'</strong> applied!</span>
                                    <button onClick={() => { removePromoCode(); setPromoCodeInput(''); }} className="font-bold text-lg leading-none p-1">&times;</button>
                                </div>
                            )}
                        </div>
                        <div className="mt-4 pt-4 border-t dark:border-gray-700 space-y-2">
                             <div className="flex justify-between text-gray-600 dark:text-gray-300">
                                <span>Subtotal</span>
                                <span>Ksh {originalTotal.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                            </div>
                            {isFreebieEarned && (
                                 <div className="flex justify-between text-green-600 font-semibold">
                                    <span>Loyalty Discount</span>
                                    <span>-Ksh {(originalTotal - cartTotal).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                                </div>
                            )}
                            {promoDiscount > 0 && (
                                 <div className="flex justify-between text-green-600 font-semibold">
                                    <span>Promo Discount (6.7%)</span>
                                    <span>-Ksh {promoDiscount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                                </div>
                            )}
                            <div className="flex justify-between font-bold text-xl text-brand-dark dark:text-brand-light pt-2">
                                <span>Total</span>
                                <span>Ksh {finalTotal.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                            </div>
                        </div>
                        <div className="mt-6 pt-6 border-t border-gray-200 dark:border-gray-700">
                            <div className="flex flex-wrap items-center justify-center gap-x-6 gap-y-3 text-gray-500 dark:text-gray-400">
                                <div className="flex items-center gap-2 text-sm">
                                    <LockClosedIcon className="w-5 h-5 text-gray-400" />
                                    <span>Secure Checkout</span>
                                </div>
                                <div className="flex items-center gap-2 text-sm">
                                    <img src="https://upload.wikimedia.org/wikipedia/commons/1/15/M-PESA_LOGO-01.svg" alt="M-Pesa Logo" className="h-4"/>
                                    <span>M-Pesa Verified</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default CheckoutPage;