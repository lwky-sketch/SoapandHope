import React, { useEffect, useState } from 'react';
import LoyaltyTracker from '../components/LoyaltyTracker';
import { NavLink } from 'react-router-dom';

const ShoppingCartIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 3h1.386c.51 0 .955.343 1.087.835l.383 1.437M7.5 14.25a3 3 0 00-3 3h15.75m-12.75-3h11.218c.51 0 .962-.328 1.093-.829l3.48-6.962c.13-.26-.056-.569-.34-.569H7.13" />
    </svg>
);

const ChartBarIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M3 13.125C3 12.504 3.504 12 4.125 12h2.25c.621 0 1.125.504 1.125 1.125v6.75C7.5 20.496 6.996 21 6.375 21h-2.25A1.125 1.125 0 013 19.875v-6.75zM9.75 8.625c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125v11.25c0 .621-.504 1.125-1.125 1.125h-2.25a1.125 1.125 0 01-1.125-1.125V8.625zM16.5 4.125c0-.621.504-1.125 1.125-1.125h2.25C20.496 3 21 3.504 21 4.125v15.75c0 .621-.504 1.125-1.125 1.125h-2.25a1.125 1.125 0 01-1.125-1.125V4.125z" />
    </svg>
);

const GiftIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M21 11.25v8.25a1.5 1.5 0 01-1.5 1.5H5.25a1.5 1.5 0 01-1.5-1.5v-8.25M12 4.875A2.625 2.625 0 109.375 7.5H12m0-2.625V7.5m0-2.625A2.625 2.625 0 1114.625 7.5H12m0 0V21m-8.625-9.75h18c.621 0 1.125-.504 1.125-1.125v-1.5c0-.621-.504-1.125-1.125-1.125h-18c-.621 0-1.125.504-1.125 1.125v1.5c0 .621.504 1.125 1.125 1.125z" />
    </svg>
);

const SparklesIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M9.813 15.904L9 18.75l-.813-2.846a4.5 4.5 0 00-3.09-3.09L2.25 12l2.846-.813a4.5 4.5 0 003.09-3.09L9 5.25l.813 2.846a4.5 4.5 0 003.09 3.09L15.75 12l-2.846.813a4.5 4.5 0 00-3.09 3.09zM18.259 8.715L18 9.75l-.259-1.035a3.375 3.375 0 00-2.455-2.456L14.25 6l1.036-.259a3.375 3.375 0 002.455-2.456L18 2.25l.259 1.035a3.375 3.375 0 002.456 2.456L21.75 6l-1.035.259a3.375 3.375 0 00-2.456 2.456zM16.898 20.562L16.25 21.75l-.648-1.188a2.25 2.25 0 01-1.4-1.4L13.125 18l1.188-.648a2.25 2.25 0 011.4 1.4l.648 1.188z" />
    </svg>
);

const TagIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M9.568 3H5.25A2.25 2.25 0 003 5.25v4.318c0 .597.237 1.17.659 1.591l9.581 9.581c.699.699 1.78.872 2.607.33a18.095 18.095 0 005.223-5.223c.542-.827.369-1.908-.33-2.607L11.16 3.66A2.25 2.25 0 009.568 3z" />
        <path strokeLinecap="round" strokeLinejoin="round" d="M6 6h.008v.008H6V6z" />
    </svg>
);

const InfinityIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M13.5 4.5L21 12m0 0l-7.5 7.5M21 12H3" transform="scale(0.8) translate(2, 0)" />
        <path strokeLinecap="round" strokeLinejoin="round" d="M10.5 19.5L3 12m0 0l7.5-7.5M3 12h18" transform="scale(0.8) translate(2, 0) rotate(180 12 12)" />
    </svg>
);

const ShieldCheckIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75L11.25 15 15 9.75m-3-7.036A11.959 11.959 0 013.598 6 11.99 11.99 0 003 9.749c0 5.592 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.31-.21-2.571-.598-3.751h-.152c-3.196 0-6.1-1.248-8.25-3.286z" />
    </svg>
);

const ChevronDownIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 8.25l-7.5 7.5-7.5-7.5" />
    </svg>
);

const faqItems = [
    {
      question: "Do I need an account to participate?",
      answer: "Yes, your purchase history is tied to your account. This is how we automatically track your progress towards your free product. Creating an account is quick, free, and also makes checkout faster for future orders."
    },
    {
      question: "How do I know which item will be free?",
      answer: "When you have 6 purchases on your record and you place your 7th order, we will automatically make the most expensive item in that cart free. You'll see the discount applied in your cart and at checkout."
    },
    {
      question: "What happens if I return an item from an order?",
      answer: "If you return all items from a qualifying purchase, that purchase will be removed from your loyalty count. If you make a partial return, the purchase still counts towards your goal."
    },
    {
      question: "Does the free product count as a purchase towards my next reward?",
      answer: "The transaction where you claim your free product counts as your 7th purchase, and it resets your loyalty tracker. Your next purchase will be the first of the next cycle of six."
    },
    {
      question: "Can I combine the loyalty reward with other discounts or promo codes?",
      answer: "Yes! Your loyalty reward can be combined with other site-wide promotions or discount codes, giving you even more savings."
    }
];

const FAQItem: React.FC<{ item: typeof faqItems[0]; isOpen: boolean; onClick: () => void }> = ({ item, isOpen, onClick }) => (
    <div className="border-b border-gray-200 dark:border-gray-700">
        <button
            className="w-full flex justify-between items-center text-left py-4"
            onClick={onClick}
            aria-expanded={isOpen}
        >
            <span className="text-lg font-medium text-brand-dark dark:text-white">{item.question}</span>
            <ChevronDownIcon className={`w-6 h-6 text-brand-primary transition-transform ${isOpen ? 'rotate-180' : ''}`} />
        </button>
        <div className={`grid transition-all duration-300 ease-in-out ${isOpen ? 'grid-rows-[1fr] opacity-100' : 'grid-rows-[0fr] opacity-0'}`}>
            <div className="overflow-hidden">
                <p className="pb-4 text-gray-600 dark:text-gray-300">
                    {item.answer}
                </p>
            </div>
        </div>
    </div>
);


const LoyaltyPage: React.FC = () => {
    const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(null);
    useEffect(() => {
      window.scrollTo(0, 0);
    }, []);

    return (
        <div className="bg-gray-50 dark:bg-gray-900">
            {/* Hero Section */}
            <div className="relative bg-brand-primary/10 dark:bg-brand-dark pt-20 pb-16 text-center">
                 <img src="https://picsum.photos/seed/loyaltybg/1920/500" alt="Abstract background" className="absolute inset-0 w-full h-full object-cover opacity-10"/>
                <div className="relative container mx-auto px-4 sm:px-6 lg:px-8">
                    <h1 className="text-4xl md:text-5xl font-serif font-bold text-brand-dark dark:text-brand-light">Our Loyalty Program</h1>
                    <p className="text-lg text-gray-700 dark:text-gray-300 mt-4 max-w-2xl mx-auto">Quality you can trust, loyalty you can feel.</p>
                </div>
            </div>

            <div className="container mx-auto px-4 sm:px-6 lg:px-8 pb-16 md:pb-24">
                
                <div className="max-w-4xl mx-auto -mt-12">
                    <LoyaltyTracker />
                </div>

                {/* How it Works */}
                <div className="mt-16 md:mt-24">
                    <h2 className="text-3xl font-bold font-serif text-brand-dark dark:text-brand-light mb-10 text-center">A Simple Path to Free Products</h2>
                    <div className="grid md:grid-cols-3 gap-8 text-center max-w-5xl mx-auto">
                        <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md border-t-4 border-brand-secondary">
                            <div className="bg-brand-secondary text-brand-dark rounded-full h-16 w-16 flex items-center justify-center text-2xl font-bold mb-4 mx-auto">1</div>
                            <ShoppingCartIcon className="w-10 h-10 text-brand-primary mx-auto mb-3" />
                            <h3 className="font-semibold text-xl mb-2 dark:text-white">Shop Your Favorites</h3>
                            <p className="text-gray-600 dark:text-gray-300">Each time you complete a purchase, you're one step closer. No cards to punch, no codes to enter—it's all automatic.</p>
                        </div>
                         <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md border-t-4 border-brand-secondary">
                            <div className="bg-brand-secondary text-brand-dark rounded-full h-16 w-16 flex items-center justify-center text-2xl font-bold mb-4 mx-auto">2</div>
                            <ChartBarIcon className="w-10 h-10 text-brand-primary mx-auto mb-3" />
                            <h3 className="font-semibold text-xl mb-2 dark:text-white">Track Your Progress</h3>
                            <p className="text-gray-600 dark:text-gray-300">After six purchases, your reward is unlocked! Check your progress anytime on this page or in your cart.</p>
                        </div>
                         <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md border-t-4 border-brand-secondary">
                            <div className="bg-brand-secondary text-brand-dark rounded-full h-16 w-16 flex items-center justify-center text-2xl font-bold mb-4 mx-auto">3</div>
                            <GiftIcon className="w-10 h-10 text-brand-primary mx-auto mb-3" />
                            <h3 className="font-semibold text-xl mb-2 dark:text-white">Claim Your Reward</h3>
                            <p className="text-gray-600 dark:text-gray-300">On your 7th purchase, we'll automatically make the most expensive item in your cart absolutely FREE!</p>
                        </div>
                    </div>
                </div>

                {/* Benefits Section */}
                <div className="mt-16 md:mt-24">
                    <h2 className="text-3xl font-bold font-serif text-brand-dark dark:text-brand-light mb-10 text-center">Rewarding You is Our Pleasure</h2>
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 max-w-6xl mx-auto">
                        <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow flex items-start gap-4">
                            <SparklesIcon className="w-8 h-8 text-brand-secondary flex-shrink-0 mt-1" />
                            <div>
                                <h4 className="font-bold text-lg dark:text-white">Fully Automatic</h4>
                                <p className="text-sm text-gray-600 dark:text-gray-300">Your progress is tracked with your account. No extra steps needed.</p>
                            </div>
                        </div>
                        <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow flex items-start gap-4">
                            <TagIcon className="w-8 h-8 text-brand-secondary flex-shrink-0 mt-1" />
                            <div>
                                <h4 className="font-bold text-lg dark:text-white">High-Value Reward</h4>
                                <p className="text-sm text-gray-600 dark:text-gray-300">Get a full-sized product for free, not just a sample or a small discount.</p>
                            </div>
                        </div>
                        <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow flex items-start gap-4">
                            <InfinityIcon className="w-8 h-8 text-brand-secondary flex-shrink-0 mt-1" />
                            <div>
                                <h4 className="font-bold text-lg dark:text-white">No Expiration</h4>
                                <p className="text-sm text-gray-600 dark:text-gray-300">Your purchases never expire. Take as long as you need to earn your reward.</p>
                            </div>
                        </div>
                        <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow flex items-start gap-4">
                            <ShieldCheckIcon className="w-8 h-8 text-brand-secondary flex-shrink-0 mt-1" />
                            <div>
                                <h4 className="font-bold text-lg dark:text-white">Simple & Transparent</h4>
                                <p className="text-sm text-gray-600 dark:text-gray-300">No hidden fees, no complicated rules. Just a simple thank you.</p>
                            </div>
                        </div>
                    </div>
                </div>

                {/* FAQ Section */}
                <div className="mt-16 md:mt-24">
                    <h2 className="text-3xl font-serif font-bold text-brand-dark dark:text-brand-light text-center mb-10">Common Questions</h2>
                    <div className="max-w-3xl mx-auto bg-white dark:bg-gray-800 rounded-lg shadow-lg p-4 sm:p-6">
                        {faqItems.map((item, index) => (
                           <FAQItem 
                                key={index}
                                item={item}
                                isOpen={openFaqIndex === index}
                                onClick={() => setOpenFaqIndex(openFaqIndex === index ? null : index)}
                           />
                        ))}
                    </div>
                </div>

                {/* Rules Section */}
                <div className="mt-16 md:mt-24 max-w-3xl mx-auto text-center">
                    <h3 className="text-xl font-semibold text-brand-dark dark:text-white mb-4">The Fine Print</h3>
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                        The loyalty reward applies to the highest-priced item in your cart during your seventh transaction. Shipping fees and taxes may still apply. The loyalty count resets to zero after a reward is redeemed. Program terms are subject to change.
                    </p>
                </div>
                
                {/* CTA Section */}
                <div className="text-center mt-16 md:mt-24 bg-white dark:bg-gray-800 p-10 rounded-lg shadow-lg max-w-4xl mx-auto">
                     <h2 className="text-2xl font-bold font-serif text-brand-dark dark:text-brand-light mb-4">Ready to Earn Your First Reward?</h2>
                     <p className="text-gray-600 dark:text-gray-300 mb-6">Every purchase brings you closer to a free product. Find your new favorite today.</p>
                     <NavLink to="/products" className="bg-brand-primary text-white font-bold py-3 px-10 rounded-md hover:bg-opacity-80 transition-all transform hover:scale-105 inline-block text-lg">
                        Start Shopping Now
                    </NavLink>
                </div>
            </div>
        </div>
    );
};

export default LoyaltyPage;
