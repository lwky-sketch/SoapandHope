import React, { useEffect } from 'react';
import { NavLink } from 'react-router-dom';

// --- ICONS ---
const SeedlingIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 2a2.25 2.25 0 00-2.25 2.25c0 1.223.99 2.22 2.214 2.25h.072c1.223-.03 2.214-1.027 2.214-2.25A2.25 2.25 0 0012 2z" />
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 22.5c-4.63 0-8.44-3.5-8.95-8.08a.75.75 0 01.6- .82h16.7a.75.75 0 01.6.82C20.44 19 16.63 22.5 12 22.5z" />
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 9.75a.75.75 0 01.75.75v1.5a.75.75 0 01-1.5 0v-1.5a.75.75 0 01.75-.75zM12 12.75a.75.75 0 01.75.75v3a.75.75 0 01-1.5 0v-3a.75.75 0 01.75-.75z" />
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 6.75A2.25 2.25 0 009.75 9v.375c0 .621.504 1.125 1.125 1.125h2.25c.621 0 1.125-.504 1.125-1.125V9A2.25 2.25 0 0012 6.75z" />
    </svg>
);
const FlaskIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M14.25 6.087c0-1.723-.97-3.232-2.435-4.008a1.986 1.986 0 00-2.63 0C7.72 2.855 6.75 4.364 6.75 6.087v5.332c0 .942.225 1.84.632 2.645l3.368 6.736a.75.75 0 001.332 0l3.368-6.736c.407-.805.632-1.703.632-2.645V6.087z" />
        <path strokeLinecap="round" strokeLinejoin="round" d="M10.5 12.75h3" />
    </svg>
);
const UsersIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M18 18.72a9.094 9.094 0 003.741-.479 3 3 0 00-4.682-2.72m-7.284 2.72a3 3 0 01-4.682-2.72 9.094 9.094 0 013.741-.479m-.479 2.72a9.094 9.094 0 00-3.741.479m5.474 0a3 3 0 01-5.474 0m5.474 0a4.5 4.5 0 11-5.474 0M12 12.75a4.5 4.5 0 110-9 4.5 4.5 0 010 9z" />
    </svg>
);
const TelescopeIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M12.75 3.03v.568c0 .334.148.65.405.864l1.068.89c.442.369.535 1.01.216 1.49l-.51.766a2.25 2.25 0 01-1.161.886l-.143.048a1.107 1.107 0 00-.57 1.664l.143.258a1.107 1.107 0 001.664.57l.143-.048a2.25 2.25 0 011.161.886l.51.766c.319.48.126 1.121-.216 1.49l-1.068.89a1.125 1.125 0 00-.405.864v.568m-6 0v-.568c0-.334-.148-.65-.405-.864l-1.068-.89c-.442-.369-.535-1.01-.216-1.49l.51-.766a2.25 2.25 0 011.161-.886l.143-.048a1.107 1.107 0 00.57-1.664l-.143-.258a1.107 1.107 0 00-1.664-.57l-.143.048a2.25 2.25 0 01-1.161-.886l-.51-.766c-.319-.48-.126-1.121.216-1.49l1.068-.89a1.125 1.125 0 00.405-.864v-.568m6 0a1.5 1.5 0 00-1.5-1.5h-3a1.5 1.5 0 00-1.5 1.5m6 0v.568m0 18v-.568m0 .568a1.5 1.5 0 01-1.5 1.5h-3a1.5 1.5 0 01-1.5-1.5m0 .568v-.568m0 12.568c0 .334.148.65.405.864l1.068.89c.442.369.535 1.01.216 1.49l-.51.766a2.25 2.25 0 01-1.161.886l-.143.048a1.107 1.107 0 00-.57 1.664l.143.258a1.107 1.107 0 001.664.57l.143-.048a2.25 2.25 0 011.161.886l.51.766c.319.48.126 1.121-.216 1.49l-1.068.89a1.125 1.125 0 00-.405.864m-6-12.568c0 .334-.148.65-.405.864l-1.068.89c-.442-.369-.535-1.01-.216-1.49l.51-.766a2.25 2.25 0 011.161-.886l.143-.048a1.107 1.107 0 00.57-1.664l-.143-.258a1.107 1.107 0 00-1.664-.57l-.143.048a2.25 2.25 0 01-1.161-.886l-.51-.766c-.319-.48-.126-1.121.216-1.49l1.068-.89a1.125 1.125 0 00.405-.864" />
    </svg>
);
const EyeIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}><path strokeLinecap="round" strokeLinejoin="round" d="M2.036 12.322a1.012 1.012 0 010-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.432 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178z" /><path strokeLinecap="round" strokeLinejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /></svg>
);
const GlobeAltIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}><path strokeLinecap="round" strokeLinejoin="round" d="M12 21a9 9 0 100-18 9 9 0 000 18z" /><path strokeLinecap="round" strokeLinejoin="round" d="M19.5 12a7.5 7.5 0 11-15 0 7.5 7.5 0 0115 0z" /></svg>
);
const HeartIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}><path strokeLinecap="round" strokeLinejoin="round" d="M21 8.25c0-2.485-2.099-4.5-4.688-4.5-1.935 0-3.597 1.126-4.312 2.733-.715-1.607-2.377-2.733-4.313-2.733C5.1 3.75 3 5.765 3 8.25c0 7.22 9 12 9 12s9-4.78 9-12z" /></svg>
);
const PawIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}><path strokeLinecap="round" strokeLinejoin="round" d="M20.828 7.643A8.966 8.966 0 0012 4.5c-2.06 0-4.012.68-5.594 1.892.23.633.39 1.3.497 2.002.107.702.164 1.42.164 2.155 0 2.29-.49 4.45-1.378 6.425a1 1 0 01-1.6-.825c.04-.32.063-.645.063-.975 0-1.886-.54-3.66-1.5-5.25a1 1 0 00-1.74-.03C3.6 13.06 3 15.45 3 18c0 .54.02 1.07.06 1.59.03.43.34.78.75.82.41.04.78-.23.89-.63.09-.33.15-.67.15-1.03 0-1.3.2-2.5.6-3.6a1 1 0 011.83.8c-.3 1-.5 2-.6 3.1a1 1 0 001.99.2c.1-.8.3-1.6.6-2.3.3-.8.7-1.5 1.2-2.1a1 1 0 011.62.75c-.1.35-.2.7-.3 1.1-.1.3-.2.6-.2.9a1 1 0 002 0c0-.6.1-1.2.3-1.8.2-.6.4-1.2.7-1.7a1 1 0 011.65.65c-.1.3-.2.6-.3.9-.1.3-.1.7-.1 1a1 1 0 002 0c0-.6.1-1.2.2-1.7.1-.6.3-1.1.5-1.6a1 1 0 011.75.45c0 2.8-2.6 5.1-5.8 5.1-1.2 0-2.3-.3-3.3-.9a1 1 0 01-.4-1.35c.4-.8.7-1.7.8-2.6.2-1 .2-2 .2-3.1 0-.7-.05-1.4-.15-2.1-.1-.7-.26-1.3-.5-1.9z" /></svg>
);
const GiftIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}><path strokeLinecap="round" strokeLinejoin="round" d="M12 3v18m-6-9h12" /><path strokeLinecap="round" strokeLinejoin="round" d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /><path strokeLinecap="round" strokeLinejoin="round" d="M9.75 8.25A2.25 2.25 0 0112 6v0a2.25 2.25 0 012.25 2.25v0" /></svg>
);


const AboutPage: React.FC = () => {
    useEffect(() => {
      window.scrollTo(0, 0);
    }, []);

    const journeySteps = [
        {
            icon: SeedlingIcon,
            year: "2021",
            title: "The Idea",
            description: "Frustrated by harsh chemicals, our founder sketches the first plant-based formulas in a small notebook, envisioning a future of effective, eco-friendly cleaning."
        },
        {
            icon: FlaskIcon,
            year: "2022",
            title: "First Formula",
            description: "After months of kitchen experiments, our signature lavender hand soap is perfected. It's gentle, effective, and smells incredible."
        },
        {
            icon: UsersIcon,
            year: "2023",
            title: "Community Launch",
            description: "Soap & Hope officially launches online, quickly building a community of conscious consumers who believe in a cleaner home and a greener planet."
        },
        {
            icon: TelescopeIcon,
            year: "2024+",
            title: "Our Future",
            description: "We're expanding our refill programs, exploring new product lines, and aiming to become a certified B-Corp, furthering our commitment to positive impact."
        }
    ];
    
    const values = [
        {
            icon: EyeIcon,
            title: "Radical Transparency",
            description: "You have a right to know what's in your home. We list every ingredient and its purpose, clearly and simply."
        },
        {
            icon: SeedlingIcon,
            title: "Uncompromising Quality",
            description: "We use high-quality, plant-derived ingredients and natural essential oils. Effective, powerful, and always gentle."
        },
        {
            icon: GlobeAltIcon,
            title: "Sustainable by Design",
            description: "From biodegradable formulas to recyclable packaging and refill options, we consider our planet in every decision we make."
        },
        {
            icon: HeartIcon,
            title: "Community Focused",
            description: "We're more than a brand; we're a community. We listen to your feedback and donate a portion of our profits to environmental causes."
        }
    ];

    return (
        <div className="bg-white dark:bg-gray-900">
            {/* Hero Section */}
            <div className="relative bg-brand-light dark:bg-gray-800 py-20 lg:py-32">
                 <img src="https://picsum.photos/seed/aboutus/1920/600" alt="Lush green field with water drops" className="absolute inset-0 w-full h-full object-cover opacity-10 dark:opacity-5"/>
                <div className="relative container mx-auto px-4 sm:px-6 lg:px-8 text-center">
                    <h1 className="text-4xl lg:text-5xl font-serif font-bold text-brand-dark dark:text-brand-light">Clean Homes, Clear Conscience.</h1>
                    <p className="mt-4 text-lg text-gray-700 dark:text-gray-300 max-w-3xl mx-auto">Premium cleaning products that care for your home while rewarding your trust. Join thousands of families who choose Soap & Hope for quality and loyalty.</p>
                </div>
            </div>

            {/* Our Journey Section */}
            <div className="py-16 lg:py-24">
                <div className="container mx-auto px-4 sm:px-6 lg:px-8">
                    <h2 className="text-3xl font-serif font-bold text-brand-dark dark:text-brand-light text-center mb-16">Our Journey</h2>
                    <div className="relative max-w-4xl mx-auto">
                        <div className="absolute left-4 md:left-1/2 top-0 h-full w-0.5 bg-gray-200 dark:bg-gray-700 transform md:-translate-x-1/2"></div>
                        <div className="space-y-16">
                            {journeySteps.map((step, index) => (
                                <div key={index} className="relative flex items-start">
                                    <div className="flex-shrink-0 absolute left-4 md:left-1/2 top-1 w-8 h-8 bg-brand-secondary rounded-full transform -translate-x-1/2 flex items-center justify-center ring-4 ring-white dark:ring-gray-900 z-10">
                                        <step.icon className="w-5 h-5 text-brand-dark"/>
                                    </div>
                                    <div className={`w-full md:w-1/2 ${index % 2 === 0 ? 'md:pr-12' : 'md:pl-12 md:ml-auto'} pl-12 md:pl-0`}>
                                        <div className={`${index % 2 === 0 ? 'md:text-right' : 'md:text-left'}`}>
                                            <p className="text-brand-primary dark:text-brand-secondary font-bold">{step.year}</p>
                                            <h3 className="text-xl font-semibold text-brand-dark dark:text-white mt-1">{step.title}</h3>
                                            <p className="text-gray-600 dark:text-gray-300 mt-2">{step.description}</p>
                                        </div>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            </div>
            
            {/* Core Values Section */}
            <div className="bg-brand-light dark:bg-gray-800 py-16 lg:py-24">
                <div className="container mx-auto px-4 sm:px-6 lg:px-8">
                    <h2 className="text-3xl font-serif font-bold text-brand-dark dark:text-brand-light text-center mb-12">Our Core Values</h2>
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
                        {values.map(value => (
                            <div key={value.title} className="text-center p-6 bg-white dark:bg-gray-900 rounded-lg shadow-sm">
                                <div className="mx-auto w-16 h-16 rounded-full bg-brand-secondary/50 flex items-center justify-center mb-4">
                                     <value.icon className="w-8 h-8 text-brand-dark" />
                                </div>
                                <h3 className="text-xl font-semibold text-brand-dark dark:text-white mb-2">{value.title}</h3>
                                <p className="text-gray-600 dark:text-gray-300">{value.description}</p>
                            </div>
                        ))}
                    </div>
                </div>
            </div>

            {/* Ingredients Philosophy */}
            <div className="py-16 lg:py-24">
                 <div className="container mx-auto px-4 sm:px-6 lg:px-8">
                     <div className="grid lg:grid-cols-2 gap-12 items-center">
                         <div className="order-2 lg:order-1">
                             <h2 className="text-3xl font-serif font-bold text-brand-dark dark:text-brand-light">Purely Powerful Ingredients</h2>
                             <p className="mt-4 text-gray-700 dark:text-gray-300 leading-relaxed">
                                 We believe what we leave out is just as important as what we put in. Our philosophy is simple: create the most effective cleaning products using only the best that nature has to offer.
                             </p>
                             <ul className="mt-6 space-y-4 text-gray-700 dark:text-gray-300">
                                 <li className="flex items-start"><span className="text-brand-secondary font-bold mr-3 mt-1">&#10003;</span><span><strong>Plant-Based & Biodegradable:</strong> Tough on stains, gentle on the earth. Our formulas break down naturally, leaving no trace.</span></li>
                                 <li className="flex items-start"><span className="text-brand-secondary font-bold mr-3 mt-1">&#10003;</span><span><strong>Cruelty-Free Always:</strong> We love our furry friends. None of our products or ingredients are ever tested on animals.</span></li>
                                 <li className="flex items-start"><span className="text-brand-secondary font-bold mr-3 mt-1">&#10003;</span><span><strong>Ethically Sourced:</strong> We partner with suppliers who share our commitment to sustainability and fair labor practices.</span></li>
                             </ul>
                         </div>
                         <div className="order-1 lg:order-2">
                            <img src="https://picsum.photos/seed/ingredients/600/500" alt="Natural ingredients like lemons and herbs" className="rounded-lg shadow-lg w-full h-full object-cover" />
                         </div>
                     </div>
                 </div>
            </div>

            {/* Why Choose Us Section */}
            <div className="bg-brand-light dark:bg-gray-800 py-16 lg:py-24">
                <div className="container mx-auto px-4 sm:px-6 lg:px-8">
                    <h2 className="text-3xl font-serif font-bold text-brand-dark dark:text-brand-light text-center mb-12">Why Choose Us?</h2>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto text-center">
                        <div className="bg-white dark:bg-gray-900 p-8 rounded-lg shadow-md border-t-4 border-brand-secondary">
                            <GlobeAltIcon className="w-12 h-12 text-brand-primary dark:text-brand-secondary mx-auto mb-4" />
                            <h3 className="text-xl font-semibold text-brand-dark dark:text-white mb-2">Planet-First Formulas</h3>
                            <p className="text-gray-600 dark:text-gray-300">Our biodegradable, plant-based ingredients are tough on grime but gentle on the planet.</p>
                        </div>
                        <div className="bg-white dark:bg-gray-900 p-8 rounded-lg shadow-md border-t-4 border-brand-secondary">
                            <PawIcon className="w-12 h-12 text-brand-primary dark:text-brand-secondary mx-auto mb-4" />
                            <h3 className="text-xl font-semibold text-brand-dark dark:text-white mb-2">Always Cruelty-Free</h3>
                            <p className="text-gray-600 dark:text-gray-300">We are proudly Leaping Bunny certified. No animal testing, ever. It's that simple.</p>
                        </div>
                        <div className="bg-white dark:bg-gray-900 p-8 rounded-lg shadow-md border-t-4 border-brand-secondary">
                            <GiftIcon className="w-12 h-12 text-brand-primary dark:text-brand-secondary mx-auto mb-4" />
                            <h3 className="text-xl font-semibold text-brand-dark dark:text-white mb-2">Get Rewarded</h3>
                            <p className="text-gray-600 dark:text-gray-300">Our loyalty program is our way of saying thanks. Your 7th product is always on us!</p>
                        </div>
                    </div>
                </div>
            </div>

            {/* Meet the Founder */}
             <div className="bg-white dark:bg-gray-900 py-16 lg:py-24">
                 <div className="container mx-auto px-4 sm:px-6 lg:px-8">
                     <div className="flex flex-col md:flex-row items-center gap-12 max-w-4xl mx-auto">
                        <img src="https://picsum.photos/seed/founder/300/300" alt="Nicki lwky, Founder" className="w-48 h-48 rounded-full object-cover flex-shrink-0 shadow-lg"/>
                        <div className="text-center md:text-left">
                            <h2 className="text-3xl font-serif font-bold text-brand-dark dark:text-brand-light">A Word From Our Founder</h2>
                            <p className="mt-4 text-lg text-gray-700 dark:text-gray-300 italic">"I started Soap & Hope because I believe we shouldn't have to choose between a clean home and a healthy planet. My promise is to create products that you can feel good about using—products that are safe for your family, kind to the earth, and bring a little bit of hope back into your home."</p>
                            <p className="mt-4 font-semibold text-brand-dark dark:text-white">- Nicki lwky, Founder of Soap & Hope</p>
                        </div>
                     </div>
                 </div>
            </div>
            
             {/* CTA Section */}
            <div className="bg-brand-light dark:bg-gray-800 py-16 lg:py-24">
                 <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
                     <h2 className="text-3xl font-serif font-bold text-brand-dark dark:text-brand-light">Join the Clean Revolution</h2>
                     <p className="mt-4 text-lg text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">Ready to experience a new kind of clean? Explore our collections and find out why thousands have made the switch to Soap & Hope.</p>
                     <div className="mt-8 flex flex-col sm:flex-row justify-center gap-4">
                         <NavLink to="/products" className="bg-brand-primary text-white font-bold py-3 px-8 rounded-md hover:bg-opacity-80 transition-all transform hover:scale-105">
                             Shop Our Collection
                         </NavLink>
                          <NavLink to="/blog" className="bg-transparent border-2 border-brand-primary text-brand-primary font-bold py-3 px-8 rounded-md hover:bg-brand-primary/10 transition-colors">
                             Read Our Blog
                         </NavLink>
                     </div>
                 </div>
            </div>
        </div>
    );
};

export default AboutPage;