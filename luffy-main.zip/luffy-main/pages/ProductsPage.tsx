import React, { useState, useMemo, useEffect, useRef } from 'react';
import { useLocation, NavLink } from 'react-router-dom';
import { PRODUCTS, CATEGORIES } from '../constants';
import StarRating from '../components/StarRating';
import { useCart } from '../context/CartContext';
import { useWishlist } from '../context/WishlistContext';
import { Product } from '../types';
import QuickViewModal from '../components/QuickViewModal';
import Breadcrumbs, { BreadcrumbItem } from '../components/Breadcrumbs';

const EyeIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M2.036 12.322a1.012 1.012 0 010-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.432 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178z" />
        <path strokeLinecap="round" strokeLinejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
    </svg>
);

const HeartIcon: React.FC<{ filled: boolean } & React.SVGProps<SVGSVGElement>> = ({ filled, ...props }) => (
    filled ? (
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
          <path d="M11.645 20.91l-.007-.003-.022-.012a15.247 15.247 0 01-1.344-.688 15.182 15.182 0 01-1.06-1.066c-3.119-3.119-3.24-5.056-3.24-8.022 0-2.868 2.368-5.17 5.225-5.17 1.625 0 3.067.76 4.04 2.015.973-1.255 2.415-2.015 4.04-2.015 2.857 0 5.225 2.302 5.225 5.17 0 2.966-.12 4.903-3.24 8.022a15.182 15.182 0 01-1.06 1.066 15.247 15.247 0 01-1.344.688l-.022.012-.007.003h-.001a.752.752 0 01-.704 0h-.001z" />
        </svg>
    ) : (
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
          <path strokeLinecap="round" strokeLinejoin="round" d="M21 8.25c0-2.485-2.099-4.5-4.688-4.5-1.935 0-3.597 1.126-4.312 2.733-.715-1.607-2.377-2.733-4.313-2.733C5.1 3.75 3 5.765 3 8.25c0 7.22 9 12 9 12s9-4.78 9-12z" />
        </svg>
    )
);

const ChevronLeftIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" {...props}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 19.5L8.25 12l7.5-7.5" />
    </svg>
);

const ChevronRightIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" {...props}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M8.25 4.5l7.5 7.5-7.5 7.5" />
    </svg>
);

const ProductCard: React.FC<{ product: Product, onQuickView: (product: Product) => void }> = ({ product, onQuickView }) => {
    const { addToCart } = useCart();
    const { isInWishlist, addToWishlist, removeFromWishlist } = useWishlist();
    const onWishlist = isInWishlist(product.id);

    const handleWishlistClick = (e: React.MouseEvent) => {
        e.preventDefault();
        e.stopPropagation();
        if (onWishlist) {
            removeFromWishlist(product.id);
        } else {
            addToWishlist(product.id);
        }
    };

    return (
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md dark:border dark:border-gray-700 overflow-hidden group flex flex-col transition-shadow hover:shadow-xl">
            <div className="relative">
                <NavLink to={`/products/${product.id}`} className="block">
                    <img src={product.images[0]} alt={product.name} className="w-full h-56 sm:h-64 object-cover" />
                </NavLink>
                <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    <button 
                        onClick={() => onQuickView(product)}
                        className="flex items-center gap-2 bg-white text-brand-dark font-bold px-4 py-2 rounded-md hover:bg-gray-200 transition-colors"
                        aria-label={`Quick view ${product.name}`}
                    >
                        <EyeIcon className="w-5 h-5" />
                        Quick View
                    </button>
                </div>
                 <button 
                    onClick={handleWishlistClick}
                    className={`absolute top-3 right-3 p-1.5 rounded-full transition-colors duration-200 ${onWishlist ? 'bg-red-100 text-red-500' : 'bg-white/70 dark:bg-gray-800/70 text-gray-700 dark:text-gray-300 hover:bg-white dark:hover:bg-gray-700 hover:text-red-500'}`}
                    aria-label={onWishlist ? 'Remove from wishlist' : 'Add to wishlist'}
                >
                    <HeartIcon filled={onWishlist} className="w-6 h-6" />
                </button>
            </div>
            <div className="p-4 flex-grow flex flex-col">
                <p className="text-sm text-gray-500 dark:text-gray-400 mb-1 capitalize">{product.category}</p>
                <h3 className="text-lg font-semibold text-brand-dark dark:text-brand-light mb-2 flex-grow">
                    <NavLink to={`/products/${product.id}`} className="hover:text-brand-primary dark:hover:text-brand-secondary transition-colors">{product.name}</NavLink>
                </h3>
                <div className="flex items-center mb-2">
                    <StarRating rating={product.rating} />
                    <span className="text-xs text-gray-500 dark:text-gray-400 ml-2">({product.reviewCount})</span>
                </div>
                <div className="flex items-center justify-between mt-auto pt-2">
                    <p className="text-xl font-bold text-brand-primary dark:text-brand-secondary">Ksh {product.price.toLocaleString()}</p>
                    <button onClick={() => addToCart(product)} className="bg-brand-secondary text-brand-dark font-bold px-4 py-2 rounded-md hover:bg-opacity-80 transition-colors">
                        Add to Cart
                    </button>
                </div>
            </div>
        </div>
    );
};

const Pagination: React.FC<{ currentPage: number; totalPages: number; onPageChange: (page: number) => void }> = ({ currentPage, totalPages, onPageChange }) => {
    if (totalPages <= 1) {
        return null;
    }

    const getPageNumbers = () => {
        const pages: (number | string)[] = [];
        const visiblePages = 1; // How many pages to show around the current page

        // Always show the first page
        pages.push(1);

        // Show ellipsis if there's a gap after the first page
        if (currentPage > visiblePages + 2) {
            pages.push('...');
        }

        // Show pages around the current page
        const startPage = Math.max(2, currentPage - visiblePages);
        const endPage = Math.min(totalPages - 1, currentPage + visiblePages);
        for (let i = startPage; i <= endPage; i++) {
            pages.push(i);
        }

        // Show ellipsis if there's a gap before the last page
        if (currentPage < totalPages - visiblePages - 1) {
            pages.push('...');
        }

        // Always show the last page
        if (totalPages > 1) {
            pages.push(totalPages);
        }

        return pages;
    };

    const pages = getPageNumbers();

    return (
        <nav aria-label="Product pagination" className="flex justify-center items-center gap-1 sm:gap-2 mt-12">
            <button
                onClick={() => onPageChange(currentPage - 1)}
                disabled={currentPage === 1}
                className="flex items-center gap-2 px-3 py-2 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-md text-sm font-medium text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 disabled:opacity-50 disabled:cursor-not-allowed"
                aria-label="Go to previous page"
            >
                <ChevronLeftIcon className="w-4 h-4" />
                <span className="hidden sm:inline">Previous</span>
            </button>
            {pages.map((page, index) =>
                typeof page === 'number' ? (
                    <button
                        key={index}
                        onClick={() => onPageChange(page)}
                        className={`w-10 h-10 border border-gray-300 dark:border-gray-600 rounded-md text-sm font-medium transition-colors ${
                            currentPage === page
                                ? 'bg-brand-primary text-white border-brand-primary dark:border-brand-primary'
                                : 'bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700'
                        }`}
                        aria-current={currentPage === page ? 'page' : undefined}
                    >
                        {page}
                    </button>
                ) : (
                    <span key={index} className="flex items-center justify-center w-10 h-10 text-gray-500 dark:text-gray-400">
                        ...
                    </span>
                )
            )}
            <button
                onClick={() => onPageChange(currentPage + 1)}
                disabled={currentPage === totalPages}
                className="flex items-center gap-2 px-3 py-2 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-md text-sm font-medium text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 disabled:opacity-50 disabled:cursor-not-allowed"
                aria-label="Go to next page"
            >
                <span className="hidden sm:inline">Next</span>
                <ChevronRightIcon className="w-4 h-4" />
            </button>
        </nav>
    );
};


function useQuery() {
    return new URLSearchParams(useLocation().search);
}

const ProductsPage: React.FC = () => {
    const query = useQuery();
    const location = useLocation();
    const mainContentRef = useRef<HTMLElement>(null);

    const [categoryFilter, setCategoryFilter] = useState<string>('all');
    const [sort, setSort] = useState('rating');
    const [quickViewProduct, setQuickViewProduct] = useState<Product | null>(null);
    const [currentPage, setCurrentPage] = useState(1);
    
    const PRODUCTS_PER_PAGE = 6;

    const prices = useMemo(() => PRODUCTS.map(p => p.price), []);
    const minAbsPrice = 0;
    const maxAbsPrice = useMemo(() => Math.ceil(Math.max(...prices) / 100) * 100, [prices]);
    const [priceRange, setPriceRange] = useState<[number, number]>([minAbsPrice, maxAbsPrice]);
    const priceGap = Math.ceil((maxAbsPrice - minAbsPrice) * 0.1);

    const handleMinPriceChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const value = Math.min(Number(e.target.value), priceRange[1] - priceGap);
        setPriceRange([value, priceRange[1]]);
    };

    const handleMaxPriceChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const value = Math.max(Number(e.target.value), priceRange[0] + priceGap);
        setPriceRange([priceRange[0], value]);
    };

    const searchQuery = query.get('search') || '';

    useEffect(() => {
        const params = new URLSearchParams(location.search);
        setCategoryFilter(params.get('category') || 'all');
    }, [location.search]);

    // Reset to page 1 when filters change
    useEffect(() => {
        setCurrentPage(1);
    }, [categoryFilter, priceRange, sort, searchQuery]);


    const handleOpenQuickView = (product: Product) => {
      setQuickViewProduct(product);
    };
  
    const handleCloseQuickView = () => {
      setQuickViewProduct(null);
    };

    const filteredProducts = useMemo(() => {
        const lowercasedQuery = searchQuery.toLowerCase();

        return PRODUCTS
            .filter(p => {
                if (!lowercasedQuery) return true;
                return p.name.toLowerCase().includes(lowercasedQuery) ||
                       p.description.toLowerCase().includes(lowercasedQuery);
            })
            .filter(p => categoryFilter === 'all' || p.category === categoryFilter)
            .filter(p => p.price >= priceRange[0] && p.price <= priceRange[1])
            .sort((a, b) => {
                if (sort === 'rating') return b.rating - a.rating;
                if (sort === 'price-asc') return a.price - b.price;
                if (sort === 'price-desc') return b.price - a.price;
                return 0;
            });
    }, [categoryFilter, priceRange, sort, searchQuery]);
    
    const totalPages = Math.ceil(filteredProducts.length / PRODUCTS_PER_PAGE);
    const currentProducts = useMemo(() => {
        const startIndex = (currentPage - 1) * PRODUCTS_PER_PAGE;
        return filteredProducts.slice(startIndex, startIndex + PRODUCTS_PER_PAGE);
    }, [currentPage, filteredProducts]);

    const handlePageChange = (page: number) => {
        setCurrentPage(page);
        mainContentRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }

    const breadcrumbItems = useMemo((): BreadcrumbItem[] => {
        const items: BreadcrumbItem[] = [
            { name: 'Home', path: '/' },
        ];
    
        if (categoryFilter === 'all' && !searchQuery) {
            items.push({ name: 'Products' });
        } else {
            items.push({ name: 'Products', path: '/products' });
        }
    
        if (searchQuery) {
            items.push({ name: `Search: "${searchQuery}"` });
        } else if (categoryFilter !== 'all') {
            const category = CATEGORIES.find(c => c.id === categoryFilter);
            if (category) {
                items.push({ name: category.name });
            }
        }
        
        return items;
    }, [categoryFilter, searchQuery]);

    return (
        <div className="bg-gray-50 dark:bg-gray-900">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
                <Breadcrumbs items={breadcrumbItems} />
                <div className="text-center mb-12">
                    <h1 className="text-3xl sm:text-4xl font-serif font-bold text-brand-dark dark:text-brand-light">Our Collection</h1>
                    {searchQuery ? (
                        <p className="text-lg text-gray-600 dark:text-gray-300 mt-2">Showing results for: <span className="font-semibold text-brand-primary dark:text-brand-secondary">"{searchQuery}"</span></p>
                    ) : (
                        <p className="text-lg text-gray-600 dark:text-gray-300 mt-2">Find the perfect solution for a sparkling clean home.</p>
                    )}
                </div>

                <div className="flex flex-col lg:flex-row gap-8">
                    {/* Filters */}
                    <aside className="lg:w-1/4">
                        <div className="sticky top-24 bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md dark:border dark:border-gray-700">
                            <h2 className="text-2xl font-semibold text-brand-dark dark:text-brand-light mb-6">Filters</h2>
                            <div className="space-y-6">
                                <div>
                                    <h3 className="font-semibold mb-3 dark:text-white">Category</h3>
                                    <select value={categoryFilter} onChange={(e) => setCategoryFilter(e.target.value)} className="w-full p-2 border rounded-md dark:bg-gray-700 dark:border-gray-600 dark:text-gray-200">
                                        <option value="all">All</option>
                                        {CATEGORIES.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                                    </select>
                                </div>
                                <div>
                                    <h3 className="font-semibold mb-3 dark:text-white">Price Range</h3>
                                    <div className="flex justify-between items-center text-sm text-gray-600 dark:text-gray-300 mb-2">
                                        <span className="border dark:border-gray-600 px-3 py-1 rounded-md bg-gray-50 dark:bg-gray-700 w-24 text-center">Ksh {priceRange[0]}</span>
                                        <span className="text-gray-400">-</span>
                                        <span className="border dark:border-gray-600 px-3 py-1 rounded-md bg-gray-50 dark:bg-gray-700 w-24 text-center">Ksh {priceRange[1]}</span>
                                    </div>
                                    <div className="relative h-5">
                                        <div className="absolute top-1/2 -translate-y-1/2 w-full h-1 bg-gray-200 dark:bg-gray-600 rounded-full"></div>
                                        <div 
                                            className="absolute top-1/2 -translate-y-1/2 h-1 bg-brand-primary dark:bg-brand-secondary rounded-full"
                                            style={{
                                                left: `${(priceRange[0] / maxAbsPrice) * 100}%`,
                                                right: `${100 - (priceRange[1] / maxAbsPrice) * 100}%`
                                            }}
                                        ></div>
                                        <input
                                            type="range"
                                            min={minAbsPrice}
                                            max={maxAbsPrice}
                                            value={priceRange[0]}
                                            onChange={handleMinPriceChange}
                                            step="10"
                                            aria-label="Minimum price"
                                            className="absolute w-full appearance-none bg-transparent pointer-events-none h-full z-10
                                                      [&::-webkit-slider-thumb]:pointer-events-auto
                                                      [&::-moz-range-thumb]:pointer-events-auto
                                                      [&::-webkit-slider-thumb]:appearance-none
                                                      [&::-webkit-slider-thumb]:h-4 [&::-webkit-slider-thumb]:w-4
                                                      [&::-webkit-slider-thumb]:bg-brand-primary
                                                      [&::-webkit-slider-thumb]:dark:bg-brand-secondary
                                                      [&::-webkit-slider-thumb]:rounded-full
                                                      [&::-webkit-slider-thumb]:cursor-pointer
                                                      [&::-moz-range-thumb]:h-4 [&::-moz-range-thumb]:w-4
                                                      [&::-moz-range-thumb]:bg-brand-primary
                                                      [&::-moz-range-thumb]:dark:bg-brand-secondary
                                                      [&::-moz-range-thumb]:rounded-full
                                                      [&::-moz-range-thumb]:cursor-pointer
                                                      [&::-moz-range-thumb]:border-none
                                                      "
                                        />
                                        <input
                                            type="range"
                                            min={minAbsPrice}
                                            max={maxAbsPrice}
                                            value={priceRange[1]}
                                            onChange={handleMaxPriceChange}
                                            step="10"
                                            aria-label="Maximum price"
                                            className="absolute w-full appearance-none bg-transparent pointer-events-none h-full
                                                      [&::-webkit-slider-thumb]:pointer-events-auto
                                                      [&::-moz-range-thumb]:pointer-events-auto
                                                      [&::-webkit-slider-thumb]:appearance-none
                                                      [&::-webkit-slider-thumb]:h-4 [&::-webkit-slider-thumb]:w-4
                                                      [&::-webkit-slider-thumb]:bg-brand-primary
                                                      [&::-webkit-slider-thumb]:dark:bg-brand-secondary
                                                      [&::-webkit-slider-thumb]:rounded-full
                                                      [&::-webkit-slider-thumb]:cursor-pointer
                                                      [&::-moz-range-thumb]:h-4 [&::-moz-range-thumb]:w-4
                                                      [&::-moz-range-thumb]:bg-brand-primary
                                                      [&::-moz-range-thumb]:dark:bg-brand-secondary
                                                      [&::-moz-range-thumb]:rounded-full
                                                      [&::-moz-range-thumb]:cursor-pointer
                                                      [&::-moz-range-thumb]:border-none
                                                      "
                                        />
                                    </div>
                                </div>
                                <div>
                                    <h3 className="font-semibold mb-3 dark:text-white">Sort By</h3>
                                    <select value={sort} onChange={(e) => setSort(e.target.value)} className="w-full p-2 border rounded-md dark:bg-gray-700 dark:border-gray-600 dark:text-gray-200">
                                        <option value="rating">Top Rated</option>
                                        <option value="price-asc">Price: Low to High</option>
                                        <option value="price-desc">Price: High to Low</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </aside>

                    {/* Product Grid */}
                    <main ref={mainContentRef} className="lg:w-3/4">
                        {currentProducts.length > 0 ? (
                            <>
                                <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-8">
                                    {currentProducts.map(product => (
                                        <ProductCard 
                                            key={product.id} 
                                            product={product}
                                            onQuickView={handleOpenQuickView}
                                        />
                                    ))}
                                </div>
                                <Pagination
                                    currentPage={currentPage}
                                    totalPages={totalPages}
                                    onPageChange={handlePageChange}
                                />
                            </>
                        ) : (
                             <div className="text-center py-20 bg-white dark:bg-gray-800 rounded-lg shadow dark:border dark:border-gray-700">
                                <p className="text-xl text-gray-600 dark:text-gray-300 font-semibold mb-2">No products found</p>
                                <p className="text-gray-500 dark:text-gray-400">Try adjusting your filters or search term.</p>
                             </div>
                        )}
                    </main>
                </div>
            </div>
            <QuickViewModal
                product={quickViewProduct}
                isOpen={!!quickViewProduct}
                onClose={handleCloseQuickView}
            />
        </div>
    );
};

export default ProductsPage;