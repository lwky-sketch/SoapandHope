import React, { useEffect } from 'react';
import { useParams, NavLink } from 'react-router-dom';
import { BLOG_POSTS } from '../constants';

const BlogPostPage: React.FC = () => {
    const { id } = useParams<{ id: string }>();
    const post = BLOG_POSTS.find(p => p.id === Number(id));

    useEffect(() => {
        window.scrollTo(0, 0);
    }, [id]);

    if (!post) {
        return (
            <div className="text-center py-20">
                <h1 className="text-2xl font-bold">Blog post not found.</h1>
                <NavLink to="/blog" className="text-brand-primary hover:underline mt-4 inline-block">
                    &larr; Back to Blog
                </NavLink>
            </div>
        );
    }

    return (
        <div className="bg-white dark:bg-gray-900 py-12 md:py-16">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8">
                <div className="max-w-3xl mx-auto">
                    <article>
                        <header className="mb-8">
                            <NavLink to="/blog" className="text-brand-primary dark:text-brand-secondary hover:underline text-sm font-semibold mb-4 inline-block">
                                &larr; Back to Blog
                            </NavLink>
                            <h1 className="text-4xl md:text-5xl font-serif font-bold text-brand-dark dark:text-brand-light leading-tight">
                                {post.title}
                            </h1>
                            <p className="text-gray-500 dark:text-gray-400 mt-4 text-sm">
                                By {post.author} on {post.date}
                            </p>
                        </header>
                        
                        <img src={post.image} alt={post.title} className="w-full h-auto max-h-[500px] object-cover rounded-lg shadow-lg mb-8" />

                        <div className="prose lg:prose-lg max-w-none text-gray-800 dark:text-gray-300 dark:prose-invert leading-relaxed space-y-6">
                            {post.content.map((paragraph, index) => (
                                <p key={index}>{paragraph}</p>
                            ))}
                        </div>
                    </article>
                </div>
            </div>
        </div>
    );
};

export default BlogPostPage;
