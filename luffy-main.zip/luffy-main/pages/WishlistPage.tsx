import React, { useEffect } from 'react';
import { NavLink } from 'react-router-dom';
import { useWishlist } from '../context/WishlistContext';
import { useCart } from '../context/CartContext';
import { PRODUCTS } from '../constants';
import StarRating from '../components/StarRating';
import { Product } from '../types';

const TrashIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M14.74 9l-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 01-2.244 2.077H8.084a2.25 2.25 0 01-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 00-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 013.478-.397m7.5 0v-.916c0-1.18-.91-2.134-2.033-2.134H8.033C6.91 2.75 6 3.664 6 4.874v.916m7.5 0a48.667 48.667 0 00-7.5 0" />
    </svg>
);

const WishlistProductCard: React.FC<{ product: Product }> = ({ product }) => {
    const { removeFromWishlist } = useWishlist();
    const { addToCart } = useCart();

    return (
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md dark:border dark:border-gray-700 overflow-hidden flex flex-col transition-shadow hover:shadow-xl">
            <NavLink to={`/products/${product.id}`} className="block relative">
                <img src={product.images[0]} alt={product.name} className="w-full h-64 object-cover" />
            </NavLink>
            <div className="p-4 flex-grow flex flex-col">
                 <h3 className="text-lg font-semibold text-brand-dark dark:text-brand-light mb-2 flex-grow">
                    <NavLink to={`/products/${product.id}`} className="hover:text-brand-primary dark:hover:text-brand-secondary transition-colors">{product.name}</NavLink>
                </h3>
                <div className="flex items-center mb-2">
                    <StarRating rating={product.rating} />
                    <span className="text-xs text-gray-500 dark:text-gray-400 ml-2">({product.reviewCount})</span>
                </div>
                <p className="text-xl font-bold text-brand-primary dark:text-brand-secondary mb-4">Ksh {product.price.toLocaleString()}</p>
                <div className="mt-auto pt-2 space-y-2">
                    <button onClick={() => addToCart(product)} className="w-full bg-brand-secondary text-brand-dark font-bold px-4 py-2 rounded-md hover:bg-opacity-80 transition-colors">
                        Add to Cart
                    </button>
                    <button onClick={() => removeFromWishlist(product.id)} className="w-full flex items-center justify-center gap-2 text-red-500 font-semibold px-4 py-2 rounded-md hover:bg-red-50 dark:hover:bg-red-500/10 transition-colors">
                        <TrashIcon className="w-5 h-5" />
                        Remove
                    </button>
                </div>
            </div>
        </div>
    )
}

const WishlistPage: React.FC = () => {
    const { wishlist } = useWishlist();
    const wishlistProducts = PRODUCTS.filter(p => wishlist.includes(p.id));
    
    useEffect(() => {
      window.scrollTo(0, 0);
    }, []);

    return (
        <div className="bg-gray-50 dark:bg-gray-900 min-h-[60vh]">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
                <div className="text-center mb-12">
                    <h1 className="text-4xl font-serif font-bold text-brand-dark dark:text-brand-light">Your Wishlist</h1>
                    <p className="text-lg text-gray-600 dark:text-gray-300 mt-2">{wishlistProducts.length} {wishlistProducts.length === 1 ? 'item' : 'items'} saved for later.</p>
                </div>

                {wishlistProducts.length > 0 ? (
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
                        {wishlistProducts.map(product => (
                            <WishlistProductCard key={product.id} product={product} />
                        ))}
                    </div>
                ) : (
                    <div className="text-center py-20 bg-white dark:bg-gray-800 rounded-lg shadow-md dark:border dark:border-gray-700">
                        <p className="text-xl text-gray-600 dark:text-gray-300 mb-6">Your wishlist is empty.</p>
                        <NavLink to="/products" className="bg-brand-primary text-white font-bold py-3 px-8 rounded-md hover:bg-opacity-80 transition-colors">
                            Discover Products
                        </NavLink>
                    </div>
                )}
            </div>
        </div>
    );
};

export default WishlistPage;