import React, { useState, useEffect } from 'react';
import { useParams, NavLink } from 'react-router-dom';
import { PRODUCTS, CATEGORIES } from '../constants';
import StarRating from '../components/StarRating';
import { useCart } from '../context/CartContext';
import { useWishlist } from '../context/WishlistContext';
import { useReviews } from '../context/ReviewContext';
import { useAuth } from '../context/AuthContext';
import ReviewForm from '../components/ReviewForm';
import Breadcrumbs, { BreadcrumbItem } from '../components/Breadcrumbs';

const HeartIcon: React.FC<{ filled: boolean } & React.SVGProps<SVGSVGElement>> = ({ filled, ...props }) => (
    filled ? (
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
          <path d="M11.645 20.91l-.007-.003-.022-.012a15.247 15.247 0 01-1.344-.688 15.182 15.182 0 01-1.06-1.066c-3.119-3.119-3.24-5.056-3.24-8.022 0-2.868 2.368-5.17 5.225-5.17 1.625 0 3.067.76 4.04 2.015.973-1.255 2.415-2.015 4.04-2.015 2.857 0 5.225 2.302 5.225 5.17 0 2.966-.12 4.903-3.24 8.022a15.182 15.182 0 01-1.06 1.066 15.247 15.247 0 01-1.344.688l-.022.012-.007.003h-.001a.752.752 0 01-.704 0h-.001z" />
        </svg>
    ) : (
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
          <path strokeLinecap="round" strokeLinejoin="round" d="M21 8.25c0-2.485-2.099-4.5-4.688-4.5-1.935 0-3.597 1.126-4.312 2.733-.715-1.607-2.377-2.733-4.313-2.733C5.1 3.75 3 5.765 3 8.25c0 7.22 9 12 9 12s9-4.78 9-12z" />
        </svg>
    )
);

const FacebookIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg fill="currentColor" viewBox="0 0 24 24" {...props}><path d="M22 12c0-5.52-4.48-10-10-10S2 6.48 2 12c0 4.84 3.44 8.87 8 9.8V15H8v-3h2V9.5C10 7.57 11.57 6 13.5 6H16v3h-2c-.55 0-1 .45-1 1v2h3l-.5 3h-2.5v6.8c4.56-.93 8-4.96 8-9.8z"/></svg>
);

const TwitterIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg fill="currentColor" viewBox="0 0 24 24" {...props}><path d="M22.46 6c-.77.35-1.6.58-2.46.67.88-.53 1.56-1.37 1.88-2.38-.83.49-1.75.85-2.72 1.05C18.37 4.5 17.26 4 16 4c-2.35 0-4.27 1.92-4.27 4.29 0 .34.04.67.11.98-3.56-.18-6.73-1.89-8.84-4.48-.37.63-.58 1.37-.58 2.15 0 1.49.76 2.81 1.91 3.58-.7-.02-1.37-.21-1.95-.5v.03c0 2.08 1.48 3.82 3.44 4.21-.36.1-.74.15-1.14.15-.28 0-.55-.03-.81-.08.55 1.7 2.14 2.94 4.03 2.97-1.47 1.15-3.33 1.84-5.35 1.84-.35 0-.69-.02-1.03-.06 1.9 1.23 4.16 1.94 6.58 1.94 7.9 0 12.23-6.54 12.23-12.23 0-.19 0-.37-.01-.56.84-.6 1.56-1.36 2.14-2.22z"/></svg>
);

const PinterestIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg fill="currentColor" viewBox="0 0 24 24" {...props}><path d="M12 2C6.48 2 2 6.48 2 12c0 4.25 2.76 7.85 6.5 9.25.07-.55.08-1.18 0-1.74-.2-.87-.97-4.1.97-4.1.9 0 1.33.67 1.33 1.48 0 .9-.57 2.24-.86 3.48-.25 1.04.52 1.89 1.55 1.89 1.85 0 3.27-1.96 3.27-4.78 0-2.43-1.75-4.29-4.1-4.29-2.79 0-4.4 2.09-4.4 4.31 0 .86.33 1.78.74 2.31.08.1.09.19.06.3l-.22.9c-.06.27-.2.36-.45.22-1.42-.64-2.31-2.61-2.31-4.26 0-3.33 2.4-6.3 6.94-6.3 3.67 0 6.5 2.59 6.5 6.03 0 3.7-2.34 6.6-5.56 6.6-1.11 0-2.16-.57-2.52-1.23l-.78-3.1c-.24-.95-.97-1.84-1.57-2.57C10.7 8.35 11.08 8 11.23 8c.37 0 .62.47.62 1.04 0 .78-.23 1.58-.23 1.58s.92-3.84 1.1-4.5c.31-1.13.25-2.29.25-2.29s.25-.11.56-.11c.96 0 2.26 1.11 2.26 3.09 0 2.85-1.5 4.96-1.5 4.96s.51 2.14.7 2.52c.26.54.94.7 1.4.45 1.45-.78 2.2-2.31 2.2-4.29 0-2.75-2.55-5.2-6.2-5.2C6.48 2 2 6.48 2 12c0 1.9.61 3.66 1.63 5.09.16.22.12.53-.1.7l-1.3 1.3c-.2.2-.51.2-.71 0-.15-.15-.22-.36-.18-.56C2.26 17.15 2 14.65 2 12 2 6.48 6.48 2 12 2z"/></svg>
);

const CheckBadgeIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75L11.25 15 15 9.75M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
    </svg>
);

const TruckIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path d="M8.25 18.75a1.5 1.5 0 01-3 0m3 0a1.5 1.5 0 00-3 0m3 0h6m-9 0H3.375a1.125 1.125 0 01-1.125-1.125V14.25m17.25 4.5a1.5 1.5 0 01-3 0m3 0a1.5 1.5 0 00-3 0m3 0h1.125c.621 0 1.125-.504 1.125-1.125V14.25m-17.25 4.5v-9m17.25 9v-9m0 0H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V9.75M15 9.75l-3.75 3.75-3.75-3.75" />
  </svg>
);

const ProductDetailPage: React.FC = () => {
    const { id } = useParams<{ id: string }>();
    const productId = Number(id);
    const product = PRODUCTS.find(p => p.id === productId);
    
    const [mainImage, setMainImage] = useState<string | undefined>(product?.images[0]);
    const [quantity, setQuantity] = useState(1);
    const [activeTab, setActiveTab] = useState('description');
    const { addToCart } = useCart();
    const { isInWishlist, addToWishlist, removeFromWishlist } = useWishlist();
    const { getReviewsByProductId, productAverageRating } = useReviews();
    const { isAuthenticated, openAuthModal } = useAuth();

    const reviews = getReviewsByProductId(productId);
    const averageRating = productAverageRating(productId);

    useEffect(() => {
      window.scrollTo(0, 0);
      if (product) {
        setMainImage(product.images[0]);
        setQuantity(1);
        setActiveTab('description');
      }
    }, [id, product]);

    if (!product) {
        return <div className="text-center py-20">Product not found.</div>;
    }
    
    const onWishlist = isInWishlist(product.id);
    const handleWishlistClick = () => {
        if (onWishlist) {
            removeFromWishlist(product.id);
        } else {
            addToWishlist(product.id);
        }
    };

    const handleShare = (platform: 'facebook' | 'twitter' | 'pinterest') => {
        const url = window.location.href;
        const text = `Check out this amazing product: ${product.name}!`;
        const imageUrl = product.images[0];
        let shareUrl = '';

        switch (platform) {
            case 'facebook':
                shareUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`;
                break;
            case 'twitter':
                shareUrl = `https://twitter.com/intent/tweet?url=${encodeURIComponent(url)}&text=${encodeURIComponent(text)}`;
                break;
            case 'pinterest':
                shareUrl = `https://pinterest.com/pin/create/button/?url=${encodeURIComponent(url)}&media=${encodeURIComponent(imageUrl)}&description=${encodeURIComponent(text)}`;
                break;
        }

        if (shareUrl) {
            window.open(shareUrl, '_blank', 'noopener,noreferrer,width=600,height=400');
        }
    };

    const relatedProducts = PRODUCTS.filter(p => p.category === product.category && p.id !== product.id).slice(0, 3);
    
    const tabButtonClasses = (tabName: string) => `pb-2 text-lg font-semibold transition-colors border-b-2 ${activeTab === tabName ? 'border-brand-primary dark:border-brand-secondary text-brand-primary dark:text-brand-secondary' : 'border-transparent text-gray-500 dark:text-gray-400 hover:text-brand-dark dark:hover:text-white'}`;

    const category = CATEGORIES.find(c => c.id === product.category);
    const breadcrumbItems: BreadcrumbItem[] = [
        { name: 'Home', path: '/' },
        { name: 'Products', path: '/products' },
    ];
    if (category) {
        breadcrumbItems.push({
            name: category.name,
            path: `/products?category=${category.id}`
        });
    }
    breadcrumbItems.push({ name: product.name });

    return (
        <div className="bg-white dark:bg-gray-900 py-12">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8">
                <Breadcrumbs items={breadcrumbItems} />
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
                    {/* Image Gallery */}
                    <div>
                        <div className="aspect-square bg-gray-100 dark:bg-gray-800 rounded-lg mb-4 overflow-hidden shadow-sm">
                            <img src={mainImage} alt={product.name} className="w-full h-full object-cover" />
                        </div>
                        <div className="flex gap-2">
                            {product.images.map((img, index) => (
                                <button key={index} onClick={() => setMainImage(img)} className={`w-24 h-24 rounded-md overflow-hidden border-2 transition-all ${mainImage === img ? 'border-brand-primary dark:border-brand-secondary shadow' : 'border-transparent hover:border-gray-300 dark:hover:border-gray-600'}`}>
                                    <img src={img} alt={`${product.name} thumbnail ${index + 1}`} className="w-full h-full object-cover" />
                                </button>
                            ))}
                        </div>
                    </div>

                    {/* Product Info */}
                    <div>
                        <NavLink to={`/products?category=${product.category}`} className="text-brand-primary dark:text-brand-secondary font-semibold uppercase tracking-wide hover:underline">
                            {product.category}
                        </NavLink>
                        <h1 className="text-3xl sm:text-4xl lg:text-5xl font-serif font-bold text-brand-dark dark:text-brand-light my-3">{product.name}</h1>
                        <div className="flex items-center gap-4 mb-4">
                            <StarRating rating={averageRating > 0 ? averageRating : product.rating} />
                            <a href="#reviews" onClick={() => setActiveTab('reviews')} className="text-gray-600 dark:text-gray-400 hover:underline">{reviews.length} review{reviews.length !== 1 ? 's' : ''}</a>
                        </div>
                        <div className="flex items-center gap-4 text-sm text-gray-600 dark:text-gray-300 mb-4">
                            <span><strong>Scent:</strong> {product.scent}</span>
                            <span className="w-px h-4 bg-gray-300 dark:bg-gray-600"></span>
                            <span><strong>Size:</strong> {product.size}</span>
                        </div>
                        <div className="inline-flex items-center gap-2 px-3 py-1 text-sm font-semibold text-green-800 bg-green-100 rounded-full mb-4">
                            <CheckBadgeIcon className="w-5 h-5"/>
                            In Stock
                        </div>
                        <p className="text-3xl font-bold text-brand-primary dark:text-brand-secondary mb-6">Ksh {product.price.toLocaleString()}</p>
                        
                        <div className="flex flex-col sm:flex-row items-center gap-4 mb-8">
                            <div className="flex items-center border border-gray-300 dark:border-gray-600 rounded-md w-full sm:w-auto justify-center">
                                <button onClick={() => setQuantity(q => Math.max(1, q - 1))} className="px-4 py-3 text-lg leading-none hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors rounded-l-md dark:text-white" aria-label="Decrease quantity">-</button>
                                <input 
                                    type="number" 
                                    value={quantity} 
                                    onChange={(e) => setQuantity(Math.max(1, parseInt(e.target.value) || 1))}
                                    className="w-16 flex-grow text-center border-l border-r dark:border-gray-600 text-lg font-semibold bg-transparent dark:text-white"
                                    min="1"
                                    aria-label="Product quantity"
                                />
                                <button onClick={() => setQuantity(q => q + 1)} className="px-4 py-3 text-lg leading-none hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors rounded-r-md dark:text-white" aria-label="Increase quantity">+</button>
                            </div>
                            <button onClick={() => addToCart(product, quantity)} className="w-full sm:flex-1 bg-brand-primary text-white font-bold py-3 px-8 rounded-md hover:bg-opacity-80 transition-colors">
                                Add to Cart
                            </button>
                            <button 
                                onClick={handleWishlistClick}
                                className={`p-3 rounded-md border-2 transition-colors ${onWishlist ? 'border-red-500 bg-red-100 text-red-500' : 'border-gray-300 dark:border-gray-600 text-gray-500 dark:text-gray-300 hover:border-red-400 dark:hover:border-red-500 hover:text-red-400 dark:hover:text-red-500'}`}
                                aria-label={onWishlist ? 'Remove from wishlist' : 'Add to wishlist'}
                            >
                                <HeartIcon filled={onWishlist} className="w-6 h-6" />
                            </button>
                        </div>
                        
                         <div className="mt-8 pt-6 border-t dark:border-gray-700 space-y-4">
                            <div className="flex items-center gap-3 text-sm text-gray-700 dark:text-gray-300">
                                <TruckIcon className="w-6 h-6 text-brand-primary dark:text-brand-secondary"/>
                                <span><strong>Free shipping</strong> on orders bellow Ksh 2,000</span>
                            </div>
                            <div className="flex items-center gap-3 text-sm text-gray-700 dark:text-gray-300">
                                <CheckBadgeIcon className="w-6 h-6 text-brand-primary dark:text-brand-secondary"/>
                                <span>Plant-based, cruelty-free, and eco-friendly</span>
                            </div>
                        </div>

                        <div className="mt-8 pt-6 border-t dark:border-gray-700">
                            <h3 className="font-semibold text-gray-800 dark:text-gray-200 mb-3">Share this product</h3>
                            <div className="flex items-center gap-4">
                                <button onClick={() => handleShare('facebook')} className="text-gray-500 dark:text-gray-400 hover:text-[#1877F2] transition-colors" aria-label="Share on Facebook"><FacebookIcon className="w-7 h-7" /></button>
                                <button onClick={() => handleShare('twitter')} className="text-gray-500 dark:text-gray-400 hover:text-[#1DA1F2] transition-colors" aria-label="Share on Twitter"><TwitterIcon className="w-7 h-7" /></button>
                                <button onClick={() => handleShare('pinterest')} className="text-gray-500 dark:text-gray-400 hover:text-[#E60023] transition-colors" aria-label="Share on Pinterest"><PinterestIcon className="w-7 h-7" /></button>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Tabs Section */}
                <div id="reviews" className="mt-16 pt-10 border-t dark:border-gray-700">
                    <div className="border-b border-gray-200 dark:border-gray-700 mb-8">
                        <nav className="flex space-x-8 -mb-px">
                            <button onClick={() => setActiveTab('description')} className={tabButtonClasses('description')}>Description</button>
                            <button onClick={() => setActiveTab('ingredients')} className={tabButtonClasses('ingredients')}>Ingredients</button>
                            <button onClick={() => setActiveTab('reviews')} className={tabButtonClasses('reviews')}>Reviews ({reviews.length})</button>
                        </nav>
                    </div>

                    <div>
                        {activeTab === 'description' && (
                            <div className="prose lg:prose-lg max-w-none text-gray-700 dark:text-gray-300 leading-relaxed dark:prose-invert">
                                <p>{product.description}</p>
                            </div>
                        )}
                        {activeTab === 'ingredients' && (
                           <div className="prose lg:prose-lg max-w-none text-gray-700 dark:text-gray-300 dark:prose-invert">
                             <ul className="list-disc pl-5 space-y-2">
                               {product.ingredients.map((ing, i) => <li key={i}>{ing}</li>)}
                             </ul>
                           </div>
                        )}
                        {activeTab === 'reviews' && (
                            <div>
                                <h2 className="text-3xl font-bold font-serif mb-8 text-center dark:text-white">Customer Reviews & Feedback</h2>
                                <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
                                    <div>
                                        {isAuthenticated ? (
                                            <ReviewForm productId={productId} />
                                        ) : (
                                            <div className="bg-gray-50 dark:bg-gray-800 p-6 rounded-lg border dark:border-gray-700 text-center">
                                                <h3 className="text-xl font-semibold mb-4 dark:text-white">Want to share your thoughts?</h3>
                                                <p className="text-gray-600 dark:text-gray-300 mb-4">Please log in to leave a review.</p>
                                                <button onClick={openAuthModal} className="bg-brand-dark text-white font-bold py-2 px-6 rounded-md hover:bg-opacity-80 transition-colors">
                                                    Login / Signup
                                                </button>
                                            </div>
                                        )}
                                    </div>
                                    <div className="max-h-[500px] overflow-y-auto pr-4">
                                        {reviews.length > 0 ? (
                                            <div className="space-y-6">
                                                {reviews.map(review => (
                                                    <div key={review.id} className="border-b dark:border-gray-700 pb-4">
                                                        <div className="flex items-center mb-2">
                                                            <StarRating rating={review.rating} />
                                                        </div>
                                                        <p className="text-gray-700 dark:text-gray-300">{review.comment}</p>
                                                        <div className="text-right mt-2">
                                                            <span className="font-bold text-sm text-brand-dark dark:text-white">- {review.author}</span>
                                                            <span className="text-xs text-gray-500 dark:text-gray-400 ml-2">on {new Date(review.date).toLocaleDateString()}</span>
                                                        </div>
                                                    </div>
                                                ))}
                                            </div>
                                        ) : (
                                            <div className="text-center text-gray-500 dark:text-gray-400 pt-8">
                                                <p>This product has no reviews yet.</p>
                                                <p>Be the first to share your thoughts!</p>
                                            </div>
                                        )}
                                    </div>
                                </div>
                            </div>
                        )}
                    </div>
                </div>
                
                {/* Related Products */}
                <div className="mt-20">
                    <h2 className="text-2xl font-bold font-serif text-center mb-8 dark:text-white">You Might Also Like</h2>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-8">
                       {relatedProducts.map(rp => (
                           <div key={rp.id} className="text-center group">
                               <NavLink to={`/products/${rp.id}`}>
                                  <div className="overflow-hidden rounded-lg mb-2">
                                    <img src={rp.images[0]} alt={rp.name} className="w-full h-48 object-cover rounded-lg group-hover:scale-105 transition-transform duration-300" />
                                  </div>
                                  <h3 className="font-semibold hover:text-brand-primary dark:text-white dark:hover:text-brand-secondary">{rp.name}</h3>
                                  <p className="font-bold text-brand-primary dark:text-brand-secondary">Ksh {rp.price.toLocaleString()}</p>
                                </NavLink>
                           </div>
                       ))}
                    </div>
                </div>

            </div>
        </div>
    );
};

export default ProductDetailPage;