import React, { useState, useMemo, useEffect } from 'react';
import { NavLink } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useOrder } from '../context/OrderContext';
import { useCart } from '../context/CartContext';
import { Order, Product } from '../types';
import { PRODUCTS, MOCK_ORDERS } from '../constants';

// --- ICONS ---
const ChevronDownIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 8.25l-7.5 7.5-7.5-7.5" />
  </svg>
);
const CheckCircleIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75L11.25 15 15 9.75M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
  </svg>
);
const TruckIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path d="M8.25 18.75a1.5 1.5 0 01-3 0m3 0a1.5 1.5 0 00-3 0m3 0h6m-9 0H3.375a1.125 1.125 0 01-1.125-1.125V14.25m17.25 4.5a1.5 1.5 0 01-3 0m3 0a1.5 1.5 0 00-3 0m3 0h1.125c.621 0 1.125-.504 1.125-1.125V14.25m-17.25 4.5v-9m17.25 9v-9m0 0H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V9.75M15 9.75l-3.75 3.75-3.75-3.75" />
  </svg>
);
const MapPinIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}><path strokeLinecap="round" strokeLinejoin="round" d="M15 10.5a3 3 0 11-6 0 3 3 0 016 0z" /><path strokeLinecap="round" strokeLinejoin="round" d="M19.5 10.5c0 7.142-7.5 11.25-7.5 11.25S4.5 17.642 4.5 10.5a7.5 7.5 0 1115 0z" /></svg>
);
const CreditCardIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}><path strokeLinecap="round" strokeLinejoin="round" d="M2.25 8.25h19.5M2.25 9h19.5m-16.5 5.25h6m-6 2.25h3m-3.75 3h15a2.25 2.25 0 002.25-2.25V6.75A2.25 2.25 0 0019.5 4.5h-15A2.25 2.25 0 002.25 6.75v10.5A2.25 2.25 0 004.5 19.5z" /></svg>
);
const ArrowPathIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}><path strokeLinecap="round" strokeLinejoin="round" d="M16.023 9.348h4.992v-.001M2.985 19.644v-4.992m0 0h4.992m-4.993 0l3.181 3.183a8.25 8.25 0 0011.667 0l3.182-3.182m0-4.991v4.99" /></svg>
);
const DocumentArrowDownIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}><path strokeLinecap="round" strokeLinejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 00-3.375-3.375h-1.5A1.125 1.125 0 0113.5 7.125v-1.5a3.375 3.375 0 00-3.375-3.375H8.25m.75 12l3 3m0 0l3-3m-3 3v-6m-1.5-9H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 00-9-9z" /></svg>
);

// --- SUB COMPONENTS ---

const ProgressTracker: React.FC<{ status: Order['status'], statusUpdates: Order['statusUpdates'] }> = ({ status, statusUpdates }) => {
    const steps = [
        { name: 'Processing', date: statusUpdates.processingDate, icon: CheckCircleIcon },
        { name: 'Shipped', date: statusUpdates.shippedDate, icon: TruckIcon },
        { name: 'Delivered', date: statusUpdates.deliveredDate, icon: CheckCircleIcon }
    ];
    const currentStepIndex = status === 'Processing' ? 0 : status === 'Shipped' ? 1 : 2;

    return (
        <div className="w-full">
            <div className="flex justify-between items-start relative">
                <div className="absolute left-0 top-5 w-full h-0.5 bg-gray-200 dark:bg-gray-700"></div>
                <div 
                    className="absolute left-0 top-5 h-0.5 bg-brand-secondary transition-all duration-500" 
                    style={{width: `${(currentStepIndex / (steps.length - 1)) * 100}%`}}>
                </div>
                {steps.map((step, index) => {
                    const isActive = index <= currentStepIndex;
                    const Icon = step.icon;
                    return (
                        <div key={step.name} className="z-10 text-center w-24">
                            <div className={`w-10 h-10 rounded-full flex items-center justify-center mx-auto transition-colors duration-300 ${isActive ? 'bg-brand-secondary' : 'bg-gray-200 dark:bg-gray-600 border-2 border-white dark:border-gray-800'}`}>
                                <Icon className={`w-6 h-6 ${isActive ? 'text-brand-dark' : 'text-gray-400'}`} />
                            </div>
                            <p className={`mt-2 text-xs font-semibold ${isActive ? 'text-brand-dark dark:text-white' : 'text-gray-500 dark:text-gray-400'}`}>{step.name}</p>
                            {isActive && step.date && <p className="text-xs text-gray-500 dark:text-gray-400">{new Date(step.date).toLocaleDateString()}</p>}
                        </div>
                    );
                })}
            </div>
        </div>
    );
};

const DetailCard: React.FC<{ icon: React.FC<any>, title: string, children: React.ReactNode }> = ({ icon: Icon, title, children }) => (
    <div className="flex items-start gap-4">
        <div className="flex-shrink-0 bg-brand-secondary/50 p-3 rounded-full">
            <Icon className="w-5 h-5 text-brand-dark" />
        </div>
        <div>
            <h5 className="font-semibold text-gray-500 dark:text-gray-400 text-sm">{title}</h5>
            <div className="text-sm text-gray-800 dark:text-gray-200">{children}</div>
        </div>
    </div>
);


const OrderItem: React.FC<{ order: Order, startOpen?: boolean }> = ({ order, startOpen = false }) => {
    const [isOpen, setIsOpen] = useState(startOpen);
    const { addToCart, toggleCart } = useCart();

    const statusColor = {
        Processing: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/50 dark:text-yellow-300',
        Shipped: 'bg-blue-100 text-blue-800 dark:bg-blue-900/50 dark:text-blue-300',
        Delivered: 'bg-green-100 text-green-800 dark:bg-green-900/50 dark:text-green-300',
    };

    const handleReorder = (e: React.MouseEvent) => {
        e.stopPropagation();
        order.items.forEach(item => {
            const product = PRODUCTS.find(p => p.id === item.id);
            if (product) {
              addToCart(product, item.quantity);
            }
        });
        toggleCart();
    };

    return (
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md border border-gray-200 dark:border-gray-700">
            <button 
                className="w-full p-4 text-left hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors"
                onClick={() => setIsOpen(!isOpen)}
                aria-expanded={isOpen}
                aria-controls={`order-details-${order.id}`}
            >
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 items-center">
                    <div>
                        <p className="text-xs text-gray-500 dark:text-gray-400">Order ID</p>
                        <p className="font-bold text-brand-dark dark:text-white break-all">{order.id}</p>
                    </div>
                    <div>
                        <p className="text-xs text-gray-500 dark:text-gray-400">Date Placed</p>
                        <p className="font-medium dark:text-gray-300">{new Date(order.date).toLocaleDateString()}</p>
                    </div>
                    <div>
                        <p className="text-xs text-gray-500 dark:text-gray-400">Total</p>
                        <p className="font-bold text-lg text-brand-primary dark:text-brand-secondary">Ksh {order.total.toLocaleString(undefined, {minimumFractionDigits: 2})}</p>
                    </div>
                    <div className="flex justify-between items-center">
                        <span className={`text-xs font-bold px-3 py-1 rounded-full ${statusColor[order.status]}`}>
                            {order.status}
                        </span>
                        <ChevronDownIcon className={`w-6 h-6 text-gray-500 dark:text-gray-300 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
                    </div>
                </div>
            </button>
            
            <div id={`order-details-${order.id}`} className={`transition-all duration-500 ease-in-out grid ${isOpen ? 'grid-rows-[1fr] opacity-100' : 'grid-rows-[0fr] opacity-0'}`}>
                <div className="overflow-hidden">
                    <div className="p-6 border-t dark:border-gray-700 bg-gray-50/50 dark:bg-gray-900/20">
                        {order.status !== 'Delivered' && order.estimatedDelivery && (
                             <div className="text-center mb-6 bg-blue-100 p-3 rounded-lg border border-blue-200 dark:bg-blue-900/50 dark:text-blue-200 dark:border-blue-800">
                                <p className="font-semibold text-blue-800 dark:text-blue-200">Estimated Delivery: {new Date(order.estimatedDelivery).toLocaleDateString()}</p>
                            </div>
                        )}
                        <div className="mb-8">
                            <ProgressTracker status={order.status} statusUpdates={order.statusUpdates} />
                        </div>

                        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                            <div className="lg:col-span-2">
                                <h4 className="font-semibold text-lg mb-4 text-brand-dark dark:text-white">Items ({order.items.reduce((acc, i) => acc + i.quantity, 0)})</h4>
                                <div className="space-y-4">
                                    {order.items.map(item => (
                                        <div key={item.id} className="flex items-center gap-4 bg-white dark:bg-gray-800 p-3 rounded-md border dark:border-gray-700">
                                            <img src={item.images[0]} alt={item.name} className="w-16 h-16 object-cover rounded-md flex-shrink-0" />
                                            <div className="flex-grow">
                                                <NavLink to={`/products/${item.id}`} className="font-semibold text-sm hover:text-brand-primary dark:hover:text-brand-secondary transition-colors dark:text-white">{item.name}</NavLink>
                                                <p className="text-xs text-gray-500 dark:text-gray-400">Qty: {item.quantity} &times; Ksh {item.price.toLocaleString()}</p>
                                            </div>
                                            {order.status === 'Delivered' && (
                                                <NavLink to={`/products/${item.id}#reviews`} className="text-xs font-semibold text-brand-primary dark:text-brand-secondary hover:underline whitespace-nowrap">
                                                    Leave a Review
                                                </NavLink>
                                            )}
                                        </div>
                                    ))}
                                </div>
                            </div>

                            <div className="space-y-6">
                                <div>
                                    <h4 className="font-semibold text-lg mb-4 text-brand-dark dark:text-white">Details</h4>
                                    <div className="space-y-4">
                                        <DetailCard icon={MapPinIcon} title="Shipping Address">
                                            <p className="font-bold">{order.shippingAddress.name}</p>
                                            <p>{order.shippingAddress.address}</p>
                                            <p>{order.shippingAddress.city}, {order.shippingAddress.postalCode}</p>
                                        </DetailCard>
                                        <DetailCard icon={CreditCardIcon} title="Payment Method">
                                            <p>{order.paymentMethod}</p>
                                        </DetailCard>
                                        {order.trackingNumber && (
                                             <DetailCard icon={TruckIcon} title="Tracking Number">
                                                <p className="font-mono text-sm">{order.trackingNumber}</p>
                                                <button onClick={() => alert('Feature coming soon!')} className="text-xs font-semibold text-brand-primary dark:text-brand-secondary hover:underline mt-1">Track Package</button>
                                            </DetailCard>
                                        )}
                                    </div>
                                </div>
                                <div className="bg-white dark:bg-gray-800 p-4 rounded-md border dark:border-gray-700">
                                    <h4 className="font-semibold text-lg mb-2 text-brand-dark dark:text-white">Order Summary</h4>
                                    <div className="space-y-1 text-sm">
                                        <div className="flex justify-between text-gray-600 dark:text-gray-300"><span>Subtotal</span> <span>Ksh {order.subtotal.toLocaleString(undefined, {minimumFractionDigits: 2})}</span></div>
                                        <div className="flex justify-between text-gray-600 dark:text-gray-300"><span>Shipping</span> <span>Ksh {order.shippingCost.toLocaleString(undefined, {minimumFractionDigits: 2})}</span></div>
                                        <div className="flex justify-between text-gray-600 dark:text-gray-300"><span>Tax (16%)</span> <span>Ksh {order.tax.toLocaleString(undefined, {minimumFractionDigits: 2})}</span></div>
                                        {order.discount > 0 && <div className="flex justify-between text-green-600"><span>Discount</span> <span>-Ksh {order.discount.toLocaleString(undefined, {minimumFractionDigits: 2})}</span></div>}
                                        <div className="flex justify-between font-bold text-brand-dark dark:text-white pt-2 border-t dark:border-gray-600 mt-2"><span>Total</span> <span>Ksh {order.total.toLocaleString(undefined, {minimumFractionDigits: 2})}</span></div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="mt-8 pt-6 border-t dark:border-gray-700 flex flex-wrap gap-4 justify-end">
                             <button onClick={() => alert('Feature coming soon!')} className="flex items-center gap-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-200 font-bold px-4 py-2 rounded-md hover:bg-gray-100 dark:hover:bg-gray-600 transition-colors text-sm">
                                <DocumentArrowDownIcon className="w-5 h-5"/> Download Invoice
                            </button>
                            <button onClick={handleReorder} className="flex items-center gap-2 bg-brand-secondary text-brand-dark font-bold px-4 py-2 rounded-md hover:bg-opacity-80 transition-colors text-sm">
                                <ArrowPathIcon className="w-5 h-5"/> Reorder
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

const RecommendedProductCard: React.FC<{product: Product}> = ({product}) => {
    const { addToCart } = useCart();
    return (
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md dark:border dark:border-gray-700 overflow-hidden group flex flex-col">
            <NavLink to={`/products/${product.id}`} className="block">
                <img src={product.images[0]} alt={product.name} className="w-full h-48 object-cover" />
            </NavLink>
            <div className="p-4 flex-grow flex flex-col">
                <h3 className="text-md font-semibold text-brand-dark dark:text-brand-light mb-2 flex-grow">
                    <NavLink to={`/products/${product.id}`} className="hover:text-brand-primary dark:hover:text-brand-secondary transition-colors">{product.name}</NavLink>
                </h3>
                <div className="mt-auto pt-2">
                    <p className="font-bold text-brand-primary dark:text-brand-secondary">Ksh {product.price.toLocaleString()}</p>
                    <button onClick={() => addToCart(product)} className="w-full mt-2 bg-brand-secondary text-brand-dark font-bold px-4 py-2 rounded-md hover:bg-opacity-80 transition-colors text-sm">
                        Add to Cart
                    </button>
                </div>
            </div>
        </div>
    );
};

const TrackOrderPage: React.FC = () => {
    const { isAuthenticated, openAuthModal } = useAuth();
    const { orders } = useOrder();
    
    // State for guest tracking
    const [trackId, setTrackId] = useState('');
    const [trackEmail, setTrackEmail] = useState('');
    const [searchedOrder, setSearchedOrder] = useState<Order | null>(null);
    const [searchError, setSearchError] = useState('');
    const [isSearching, setIsSearching] = useState(false);
    
    useEffect(() => {
        window.scrollTo(0, 0);
    }, []);

    const handleTrackSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        setIsSearching(true);
        setSearchedOrder(null);
        setSearchError('');

        // Simulate API search
        setTimeout(() => {
            const foundOrder = MOCK_ORDERS.find(
                o => o.id.toLowerCase() === trackId.trim().toLowerCase() && 
                     o.userEmail.toLowerCase() === trackEmail.trim().toLowerCase()
            );
            
            if (foundOrder) {
                setSearchedOrder(foundOrder);
            } else {
                setSearchError('No order found with that ID and email combination. Please check your details and try again.');
            }
            setIsSearching(false);
        }, 1000);
    };

    const recommendedProducts = useMemo(() => {
        const orderedProductIds = new Set(orders.flatMap(o => o.items.map(i => i.id)));
        return PRODUCTS.filter(p => !orderedProductIds.has(p.id)).slice(0, 4);
    }, [orders]);

    if (!isAuthenticated) {
        return (
            <div className="bg-gray-50 dark:bg-gray-900 py-16 min-h-[60vh]">
                <div className="container mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="max-w-2xl mx-auto">
                        <div className="text-center mb-12">
                            <h1 className="text-4xl font-serif font-bold text-brand-dark dark:text-brand-light">Track Your Order</h1>
                            <p className="text-lg text-gray-600 dark:text-gray-300 mt-2">Enter your order details to see its status.</p>
                        </div>
                        <div className="bg-white dark:bg-gray-800 p-8 rounded-lg shadow-xl border dark:border-gray-700">
                            <form onSubmit={handleTrackSubmit} className="space-y-4">
                                <div>
                                    <label htmlFor="trackId" className="block text-sm font-medium text-gray-700 dark:text-gray-200">Order ID</label>
                                    <input type="text" name="trackId" id="trackId" value={trackId} onChange={e => setTrackId(e.target.value)} placeholder="e.g. SH-1004" required className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-brand-primary focus:border-brand-primary dark:bg-gray-700 dark:border-gray-600 dark:text-gray-200" />
                                </div>
                                <div>
                                    <label htmlFor="trackEmail" className="block text-sm font-medium text-gray-700 dark:text-gray-200">Email Address</label>
                                    <input type="email" name="trackEmail" id="trackEmail" value={trackEmail} onChange={e => setTrackEmail(e.target.value)} placeholder="you@example.com" required className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-brand-primary focus:border-brand-primary dark:bg-gray-700 dark:border-gray-600 dark:text-gray-200" />
                                </div>
                                <button type="submit" disabled={isSearching} className="w-full flex justify-center py-3 px-4 border border-transparent rounded-md shadow-sm text-base font-medium text-white bg-brand-primary hover:bg-opacity-80 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-brand-primary disabled:bg-gray-400">
                                    {isSearching ? 'Searching...' : 'Track Order'}
                                </button>
                            </form>
                            <p className="text-center text-sm text-gray-600 dark:text-gray-400 mt-6">
                                Have an account?{' '}
                                <button onClick={openAuthModal} className="font-semibold text-brand-primary dark:text-brand-secondary hover:underline">
                                    Log in
                                </button>
                                {' '}to see your full order history.
                            </p>
                        </div>
                        
                        <div className="mt-8">
                            {searchError && <p className="text-center text-red-500 bg-red-100 dark:bg-red-900/50 dark:text-red-300 p-3 rounded-md">{searchError}</p>}
                            {searchedOrder && <OrderItem order={searchedOrder} startOpen={true} />}
                        </div>
                    </div>
                </div>
            </div>
        );
    }
    
    return (
        <div className="bg-gray-50 dark:bg-gray-900 py-12 min-h-[60vh]">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8">
                <div className="text-center mb-12">
                    <h1 className="text-4xl font-serif font-bold text-brand-dark dark:text-brand-light">My Orders</h1>
                    <p className="text-lg text-gray-600 dark:text-gray-300 mt-2">Track your current and past orders.</p>
                </div>
                
                {orders.length > 0 ? (
                    <div className="space-y-6 max-w-5xl mx-auto">
                        {orders.map(order => (
                            <OrderItem key={order.id} order={order} />
                        ))}
                    </div>
                ) : (
                    <div className="text-center py-20 bg-white dark:bg-gray-800 rounded-lg shadow-md max-w-2xl mx-auto">
                        <p className="text-xl text-gray-600 dark:text-gray-300 mb-6">You haven't placed any orders yet.</p>
                        <NavLink to="/products" className="bg-brand-primary text-white font-bold py-3 px-8 rounded-md hover:bg-opacity-80 transition-colors">
                            Start Shopping
                        </NavLink>
                    </div>
                )}
                
                {recommendedProducts.length > 0 && (
                    <div className="mt-20">
                        <h2 className="text-2xl font-bold font-serif text-center mb-8 dark:text-white">You Might Also Like</h2>
                        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 max-w-6xl mx-auto">
                           {recommendedProducts.map(p => <RecommendedProductCard key={p.id} product={p}/>)}
                        </div>
                    </div>
                )}

            </div>
        </div>
    );
};

export default TrackOrderPage;