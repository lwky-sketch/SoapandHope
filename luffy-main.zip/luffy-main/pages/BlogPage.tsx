import React, { useEffect, useState, useMemo } from 'react';
import { NavLink } from 'react-router-dom';
import { BLOG_POSTS, BLOG_CATEGORIES } from '../constants';
import { BlogPost } from '../types';

// New component for tags
const Tag: React.FC<{ tag: string }> = ({ tag }) => (
    <span className="inline-block bg-brand-secondary/20 text-brand-primary text-xs font-semibold mr-2 px-2.5 py-0.5 rounded-full">
        {tag}
    </span>
);

// New Featured Post Card
const FeaturedBlogCard: React.FC<{ post: BlogPost }> = ({ post }) => (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg overflow-hidden group transition-shadow hover:shadow-xl md:flex mb-12">
        <div className="md:w-3/5">
            <NavLink to={`/blog/${post.id}`} className="block h-full">
                <img src={post.image} alt={post.title} className="w-full h-64 md:h-full object-cover" />
            </NavLink>
        </div>
        <div className="p-6 md:p-8 md:w-2/5 flex flex-col">
            <div>
                <div className="mb-2">
                    {post.tags.map(tag => <Tag key={tag} tag={tag} />)}
                </div>
                <p className="text-sm text-gray-500 dark:text-gray-400 mb-2">{post.date} &bull; by {post.author}</p>
                <h2 className="text-3xl font-semibold font-serif text-brand-dark dark:text-white mb-3">
                    <NavLink to={`/blog/${post.id}`} className="hover:text-brand-primary dark:hover:text-brand-secondary transition-colors">{post.title}</NavLink>
                </h2>
                <p className="text-gray-600 dark:text-gray-300 mb-4 leading-relaxed">{post.summary}</p>
            </div>
            <div className="mt-auto">
                <NavLink to={`/blog/${post.id}`} className="font-bold text-brand-primary dark:text-brand-secondary hover:underline">
                    Read More &rarr;
                </NavLink>
            </div>
        </div>
    </div>
);

// Updated regular Blog Card
const BlogCard: React.FC<{ post: BlogPost }> = ({ post }) => (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg overflow-hidden group transition-transform transform hover:-translate-y-2 flex flex-col">
        <NavLink to={`/blog/${post.id}`} className="block">
            <img src={post.image} alt={post.title} className="w-full h-56 object-cover" />
        </NavLink>
        <div className="p-6 flex flex-col flex-grow">
            <div className="mb-3">
                {post.tags.map(tag => <Tag key={tag} tag={tag} />)}
            </div>
            <p className="text-sm text-gray-500 dark:text-gray-400 mb-2">{post.date}</p>
            <h2 className="text-xl font-semibold font-serif text-brand-dark dark:text-white mb-3 flex-grow">
                <NavLink to={`/blog/${post.id}`} className="hover:text-brand-primary dark:hover:text-brand-secondary transition-colors">{post.title}</NavLink>
            </h2>
            <div className="mt-auto">
                <NavLink to={`/blog/${post.id}`} className="font-bold text-brand-primary dark:text-brand-secondary hover:underline">
                    Read More &rarr;
                </NavLink>
            </div>
        </div>
    </div>
);

const BlogPage: React.FC = () => {
    const [activeCategory, setActiveCategory] = useState('All');

    useEffect(() => {
        window.scrollTo(0, 0);
    }, []);
    
    // Assuming the latest post is the first one in the array
    const featuredPost = BLOG_POSTS[0];
    const otherPosts = BLOG_POSTS.slice(1);

    const filteredPosts = useMemo(() => {
        if (activeCategory === 'All') {
            return otherPosts;
        }
        return otherPosts.filter(post => post.tags.includes(activeCategory));
    }, [activeCategory, otherPosts]);

    const filterButtonClasses = (category: string) => 
        `px-4 py-2 rounded-full font-medium transition-colors duration-200 ${
            activeCategory === category 
            ? 'bg-brand-primary text-white shadow' 
            : 'bg-white text-gray-700 hover:bg-gray-100 dark:bg-gray-700 dark:text-gray-200 dark:hover:bg-gray-600'
        }`;

    return (
        <div className="bg-brand-light dark:bg-gray-900 py-16">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8">
                <div className="text-center mb-12">
                    <h1 className="text-4xl md:text-5xl font-serif font-bold text-brand-dark dark:text-brand-light">The Soap & Hope Blog</h1>
                    <p className="text-lg text-gray-600 dark:text-gray-300 mt-4 max-w-2xl mx-auto">Cleaning tips, product spotlights, and sustainability content from our team of experts.</p>
                </div>

                {/* Featured Post */}
                <FeaturedBlogCard post={featuredPost} />

                {/* Filters */}
                <div className="mb-10 text-center">
                    <div className="inline-flex flex-wrap items-center justify-center gap-2 p-2 bg-gray-200/50 dark:bg-gray-800 rounded-full">
                         <button onClick={() => setActiveCategory('All')} className={filterButtonClasses('All')}>
                            All Posts
                        </button>
                        {BLOG_CATEGORIES.map(category => (
                            <button key={category} onClick={() => setActiveCategory(category)} className={filterButtonClasses(category)}>
                                {category}
                            </button>
                        ))}
                    </div>
                </div>

                {/* Other Posts Grid */}
                {filteredPosts.length > 0 ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                        {filteredPosts.map(post => (
                            <BlogCard key={post.id} post={post} />
                        ))}
                    </div>
                ) : (
                    <div className="text-center py-16 bg-white dark:bg-gray-800 rounded-lg shadow-md">
                        <p className="text-xl text-gray-600 dark:text-gray-300 font-semibold">No posts found in this category.</p>
                        <p className="text-gray-500 dark:text-gray-400 mt-2">Try selecting another category.</p>
                    </div>
                )}
            </div>
        </div>
    );
};

export default BlogPage;
