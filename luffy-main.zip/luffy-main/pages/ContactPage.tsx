import React, { useEffect, useState } from 'react';
import { NavLink } from 'react-router-dom';
import QRCode from '../components/QRCode';

const PhoneIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 6.75c0 8.284 6.716 15 15 15h2.25a2.25 2.25 0 002.25-2.25v-1.372c0-.516-.351-.966-.852-1.091l-4.423-1.106c-.44-.11-.902.055-1.173.417l-.97 1.293c-.282.376-.769.542-1.21.38a12.035 12.035 0 01-7.143-7.143c-.162-.441.004-.928.38-1.21l1.293-.97c.363-.271.527-.734.417-1.173L6.963 3.102a1.125 1.125 0 00-1.091-.852H4.5A2.25 2.25 0 002.25 4.5v2.25z" />
  </svg>
);

const EnvelopeIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M21.75 6.75v10.5a2.25 2.25 0 01-2.25-2.25h-15a2.25 2.25 0 01-2.25-2.25V6.75m19.5 0A2.25 2.25 0 0019.5 4.5h-15a2.25 2.25 0 00-2.25 2.25m19.5 0v.243a2.25 2.25 0 01-1.07 1.916l-7.5 4.615a2.25 2.25 0 01-2.36 0L3.32 8.91a2.25 2.25 0 01-1.07-1.916V6.75" />
  </svg>
);

const MapPinIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M15 10.5a3 3 0 11-6 0 3 3 0 016 0z" />
        <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 10.5c0 7.142-7.5 11.25-7.5 11.25S4.5 17.642 4.5 10.5a7.5 7.5 0 1115 0z" />
    </svg>
);

const ChevronDownIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 8.25l-7.5 7.5-7.5-7.5" />
    </svg>
);

const FacebookIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg fill="currentColor" viewBox="0 0 24 24" {...props}><path d="M22 12c0-5.52-4.48-10-10-10S2 6.48 2 12c0 4.84 3.44 8.87 8 9.8V15H8v-3h2V9.5C10 7.57 11.57 6 13.5 6H16v3h-2c-.55 0-1 .45-1 1v2h3l-.5 3h-2.5v6.8c4.56-.93 8-4.96 8-9.8z"/></svg>
);

const TwitterIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg fill="currentColor" viewBox="0 0 24 24" {...props}><path d="M22.46 6c-.77.35-1.6.58-2.46.67.88-.53 1.56-1.37 1.88-2.38-.83.49-1.75.85-2.72 1.05C18.37 4.5 17.26 4 16 4c-2.35 0-4.27 1.92-4.27 4.29 0 .34.04.67.11.98-3.56-.18-6.73-1.89-8.84-4.48-.37.63-.58 1.37-.58 2.15 0 1.49.76 2.81 1.91 3.58-.7-.02-1.37-.21-1.95-.5v.03c0 2.08 1.48 3.82 3.44 4.21-.36.1-.74.15-1.14.15-.28 0-.55-.03-.81-.08.55 1.7 2.14 2.94 4.03 2.97-1.47 1.15-3.33 1.84-5.35 1.84-.35 0-.69-.02-1.03-.06 1.9 1.23 4.16 1.94 6.58 1.94 7.9 0 12.23-6.54 12.23-12.23 0-.19 0-.37-.01-.56.84-.6 1.56-1.36 2.14-2.22z"/></svg>
);

const InstagramIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg fill="currentColor" viewBox="0 0 24 24" {...props}><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.85s-.012 3.584-.07 4.85c-.148 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07s-3.584-.012-4.85-.07c-3.252-.148-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.85s.012-3.584.07-4.85c.148-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.85-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948s.014 3.667.072 4.947c.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072s3.667-.014 4.947-.072c4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.947s-.014-3.667-.072-4.947c-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.072-4.948-.072zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.162 6.162 6.162 6.162-2.759 6.162-6.162-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4s1.791-4 4-4 4 1.79 4 4-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/></svg>
);

const faqItems: { question: string; answer: React.ReactNode }[] = [
    { question: "What are your shipping options?", answer: "We offer standard (3-5 business days) and express (1-2 business days) shipping options nationwide. Shipping costs are calculated at checkout based on your location and order size." },
    { 
        question: "What is your return policy?", 
        answer: (
            <>
                We accept returns within 42 hours of delivery for unopened and unused products. For a complete overview of the process and eligibility, please see our full{' '}
                <NavLink to="/return-policy" className="text-brand-primary dark:text-brand-secondary hover:underline">Return Policy page</NavLink>.
            </>
        ) 
    },
    { question: "Are your products safe for sensitive skin?", answer: "Yes! Many of our products are formulated specifically for sensitive skin, using natural, plant-based ingredients and avoiding harsh chemicals. Look for the 'Sensitive Skin Friendly' badge on product pages." },
    { question: "How does the loyalty program work?", answer: "It's simple! For every 6 products you purchase, you get the 7th one free (the most expensive item in your cart on that 7th purchase). Progress is tracked automatically, no sign-up needed." },
    { question: "Do you offer wholesale or bulk pricing?", answer: "Absolutely. We love partnering with other businesses. Please send us an inquiry through our contact form with the subject 'Wholesale Inquiry' or email partners@soapandhope.com for more information." }
];

const FAQItem: React.FC<{ item: typeof faqItems[0]; isOpen: boolean; onClick: () => void }> = ({ item, isOpen, onClick }) => {
    return (
        <div className="border-b dark:border-gray-700">
            <button
                className="w-full flex justify-between items-center text-left py-4"
                onClick={onClick}
                aria-expanded={isOpen}
            >
                <span className="text-lg font-medium text-brand-dark dark:text-white">{item.question}</span>
                <ChevronDownIcon className={`w-6 h-6 text-brand-primary transition-transform ${isOpen ? 'rotate-180' : ''}`} />
            </button>
            <div className={`overflow-hidden transition-all duration-300 ease-in-out ${isOpen ? 'max-h-96' : 'max-h-0'}`}>
                <div className="p-4 pt-0 text-gray-600 dark:text-gray-300">
                    {item.answer}
                </div>
            </div>
        </div>
    );
};


const ContactPage: React.FC = () => {
    const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(null);
    const [formState, setFormState] = useState({ name: '', email: '', subject: '', message: '' });
    const [formStatus, setFormStatus] = useState<'idle' | 'sending' | 'success' | 'error'>('idle');

    useEffect(() => {
        window.scrollTo(0, 0);
    }, []);

    const handleFaqClick = (index: number) => {
        setOpenFaqIndex(openFaqIndex === index ? null : index);
    };

    const handleFormChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
        setFormState({ ...formState, [e.target.name]: e.target.value });
    };

    const handleFormSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        setFormStatus('sending');
        console.log('Form data submitted:', formState);

        // Simulate API call
        setTimeout(() => {
            setFormStatus('success');
            setFormState({ name: '', email: '', subject: '', message: '' });
            setTimeout(() => setFormStatus('idle'), 5000);
        }, 1500);
    };

    return (
        <div className="bg-gray-50 dark:bg-gray-900">
            <div className="relative bg-brand-primary/10 dark:bg-brand-dark h-64">
                <img src="https://picsum.photos/seed/contact/1920/400" alt="Abstract background" className="absolute inset-0 w-full h-full object-cover opacity-20"/>
                <div className="absolute inset-0 flex items-center justify-center">
                    <div className="text-center">
                        <h1 className="text-4xl md:text-5xl font-serif font-bold text-brand-dark dark:text-brand-light">Contact Us</h1>
                        <p className="mt-2 text-lg text-gray-700 dark:text-gray-300">We're here to help and answer any question you might have.</p>
                    </div>
                </div>
            </div>

            <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:-mt-20 -mt-16">
                <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl p-8 md:p-12">
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
                         {/* Contact Form */}
                        <div>
                            <h2 className="text-3xl font-serif font-bold text-brand-dark dark:text-brand-light mb-6">Send Us a Message</h2>
                            {formStatus === 'success' ? (
                                <div className="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 rounded-md h-full flex flex-col justify-center">
                                    <p className="font-bold">Message Sent!</p>
                                    <p>Thank you for reaching out. We'll get back to you as soon as possible.</p>
                                </div>
                            ) : (
                                <form onSubmit={handleFormSubmit} className="space-y-4">
                                    <div>
                                        <label htmlFor="name" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Full Name</label>
                                        <input type="text" name="name" id="name" value={formState.name} onChange={handleFormChange} required className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-brand-primary focus:border-brand-primary dark:bg-gray-700 dark:border-gray-600 dark:text-gray-200" />
                                    </div>
                                    <div>
                                        <label htmlFor="email" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Email Address</label>
                                        <input type="email" name="email" id="email" value={formState.email} onChange={handleFormChange} required className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-brand-primary focus:border-brand-primary dark:bg-gray-700 dark:border-gray-600 dark:text-gray-200" />
                                    </div>
                                    <div>
                                        <label htmlFor="subject" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Subject</label>
                                        <select name="subject" id="subject" value={formState.subject} onChange={handleFormChange} required className="mt-1 block w-full px-3 py-2 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-brand-primary focus:border-brand-primary dark:bg-gray-700 dark:border-gray-600 dark:text-gray-200">
                                            <option value="" disabled>Select an inquiry type</option>
                                            <option>General Question</option>
                                            <option>Order Issue</option>
                                            <option>Product Feedback</option>
                                            <option>Wholesale Inquiry</option>
                                            <option>Other</option>
                                        </select>
                                    </div>
                                    <div>
                                        <label htmlFor="message" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Message</label>
                                        <textarea name="message" id="message" rows={5} value={formState.message} onChange={handleFormChange} required className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-brand-primary focus:border-brand-primary dark:bg-gray-700 dark:border-gray-600 dark:text-gray-200"></textarea>
                                    </div>
                                    <div>
                                        <button type="submit" disabled={formStatus === 'sending'} className="w-full flex justify-center py-3 px-4 border border-transparent rounded-md shadow-sm text-base font-medium text-white bg-brand-primary hover:bg-opacity-80 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-brand-primary disabled:bg-gray-400">
                                            {formStatus === 'sending' ? 'Sending...' : 'Submit'}
                                        </button>
                                    </div>
                                </form>
                            )}
                        </div>
                        {/* Contact Information */}
                        <div>
                            <h2 className="text-3xl font-serif font-bold text-brand-dark dark:text-brand-light mb-6">Contact Information</h2>
                            <p className="text-gray-600 dark:text-gray-300 mb-8 leading-relaxed">
                                You can also reach us through the channels below. We look forward to hearing from you!
                            </p>
                            <div className="space-y-6">
                                <div className="flex items-start gap-4">
                                    <div className="flex-shrink-0 bg-brand-secondary p-3 rounded-full">
                                        <MapPinIcon className="w-6 h-6 text-brand-dark" />
                                    </div>
                                    <div>
                                        <h3 className="text-lg font-semibold text-brand-dark dark:text-white">Our Office</h3>
                                        <p className="text-gray-600 dark:text-gray-300">123 Clean Avenue, Green Park<br/>Nairobi, Kenya</p>
                                    </div>
                                </div>
                                <div className="flex items-start gap-4">
                                    <div className="flex-shrink-0 bg-brand-secondary p-3 rounded-full">
                                        <PhoneIcon className="w-6 h-6 text-brand-dark" />
                                    </div>
                                    <div>
                                        <h3 className="text-lg font-semibold text-brand-dark dark:text-white">Phone</h3>
                                        <a href="tel:0716446845" className="text-brand-primary dark:text-brand-secondary font-medium hover:underline">
                                            0716446845
                                        </a>
                                        <p className="text-sm text-gray-500 dark:text-gray-400">Mon - Fri, 9am - 5pm</p>
                                    </div>
                                </div>
                                <div className="flex items-start gap-4">
                                    <div className="flex-shrink-0 bg-brand-secondary p-3 rounded-full">
                                        <EnvelopeIcon className="w-6 h-6 text-brand-dark" />
                                    </div>
                                    <div>
                                        <h3 className="text-lg font-semibold text-brand-dark dark:text-white">Email</h3>
                                        <p><a href="mailto:hello@soapandhope.com" className="text-brand-primary dark:text-brand-secondary font-medium hover:underline">hello@soapandhope.com</a> (General)</p>
                                        <p><a href="mailto:orders@soapandhope.com" className="text-brand-primary dark:text-brand-secondary font-medium hover:underline">orders@soapandhope.com</a> (Support)</p>
                                    </div>
                                </div>
                            </div>
                            <div className="mt-8 pt-8 border-t border-gray-200 dark:border-gray-700">
                                <h3 className="text-lg font-semibold text-brand-dark dark:text-white mb-3">Find Us on Social</h3>
                                <div className="flex items-center space-x-4">
                                    <a href="https://facebook.com" target="_blank" rel="noopener noreferrer" aria-label="Facebook page" className="text-gray-500 dark:text-gray-400 hover:text-[#1877F2] transition-colors"><FacebookIcon className="h-7 w-7" /></a>
                                    <a href="https://twitter.com" target="_blank" rel="noopener noreferrer" aria-label="Twitter page" className="text-gray-500 dark:text-gray-400 hover:text-[#1DA1F2] transition-colors"><TwitterIcon className="h-7 w-7" /></a>
                                    <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" aria-label="Instagram page" className="text-gray-500 dark:text-gray-400 hover:text-[#E1306C] transition-colors"><InstagramIcon className="h-7 w-7" /></a>
                                </div>
                            </div>
                            <div className="mt-8 pt-8 border-t border-gray-200 dark:border-gray-700">
                                <h3 className="text-lg font-semibold text-brand-dark dark:text-white mb-4">Share This Page</h3>
                                <QRCode />
                            </div>
                        </div>
                    </div>
                </div>

                {/* FAQ Section */}
                <div className="mt-20">
                    <h2 className="text-3xl font-serif font-bold text-brand-dark dark:text-brand-light text-center mb-10">Frequently Asked Questions</h2>
                    <div className="max-w-3xl mx-auto bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6">
                        {faqItems.map((item, index) => (
                           <FAQItem 
                                key={index}
                                item={item}
                                isOpen={openFaqIndex === index}
                                onClick={() => handleFaqClick(index)}
                           />
                        ))}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default ContactPage;