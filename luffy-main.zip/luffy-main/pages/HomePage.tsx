import React, { useState, useEffect } from 'react';
import { NavLink } from 'react-router-dom';
import { HERO_SLIDES, CATEGORIES, PRODUCTS, REVIEWS, BLOG_POSTS } from '../constants';
import { useCart } from '../context/CartContext';
import { useWishlist } from '../context/WishlistContext';
import StarRating from '../components/StarRating';
import LoyaltyTracker from '../components/LoyaltyTracker';

// --- ICONS ---
const GlobeAltIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}><path strokeLinecap="round" strokeLinejoin="round" d="M12 21a9 9 0 100-18 9 9 0 000 18z" /><path strokeLinecap="round" strokeLinejoin="round" d="M19.5 12a7.5 7.5 0 11-15 0 7.5 7.5 0 0115 0z" /></svg>
);
const PawIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}><path strokeLinecap="round" strokeLinejoin="round" d="M20.828 7.643A8.966 8.966 0 0012 4.5c-2.06 0-4.012.68-5.594 1.892.23.633.39 1.3.497 2.002.107.702.164 1.42.164 2.155 0 2.29-.49 4.45-1.378 6.425a1 1 0 01-1.6-.825c.04-.32.063-.645.063-.975 0-1.886-.54-3.66-1.5-5.25a1 1 0 00-1.74-.03C3.6 13.06 3 15.45 3 18c0 .54.02 1.07.06 1.59.03.43.34.78.75.82.41.04.78-.23.89-.63.09-.33.15-.67.15-1.03 0-1.3.2-2.5.6-3.6a1 1 0 011.83.8c-.3 1-.5 2-.6 3.1a1 1 0 001.99.2c.1-.8.3-1.6.6-2.3.3-.8.7-1.5 1.2-2.1a1 1 0 011.62.75c-.1.35-.2.7-.3 1.1-.1.3-.2.6-.2.9a1 1 0 002 0c0-.6.1-1.2.3-1.8.2-.6.4-1.2.7-1.7a1 1 0 011.65.65c-.1.3-.2.6-.3.9-.1.3-.1.7-.1 1a1 1 0 002 0c0-.6.1-1.2.2-1.7.1-.6.3-1.1.5-1.6a1 1 0 011.75.45c0 2.8-2.6 5.1-5.8 5.1-1.2 0-2.3-.3-3.3-.9a1 1 0 01-.4-1.35c.4-.8.7-1.7.8-2.6.2-1 .2-2 .2-3.1 0-.7-.05-1.4-.15-2.1-.1-.7-.26-1.3-.5-1.9z" /></svg>
);
const GiftIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M21 11.25v8.25a1.5 1.5 0 01-1.5 1.5H5.25a1.5 1.5 0 01-1.5-1.5v-8.25M12 4.875A2.625 2.625 0 109.375 7.5H12m0-2.625V7.5m0-2.625A2.625 2.625 0 1114.625 7.5H12m0 0V21m-8.625-9.75h18c.621 0 1.125-.504 1.125-1.125v-1.5c0-.621-.504-1.125-1.125-1.125h-18c-.621 0-1.125.504-1.125 1.125v1.5c0 .621.504 1.125 1.125 1.125z" />
    </svg>
);


// --- Reusable Components defined outside Parent ---

const Hero: React.FC = () => {
    const [currentSlide, setCurrentSlide] = useState(0);

    useEffect(() => {
        const timer = setInterval(() => {
            setCurrentSlide((prev) => (prev + 1) % HERO_SLIDES.length);
        }, 5000);
        return () => clearInterval(timer);
    }, []);

    const slide = HERO_SLIDES[currentSlide];

    const buttonClasses = "bg-brand-primary text-white font-bold py-3 px-8 rounded-md hover:bg-opacity-80 transition-all transform hover:scale-105 inline-block";

    const renderButton = () => {
        if (slide.buttonLink.startsWith('#')) {
            return (
                <a href={slide.buttonLink} className={buttonClasses}>
                    {slide.buttonText}
                </a>
            );
        }
        return (
            <NavLink to={slide.buttonLink} className={buttonClasses}>
                {slide.buttonText}
            </NavLink>
        );
    };

    return (
        <div className="relative bg-brand-light dark:bg-gray-800 min-h-[60vh] md:min-h-[70vh] flex items-center">
            <div className="absolute inset-0">
                <img src={slide.image} alt={slide.title} className="w-full h-full object-cover opacity-20 dark:opacity-10" />
            </div>
            <div className="relative container mx-auto px-4 sm:px-6 lg:px-8 text-center z-10">
                <h1 className="text-4xl md:text-6xl font-serif font-bold text-brand-dark dark:text-brand-light mb-4 animate-fade-in-down">{slide.title}</h1>
                <p className="text-lg md:text-xl text-gray-700 dark:text-gray-300 max-w-2xl mx-auto mb-8 animate-fade-in-up">{slide.subtitle}</p>
                {renderButton()}
            </div>
        </div>
    );
};

const LoyaltyBanner: React.FC = () => (
    <div className="bg-brand-primary/10 dark:bg-brand-dark/20 py-12 sm:py-16">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-4xl mx-auto text-center">
                <h2 className="text-3xl font-serif font-bold text-brand-dark dark:text-brand-light mb-4">Track Your Loyalty Rewards</h2>
                <p className="text-gray-700 dark:text-gray-300 max-w-2xl mx-auto mb-8">
                    Every purchase brings you closer to a free product. See your progress below!
                </p>
                <div className="max-w-2xl mx-auto">
                    <LoyaltyTracker showTitle={false}/>
                </div>
                <div className="mt-8">
                    <NavLink 
                        to="/loyalty" 
                        className="bg-brand-primary text-white font-bold py-3 px-8 rounded-md hover:bg-opacity-80 transition-all transform hover:scale-105 inline-block"
                    >
                        Learn More About The Program
                    </NavLink>
                </div>
            </div>
        </div>
    </div>
);

const ParallaxSection: React.FC = () => (
    <div 
        className="relative py-20 sm:py-24 md:py-32 bg-cover bg-center bg-fixed" 
        style={{ backgroundImage: "url('https://images.unsplash.com/photo-1583947215259-38e34be8751f?q=80&w=2070&auto=format&fit=crop')" }}
        aria-label="A person wearing yellow gloves cleaning a soapy glass shower door with a squeegee"
    >
        <div className="absolute inset-0 bg-brand-dark/60"></div>
        <div className="relative container mx-auto px-4 sm:px-6 lg:px-8 text-center text-white z-10">
            <h2 className="text-4xl md:text-5xl font-serif font-bold mb-4 animate-fade-in-down" style={{animationDelay: '0.2s'}}>A Truly Deep Clean</h2>
            <p className="text-lg md:text-xl max-w-2xl mx-auto mb-8 animate-fade-in-up" style={{animationDelay: '0.4s'}}>
                Experience the power of nature. Our eco-friendly formulas leave your home sparkling, without the harsh chemicals.
            </p>
            <NavLink 
                to="/products" 
                className="bg-brand-primary text-white font-bold py-3 px-8 rounded-md hover:bg-opacity-80 transition-all transform hover:scale-105 inline-block animate-fade-in-up"
                style={{animationDelay: '0.6s'}}
            >
                Discover Our Products
            </NavLink>
        </div>
    </div>
);

const WhyChooseUs: React.FC = () => (
    <div className="bg-white dark:bg-gray-800 py-12 sm:py-16 lg:py-24">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <h2 className="text-3xl font-serif font-bold text-brand-dark dark:text-brand-light text-center mb-12">Clean You Can Trust</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto text-center">
                <div className="p-8">
                    <GlobeAltIcon className="w-12 h-12 text-brand-primary dark:text-brand-secondary mx-auto mb-4" />
                    <h3 className="text-xl font-semibold text-brand-dark dark:text-white mb-2">Planet-First Formulas</h3>
                    <p className="text-gray-600 dark:text-gray-300">Our biodegradable, plant-based ingredients are tough on grime but gentle on the planet.</p>
                </div>
                <div className="p-8">
                    <PawIcon className="w-12 h-12 text-brand-primary dark:text-brand-secondary mx-auto mb-4" />
                    <h3 className="text-xl font-semibold text-brand-dark dark:text-white mb-2">Always Cruelty-Free</h3>
                    <p className="text-gray-600 dark:text-gray-300">We are proudly Leaping Bunny certified. No animal testing, ever. It's that simple.</p>
                </div>
                <div className="p-8">
                    <GiftIcon className="w-12 h-12 text-brand-primary dark:text-brand-secondary mx-auto mb-4" />
                    <h3 className="text-xl font-semibold text-brand-dark dark:text-white mb-2">Get Rewarded</h3>
                    <p className="text-gray-600 dark:text-gray-300">Our loyalty program is our way of saying thanks. Your 7th product is always on us!</p>
                </div>
            </div>
        </div>
    </div>
);


const CategoryLinks: React.FC = () => (
    <div className="bg-white dark:bg-gray-800 py-12 sm:py-16">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <h2 className="text-3xl font-serif font-bold text-center text-brand-dark dark:text-brand-light mb-10">Shop by Category</h2>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-8">
                {CATEGORIES.map(category => (
                    <NavLink key={category.id} to={`/products?category=${category.id}`} className="group text-center">
                        <div className="relative overflow-hidden rounded-lg aspect-square mb-4">
                            <img src={category.image} alt={category.name} className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-300" />
                            <div className="absolute inset-0 bg-black/20 group-hover:bg-black/10 transition-colors"></div>
                        </div>
                        <h3 className="text-lg font-semibold text-brand-dark dark:text-white group-hover:text-brand-primary dark:group-hover:text-brand-secondary transition-colors">{category.name}</h3>
                    </NavLink>
                ))}
            </div>
        </div>
    </div>
);

const HeartIcon: React.FC<{ filled: boolean } & React.SVGProps<SVGSVGElement>> = ({ filled, ...props }) => (
    filled ? (
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
          <path d="M11.645 20.91l-.007-.003-.022-.012a15.247 15.247 0 01-1.344-.688 15.182 15.182 0 01-1.06-1.066c-3.119-3.119-3.24-5.056-3.24-8.022 0-2.868 2.368-5.17 5.225-5.17 1.625 0 3.067.76 4.04 2.015.973-1.255 2.415-2.015 4.04-2.015 2.857 0 5.225 2.302 5.225 5.17 0 2.966-.12 4.903-3.24 8.022a15.182 15.182 0 01-1.06 1.066 15.247 15.247 0 01-1.344.688l-.022.012-.007.003h-.001a.752.752 0 01-.704 0h-.001z" />
        </svg>
    ) : (
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
          <path strokeLinecap="round" strokeLinejoin="round" d="M21 8.25c0-2.485-2.099-4.5-4.688-4.5-1.935 0-3.597 1.126-4.312 2.733-.715-1.607-2.377-2.733-4.313-2.733C5.1 3.75 3 5.765 3 8.25c0 7.22 9 12 9 12s9-4.78 9-12z" />
        </svg>
    )
);

const ProductCard: React.FC<{ product: typeof PRODUCTS[0] }> = ({ product }) => {
    const { addToCart } = useCart();
    const { isInWishlist, addToWishlist, removeFromWishlist } = useWishlist();
    const onWishlist = isInWishlist(product.id);

    const handleWishlistClick = (e: React.MouseEvent) => {
        e.preventDefault();
        e.stopPropagation();
        if (onWishlist) {
            removeFromWishlist(product.id);
        } else {
            addToWishlist(product.id);
        }
    };

    return (
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md dark:border dark:border-gray-700 overflow-hidden group flex flex-col">
            <div className="relative">
                <NavLink to={`/products/${product.id}`} className="block">
                    <img src={product.images[0]} alt={product.name} className="w-full h-56 object-cover" />
                </NavLink>
                 <button 
                    onClick={handleWishlistClick}
                    className={`absolute top-3 right-3 p-1.5 rounded-full transition-colors duration-200 ${onWishlist ? 'bg-red-100 text-red-500' : 'bg-white/70 dark:bg-gray-800/70 text-gray-700 dark:text-gray-300 hover:bg-white dark:hover:bg-gray-700 hover:text-red-500'}`}
                    aria-label={onWishlist ? 'Remove from wishlist' : 'Add to wishlist'}
                >
                    <HeartIcon filled={onWishlist} className="w-6 h-6" />
                </button>
            </div>
            <div className="p-4 flex-grow flex flex-col">
                <h3 className="text-lg font-semibold text-brand-dark dark:text-brand-light mb-2 flex-grow">
                    <NavLink to={`/products/${product.id}`} className="hover:text-brand-primary dark:hover:text-brand-secondary transition-colors">{product.name}</NavLink>
                </h3>
                <div className="flex items-center mb-2">
                    <StarRating rating={product.rating} />
                    <span className="text-xs text-gray-500 dark:text-gray-400 ml-2">({product.reviewCount})</span>
                </div>
                <div className="flex items-center justify-between mt-auto pt-2">
                    <p className="text-xl font-bold text-brand-primary dark:text-brand-secondary">Ksh {product.price.toLocaleString()}</p>
                    <button onClick={() => addToCart(product)} className="bg-brand-secondary text-brand-dark font-bold px-4 py-2 rounded-md hover:bg-opacity-80 transition-colors">
                        Add to Cart
                    </button>
                </div>
            </div>
        </div>
    );
};

const FeaturedProducts: React.FC = () => {
    const [activeTab, setActiveTab] = useState('bestsellers');

    const bestSellers = PRODUCTS.slice(0, 4);
    const newArrivals = [...PRODUCTS].sort((a, b) => b.id - a.id).slice(0, 4);

    const productsToShow = activeTab === 'bestsellers' ? bestSellers : newArrivals;
    
    const tabButtonClasses = (tabName: string) => `px-6 py-2 text-lg font-semibold rounded-full transition-colors duration-300 ${activeTab === tabName ? 'bg-brand-primary text-white' : 'text-gray-600 dark:text-gray-300 hover:text-brand-primary dark:hover:text-brand-secondary'}`;

    return (
        <div className="py-12 sm:py-16 bg-brand-light dark:bg-gray-900">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8">
                <h2 className="text-3xl font-serif font-bold text-center text-brand-dark dark:text-brand-light mb-4">Our Curated Collection</h2>
                <div className="flex justify-center gap-4 mb-10">
                    <button onClick={() => setActiveTab('bestsellers')} className={tabButtonClasses('bestsellers')}>
                        Best Sellers
                    </button>
                    <button onClick={() => setActiveTab('newarrivals')} className={tabButtonClasses('newarrivals')}>
                        New Arrivals
                    </button>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
                    {productsToShow.map(product => (
                        <ProductCard key={product.id} product={product} />
                    ))}
                </div>
            </div>
        </div>
    );
};


const BlogSection: React.FC = () => {
    const latestPosts = BLOG_POSTS.slice(0, 3);
    return (
        <div className="py-12 sm:py-16 dark:bg-gray-800">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8">
                <h2 className="text-3xl font-serif font-bold text-center text-brand-dark dark:text-brand-light mb-10">From Our Blog</h2>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                    {latestPosts.map(post => (
                        <div key={post.id} className="bg-white dark:bg-gray-900 rounded-lg shadow-md dark:border dark:border-gray-700 overflow-hidden group flex flex-col">
                            <NavLink to={`/blog/${post.id}`} className="block">
                                <img src={post.image} alt={post.title} className="w-full h-56 object-cover transform group-hover:scale-105 transition-transform duration-300" />
                            </NavLink>
                            <div className="p-6 flex flex-col flex-grow">
                                <p className="text-sm text-gray-500 dark:text-gray-400 mb-2">{post.date}</p>
                                <h3 className="text-xl font-semibold text-brand-dark dark:text-white mb-4 flex-grow">
                                    <NavLink to={`/blog/${post.id}`} className="hover:text-brand-primary dark:hover:text-brand-secondary transition-colors">{post.title}</NavLink>
                                </h3>
                                <NavLink to={`/blog/${post.id}`} className="font-semibold text-brand-primary dark:text-brand-secondary hover:underline mt-auto">
                                    Read More &rarr;
                                </NavLink>
                            </div>
                        </div>
                    ))}
                </div>
                <div className="text-center mt-12">
                    <NavLink to="/blog" className="bg-brand-primary text-white font-bold py-3 px-8 rounded-md hover:bg-opacity-80 transition-colors">
                        View All Posts
                    </NavLink>
                </div>
            </div>
        </div>
    );
};

const getAvatarByAuthor = (author: string): string => {
    const maleAvatars = [
        'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?q=80&w=200&h=200&auto=format&fit=crop',
        'https://images.unsplash.com/photo-1607990281513-2c110a25bd8c?q=80&w=200&h=200&auto=format&fit=crop',
        'https://images.unsplash.com/photo-1583364481914-2421b8f72559?q=80&w=200&h=200&auto=format&fit=crop',
    ];
    const femaleAvatars = [
        'https://images.unsplash.com/photo-1532635241-17e820acc59f?q=80&w=200&h=200&auto=format&fit=crop',
        'https://images.unsplash.com/photo-1525134479668-1bee5c7c6845?q=80&w=200&h=200&auto=format&fit=crop',
        'https://images.unsplash.com/photo-1555632283-72242b580934?q=80&w=200&h=200&auto=format&fit=crop',
    ];

    const firstName = author.split(' ')[0].toLowerCase().replace('.', '');
    const maleNames = ['mike', 'david', 'ben', 'kevin', 'daniel'];
    const gender = maleNames.includes(firstName) ? 'male' : 'female';
    
    // Simple hash function to pick an avatar consistently
    const hash = author.split('').reduce((acc, char) => char.charCodeAt(0) + ((acc << 5) - acc), 0);

    if (gender === 'male') {
        return maleAvatars[Math.abs(hash) % maleAvatars.length];
    } else {
        return femaleAvatars[Math.abs(hash) % femaleAvatars.length];
    }
};

const Testimonials: React.FC = () => (
    <div className="bg-brand-primary/5 dark:bg-brand-dark/20 py-12 sm:py-16 lg:py-24">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <h2 className="text-3xl font-serif font-bold text-center text-brand-dark dark:text-brand-light mb-4">What Customers Says</h2>
            <p className="text-center text-lg text-gray-700 dark:text-gray-300 max-w-3xl mx-auto mb-12">Join thousands of satisfied families who trust Soap & Hope for their cleaning needs</p>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8 max-w-7xl mx-auto">
                {REVIEWS.slice(0, 5).map(review => (
                    <div key={review.id} className="bg-white dark:bg-gray-800 p-8 rounded-lg shadow-lg dark:border dark:border-gray-700 flex flex-col items-center text-center transform hover:-translate-y-2 transition-transform">
                        <img src={getAvatarByAuthor(review.author)} alt={review.author} className="w-20 h-20 rounded-full mb-4 shadow-md border-2 border-brand-secondary object-cover" />
                        <StarRating rating={review.rating} />
                        <p className="text-gray-600 dark:text-gray-300 my-4 flex-grow">"{review.comment}"</p>
                        <p className="font-bold text-brand-dark dark:text-white">- {review.author}</p>
                    </div>
                ))}
            </div>
             <div className="text-center mt-12">
                <NavLink to="/products" className="bg-brand-primary text-white font-bold py-3 px-8 rounded-md hover:bg-opacity-80 transition-all transform hover:scale-105 inline-block">
                    See All Products
                </NavLink>
            </div>
        </div>
    </div>
);

// --- Parent Component ---

const HomePage: React.FC = () => {
    return (
        <div className="bg-gray-50 dark:bg-gray-900">
            <Hero />
            <LoyaltyBanner />
            <ParallaxSection />
            <WhyChooseUs />
            <CategoryLinks />
            <FeaturedProducts />
            <BlogSection />
            <Testimonials />
        </div>
    );
};

export default HomePage;