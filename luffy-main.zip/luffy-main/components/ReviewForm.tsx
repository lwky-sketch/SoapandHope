import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useReviews } from '../context/ReviewContext';
import StarRatingInput from './StarRatingInput';

interface ReviewFormProps {
  productId: number;
}

const ReviewForm: React.FC<ReviewFormProps> = ({ productId }) => {
  const { currentUser } = useAuth();
  const { addReview } = useReviews();

  const [rating, setRating] = useState(0);
  const [comment, setComment] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    if (rating === 0 || comment.trim() === '') {
      setError('Please provide a rating and a comment.');
      return;
    }

    if (!currentUser) {
      setError('You must be logged in to post a review.');
      return;
    }

    addReview({
      productId,
      author: currentUser.username,
      rating,
      comment,
    });

    setSuccess('Thank you for your review!');
    setRating(0);
    setComment('');

    setTimeout(() => setSuccess(''), 4000);
  };

  return (
    <form onSubmit={handleSubmit} className="bg-gray-50 dark:bg-gray-800 dark:border-gray-700 p-6 rounded-lg border">
      <h3 className="text-xl font-semibold mb-4 dark:text-white">Leave a Review</h3>
      {error && <p className="text-red-500 mb-4">{error}</p>}
      {success && <p className="text-green-600 mb-4">{success}</p>}
      <div className="mb-4">
        <label className="block text-gray-700 dark:text-gray-300 font-medium mb-2">Your Rating</label>
        <StarRatingInput rating={rating} onRatingChange={setRating} />
      </div>
      <div className="mb-4">
         <label htmlFor="comment" className="block text-gray-700 dark:text-gray-300 font-medium mb-2">Your Comment</label>
        <textarea
          id="comment"
          value={comment}
          onChange={(e) => setComment(e.target.value)}
          placeholder={`How did you like the product, ${currentUser?.username}?`}
          className="w-full p-3 border rounded-md h-32 dark:bg-gray-700 dark:border-gray-600 dark:text-gray-200"
          required
        />
      </div>
      <button type="submit" className="bg-brand-primary text-white font-bold py-2 px-6 rounded-md hover:bg-opacity-80 transition-colors">
        Submit Review
      </button>
    </form>
  );
};

export default ReviewForm;
