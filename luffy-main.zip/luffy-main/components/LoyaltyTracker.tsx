
import React from 'react';
import { useCart } from '../context/CartContext';
import { NavLink } from 'react-router-dom';

interface LoyaltyTrackerProps {
  showTitle?: boolean;
}

const GiftIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M21 11.25v8.25a1.5 1.5 0 01-1.5 1.5H5.25a1.5 1.5 0 01-1.5-1.5v-8.25M12 4.875A2.625 2.625 0 109.375 7.5H12m0-2.625V7.5m0-2.625A2.625 2.625 0 1114.625 7.5H12m0 0V21m-8.625-9.75h18c.621 0 1.125-.504 1.125-1.125v-1.5c0-.621-.504-1.125-1.125-1.125h-18c-.621 0-1.125.504-1.125 1.125v1.5c0 .621.504 1.125 1.125 1.125z" />
  </svg>
);

const LoyaltyTracker: React.FC<LoyaltyTrackerProps> = ({ showTitle = true }) => {
  const { purchaseCount } = useCart();
  const progress = Math.min(purchaseCount, 6);
  const percentage = (progress / 6) * 100;

  let message = '';
  if (progress < 6) {
    const remaining = 6 - progress;
    message = `${remaining} purchase${remaining > 1 ? 's' : ''} away from a FREE product!`;
  } else {
    message = "Congratulations! Your next product is on us!";
  }

  return (
    <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md border border-gray-200 dark:border-gray-700">
      {showTitle && <h3 className="text-xl font-bold font-serif text-brand-dark dark:text-brand-light mb-4">Your Loyalty Progress</h3>}
      <div className="flex items-center gap-4 mb-2">
        <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-4">
          <div 
            className="bg-brand-secondary h-4 rounded-full transition-all duration-500 ease-out"
            style={{ width: `${percentage}%` }}
          ></div>
        </div>
        <GiftIcon className={`w-8 h-8 transition-colors ${progress >= 6 ? 'text-brand-accent' : 'text-gray-400 dark:text-gray-500'}`} />
      </div>
      <div className="flex justify-between text-sm font-medium text-gray-600 dark:text-gray-400">
        <span>{progress}/6 Purchases</span>
        <span>7th Free</span>
      </div>
      <p className="text-center mt-4 text-md font-semibold text-brand-primary dark:text-brand-secondary">{message}</p>
      {progress < 6 && showTitle &&
        <div className="text-center mt-4">
            <NavLink to="/loyalty" className="text-sm text-brand-primary dark:text-brand-secondary hover:underline">Learn more about our program</NavLink>
        </div>
      }
    </div>
  );
};

export default LoyaltyTracker;