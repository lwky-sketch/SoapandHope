import React from 'react';
import { QRCodeCanvas } from 'qrcode.react';
import { useTheme } from '../context/ThemeContext';

const QRCode: React.FC = () => {
  const { theme } = useTheme();
  const qrCodeValue = window.location.origin;

  const bgColor = theme === 'dark' ? '#1f2937' : '#ffffff'; // gray-800
  const fgColor = theme === 'dark' ? '#F8F9FA' : '#1D3A34'; // brand-light, brand-dark

  return (
    <div className="bg-white dark:bg-gray-800 p-4 rounded-lg border border-gray-200 dark:border-gray-700 shadow-sm flex flex-col items-center gap-3 w-fit">
        <QRCodeCanvas
            value={qrCodeValue}
            size={128}
            bgColor={bgColor}
            fgColor={fgColor}
            level={"L"}
            includeMargin={true}
        />
        <p className="text-sm font-semibold text-brand-dark dark:text-white text-center">
            Scan to visit our website
        </p>
    </div>
  );
};

export default QRCode;
