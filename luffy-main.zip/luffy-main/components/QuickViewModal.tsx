import React, { useEffect } from 'react';
import { NavLink } from 'react-router-dom';
import { Product } from '../types';
import { useCart } from '../context/CartContext';
import StarRating from './StarRating';

interface QuickViewModalProps {
  product: Product | null;
  isOpen: boolean;
  onClose: () => void;
}

const XMarkIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
    </svg>
);

const QuickViewModal: React.FC<QuickViewModalProps> = ({ product, isOpen, onClose }) => {
  const { addToCart } = useCart();

  useEffect(() => {
    const handleEsc = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        onClose();
      }
    };
    
    if (isOpen) {
      document.body.style.overflow = 'hidden';
      window.addEventListener('keydown', handleEsc);
    }
    
    return () => {
      document.body.style.overflow = 'unset';
      window.removeEventListener('keydown', handleEsc);
    };
  }, [isOpen, onClose]);

  if (!isOpen || !product) return null;

  const handleAddToCart = () => {
    addToCart(product);
    onClose();
  }

  return (
    <div className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center p-4" style={{ animation: 'fadeIn 0.3s ease-out' }}>
      <div 
        className="fixed inset-0"
        onClick={onClose}
        aria-hidden="true"
      ></div>
      <div className="relative bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-4xl max-h-[90vh] flex flex-col md:flex-row overflow-hidden">
        <button onClick={onClose} className="absolute top-3 right-3 p-2 rounded-full bg-white/50 dark:bg-gray-800/50 backdrop-blur-sm hover:bg-white dark:hover:bg-gray-700 text-gray-600 dark:text-gray-300 hover:text-black dark:hover:text-white transition-all duration-200 z-10">
          <XMarkIcon className="w-7 h-7" />
          <span className="sr-only">Close modal</span>
        </button>

        {/* Image Section */}
        <div className="w-full md:w-1/2">
          <img src={product.images[0]} alt={product.name} className="w-full h-64 md:h-full object-cover"/>
        </div>

        {/* Content Section */}
        <div className="w-full md:w-1/2 p-6 md:p-8 flex flex-col overflow-y-auto">
          <div>
            <p className="text-brand-primary dark:text-brand-secondary font-semibold uppercase tracking-wide text-sm">{product.category}</p>
            <h2 className="text-2xl sm:text-3xl font-serif font-bold text-brand-dark dark:text-brand-light my-2">{product.name}</h2>
            <div className="flex items-center gap-4 mb-3">
              <StarRating rating={product.rating} />
              <span className="text-gray-600 dark:text-gray-400 text-sm">{product.reviewCount} reviews</span>
            </div>
            <p className="text-2xl font-bold text-brand-primary dark:text-brand-secondary mb-4">Ksh {product.price.toLocaleString()}</p>
            <p className="text-gray-700 dark:text-gray-300 leading-relaxed mb-6" style={{ display: '-webkit-box', WebkitLineClamp: 4, sm: { WebkitLineClamp: 3 }, WebkitBoxOrient: 'vertical', overflow: 'hidden' }}>{product.description}</p>
          </div>
          <div className="mt-auto pt-6">
            <button onClick={handleAddToCart} className="w-full bg-brand-primary text-white font-bold py-3 px-8 rounded-md hover:bg-opacity-80 transition-colors mb-3">
              Add to Cart
            </button>
            <NavLink 
              to={`/products/${product.id}`} 
              onClick={onClose}
              className="w-full text-center block text-brand-primary dark:text-brand-secondary font-semibold hover:underline"
            >
              View Full Details
            </NavLink>
          </div>
        </div>
      </div>
       <style>{`
        @keyframes fadeIn {
          from { opacity: 0; }
          to { opacity: 1; }
        }
      `}</style>
    </div>
  );
};

export default QuickViewModal;