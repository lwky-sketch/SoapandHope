import React, { useState, useEffect, useRef } from 'react';
import { useNavigate, NavLink } from 'react-router-dom';
import { Product } from '../types';
import { PRODUCTS } from '../constants';

const SearchIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-5.197-5.197m0 0A7.5 7.5 0 105.196 5.196a7.5 7.5 0 0010.607 10.607z" />
    </svg>
);

const popularTerms = ['laundry', 'soap', 'lavender', 'mint sanitizer', 'dish liquid'];

interface SearchWithAutocompleteProps {
    onSearchSubmit?: () => void;
    isMobile?: boolean;
}

const SearchWithAutocomplete: React.FC<SearchWithAutocompleteProps> = ({ onSearchSubmit, isMobile = false }) => {
    const [searchQuery, setSearchQuery] = useState('');
    const [results, setResults] = useState<{ products: Product[], terms: string[] }>({ products: [], terms: [] });
    const [isOpen, setIsOpen] = useState(false);
    const searchContainerRef = useRef<HTMLFormElement>(null);
    const navigate = useNavigate();

    useEffect(() => {
        const handler = (e: MouseEvent) => {
            if (searchContainerRef.current && !searchContainerRef.current.contains(e.target as Node)) {
                setIsOpen(false);
            }
        };
        document.addEventListener('mousedown', handler);
        return () => document.removeEventListener('mousedown', handler);
    }, []);

    useEffect(() => {
        const trimmedQuery = searchQuery.trim().toLowerCase();
        if (trimmedQuery.length > 1) {
            const matchedProducts = PRODUCTS.filter(p => 
                p.name.toLowerCase().includes(trimmedQuery) ||
                p.category.toLowerCase().includes(trimmedQuery)
            ).slice(0, 4);
            const matchedTerms = popularTerms.filter(t => t.toLowerCase().includes(trimmedQuery)).slice(0, 3);
            
            if (matchedProducts.length > 0 || matchedTerms.length > 0) {
                setResults({ products: matchedProducts, terms: matchedTerms });
                setIsOpen(true);
            } else {
                setIsOpen(false);
            }
        } else {
            setIsOpen(false);
        }
    }, [searchQuery]);

    const performSearch = (query: string) => {
        const trimmedQuery = query.trim();
        if (trimmedQuery) {
            navigate(`/products?search=${encodeURIComponent(trimmedQuery)}`);
        } else {
            navigate('/products');
        }
        setSearchQuery('');
        setIsOpen(false);
        if (onSearchSubmit) {
            onSearchSubmit();
        }
    };
    
    const handleSearchSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        performSearch(searchQuery);
    };

    const handleTermClick = (term: string) => {
        performSearch(term);
    };

    const handleLinkClick = () => {
        setSearchQuery('');
        setIsOpen(false);
        if (onSearchSubmit) {
            onSearchSubmit();
        }
    };
    
    return (
        <form onSubmit={handleSearchSubmit} ref={searchContainerRef} className="relative">
             <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onFocus={() => { if(searchQuery.trim().length > 1) setIsOpen(true)}}
                placeholder={isMobile ? "Search products..." : "Search..."}
                className={isMobile 
                    ? "w-full pl-4 pr-12 py-3 bg-white/10 text-white placeholder-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-brand-secondary"
                    : "w-32 sm:w-40 md:w-48 pl-4 pr-10 py-2 border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-gray-200 dark:placeholder-gray-400 rounded-full text-sm focus:outline-none focus:ring-2 focus:ring-brand-primary/50 transition-all duration-300 md:focus:w-56"
                }
                aria-label="Search products"
            />
            <button type="submit" aria-label="Submit search" className={`absolute right-0 top-0 text-gray-500 hover:text-brand-primary dark:text-gray-400 dark:hover:text-brand-secondary ${isMobile ? 'mt-3 mr-3' : 'mt-2 mr-3'}`}>
                <SearchIcon className={isMobile ? "w-6 h-6" : "w-5 h-5"} />
            </button>

            {isOpen && (
                <div className="absolute top-full mt-2 w-full sm:w-80 max-h-96 overflow-y-auto bg-white/90 dark:bg-brand-dark/90 backdrop-blur-md rounded-lg shadow-lg border border-gray-200 dark:border-gray-700 z-10">
                    <div className="p-2 sm:p-4 space-y-2">
                        {results.products.length > 0 && (
                            <div>
                                <h4 className="text-xs font-bold uppercase text-gray-400 mb-2 px-2">Products</h4>
                                <ul>
                                    {results.products.map(product => (
                                    <li key={product.id}>
                                        <NavLink to={`/products/${product.id}`} onClick={handleLinkClick} className="flex items-center gap-3 p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors">
                                            <img src={product.images[0]} alt={product.name} className="w-12 h-12 object-cover rounded-md flex-shrink-0" />
                                            <div className="flex-grow min-w-0">
                                                <p className="font-semibold text-sm text-brand-dark dark:text-white truncate">{product.name}</p>
                                                <p className="text-sm text-brand-primary dark:text-brand-secondary">Ksh {product.price.toLocaleString()}</p>
                                            </div>
                                        </NavLink>
                                    </li>
                                    ))}
                                </ul>
                            </div>
                        )}
                        {results.products.length > 0 && results.terms.length > 0 && (
                            <hr className="border-gray-200 dark:border-gray-700" />
                        )}
                        {results.terms.length > 0 && (
                            <div>
                                <h4 className="text-xs font-bold uppercase text-gray-400 mb-2 px-2">Popular Searches</h4>
                                <ul>
                                    {results.terms.map(term => (
                                    <li key={term}>
                                        <button type="button" onClick={() => handleTermClick(term)} className="w-full text-left flex items-center gap-3 p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors">
                                            <SearchIcon className="w-4 h-4 text-gray-500 flex-shrink-0"/>
                                            <span className="font-semibold text-sm text-gray-700 dark:text-gray-300 capitalize">{term}</span>
                                        </button>
                                    </li>
                                    ))}
                                </ul>
                            </div>
                        )}
                    </div>
                </div>
            )}
        </form>
    );
}

export default SearchWithAutocomplete;