import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
import { useCart } from '../context/CartContext';
import { useWishlist } from '../context/WishlistContext';
import { useAuth } from '../context/AuthContext';
import Logo from './Logo';
import ThemeToggleButton from './ThemeToggleButton';
import SearchWithAutocomplete from './SearchWithAutocomplete';

const ShoppingBagIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 10.5V6a3.75 3.75 0 10-7.5 0v4.5m11.356-1.993l1.263 12c.07.658-.463 1.243-1.119 1.243H4.25a1.125 1.125 0 01-1.12-1.243l1.264-12A1.125 1.125 0 015.513 7.5h12.974c.576 0 1.059.435 1.119 1.007zM8.625 10.5a.375.375 0 11-.75 0 .375.375 0 01.75 0zm7.5 0a.375.375 0 11-.75 0 .375.375 0 01.75 0z" />
    </svg>
);

const HeartIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M21 8.25c0-2.485-2.099-4.5-4.688-4.5-1.935 0-3.597 1.126-4.312 2.733-.715-1.607-2.377-2.733-4.313-2.733C5.1 3.75 3 5.765 3 8.25c0 7.22 9 12 9 12s9-4.78 9-12z" />
    </svg>
);

const Bars3Icon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5" />
    </svg>
);

const XMarkIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
    </svg>
);

const UserCircleIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M17.982 18.725A7.488 7.488 0 0012 15.75a7.488 7.488 0 00-5.982 2.975m11.963 0a9 9 0 10-11.963 0m11.963 0A8.966 8.966 0 0112 21a8.966 8.966 0 01-5.982-2.275M15 9.75a3 3 0 11-6 0 3 3 0 016 0z" />
    </svg>
);

const Header: React.FC = () => {
    const { cartCount, toggleCart } = useCart();
    const { wishlistCount } = useWishlist();
    const { isAuthenticated, openAuthModal, logout, currentUser } = useAuth();
    const [isMenuOpen, setIsMenuOpen] = useState(false);

    const navLinkClass = ({ isActive }: { isActive: boolean }) =>
      `text-gray-600 dark:text-gray-300 hover:text-brand-primary dark:hover:text-brand-secondary transition-colors font-medium pb-1 border-b-2 ${
        isActive ? 'border-brand-primary dark:border-brand-secondary text-brand-primary dark:text-brand-secondary' : 'border-transparent'
      }`;

    const mobileNavLinkClass = ({ isActive }: { isActive: boolean }) =>
      `text-2xl font-semibold transition-colors ${
        isActive ? 'text-brand-secondary' : 'text-white hover:text-brand-secondary'
      }`;
    
    const NavLinks: React.FC<{isMobile?: boolean}> = ({ isMobile = false }) => (
        <>
            <NavLink to="/" className={isMobile ? mobileNavLinkClass : navLinkClass} onClick={() => setIsMenuOpen(false)} end>Home</NavLink>
            <NavLink to="/products" className={isMobile ? mobileNavLinkClass : navLinkClass} onClick={() => setIsMenuOpen(false)}>Products</NavLink>
            <NavLink to="/loyalty" className={isMobile ? mobileNavLinkClass : navLinkClass} onClick={() => setIsMenuOpen(false)}>Loyalty Program</NavLink>
            <NavLink to="/blog" className={isMobile ? mobileNavLinkClass : navLinkClass} onClick={() => setIsMenuOpen(false)}>Blog</NavLink>
            <NavLink to="/track-order" className={isMobile ? mobileNavLinkClass : navLinkClass} onClick={() => setIsMenuOpen(false)}>Track Order</NavLink>
            <NavLink to="/about" className={isMobile ? mobileNavLinkClass : navLinkClass} onClick={() => setIsMenuOpen(false)}>About Us</NavLink>
            <NavLink to="/contact" className={isMobile ? mobileNavLinkClass : navLinkClass} onClick={() => setIsMenuOpen(false)}>Contact</NavLink>
        </>
    );
    
    return (
     <header className="bg-white/80 dark:bg-brand-dark/80 backdrop-blur-md sticky top-0 z-40 shadow-sm">
            <div className="container mx-auto px-2 sm:px-6 lg:px-8">
                <div className="flex items-center justify-between h-20">
                    <div className="flex items-center">
                        <div className="flex-shrink-0 lg:mr-10">
                            <Logo />
                        </div>
                        <nav className="hidden lg:flex items-center space-x-8">
                            <NavLinks />
                        </nav>
                    </div>
                    <div className="flex items-center space-x-2 sm:space-x-4">
                        <div className="hidden sm:block">
                            <SearchWithAutocomplete />
                        </div>
                        
                        {isAuthenticated && (
                            <NavLink to="/order-history" className="hidden lg:block text-gray-600 dark:text-gray-300 hover:text-brand-primary dark:hover:text-brand-secondary transition-colors font-medium text-sm">My Orders</NavLink>
                        )}

                        <ThemeToggleButton />
                         <NavLink to="/wishlist" className="relative text-gray-600 dark:text-gray-300 hover:text-brand-primary dark:hover:text-brand-secondary transition-colors">
                            <HeartIcon className="w-7 h-7" />
                            {wishlistCount > 0 && (
                                <span className="absolute -top-2 -right-2 w-5 h-5 bg-brand-accent text-white text-xs rounded-full flex items-center justify-center font-bold">
                                    {wishlistCount}
                                </span>
                            )}
                        </NavLink>
                        <button onClick={toggleCart} className="relative text-gray-600 dark:text-gray-300 hover:text-brand-primary dark:hover:text-brand-secondary transition-colors">
                            <ShoppingBagIcon className="w-7 h-7" />
                            {cartCount > 0 && (
                                <span className="absolute -top-2 -right-2 w-5 h-5 bg-brand-accent text-white text-xs rounded-full flex items-center justify-center font-bold">
                                    {cartCount}
                                </span>
                            )}
                        </button>
                        <div className="hidden lg:flex items-center space-x-4">
                            <div className="h-6 w-px bg-gray-300 dark:bg-gray-600"></div>
                            {isAuthenticated ? (
                                <div className="flex items-center gap-2 md:gap-4">
                                    <div className="flex items-center gap-2">
                                        <UserCircleIcon className="w-6 h-6 text-gray-600 dark:text-gray-300" />
                                        <span className="text-sm text-gray-800 dark:text-gray-200 font-semibold" title={currentUser?.email || ''}>{currentUser?.username}</span>
                                    </div>
                                    <div className="h-6 w-px bg-gray-300 dark:bg-gray-600"></div>
                                    <button onClick={logout} className="text-gray-600 dark:text-gray-300 hover:text-brand-primary dark:hover:text-brand-secondary transition-colors font-medium text-sm">
                                        Logout
                                    </button>
                                </div>
                            ) : (
                                <button onClick={openAuthModal} className="text-gray-600 dark:text-gray-300 hover:text-brand-primary dark:hover:text-brand-secondary transition-colors font-medium text-sm">
                                    Login / Signup
                                </button>
                            )}
                        </div>
                        <div className="lg:hidden">
                            <button onClick={() => setIsMenuOpen(true)} className="text-gray-600 dark:text-gray-300 hover:text-brand-primary dark:hover:text-brand-secondary">
                                <Bars3Icon className="w-7 h-7" />
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            {/* Mobile Menu */}
            <div className={`fixed inset-0 z-50 transform transition-transform duration-300 ease-in-out ${isMenuOpen ? 'translate-x-0' : 'translate-x-full'} lg:hidden`}>
                <div className="bg-brand-dark/95 backdrop-blur-sm w-full h-full flex flex-col">
                    <div className="flex items-center justify-between h-20 px-4 sm:px-6 border-b border-white/10">
                        <div className="[&_span]:text-white">
                           <Logo />
                        </div>
                        <button onClick={() => setIsMenuOpen(false)} className="text-gray-300 hover:text-white">
                            <XMarkIcon className="w-7 h-7" />
                        </button>
                    </div>

                    <div className="flex-grow flex flex-col items-center justify-center text-center p-8">
                        <div className="w-full max-w-sm mb-8">
                            <SearchWithAutocomplete 
                                isMobile 
                                onSearchSubmit={() => setIsMenuOpen(false)}
                            />
                        </div>

                        <nav className="flex flex-col items-center justify-center space-y-6">
                            <NavLinks isMobile={true}/>
                            {isAuthenticated && (
                                <NavLink to="/order-history" className={mobileNavLinkClass} onClick={() => setIsMenuOpen(false)}>My Orders</NavLink>
                            )}
                        </nav>
                    </div>

                    <div className="p-8 border-t border-white/10">
                         {isAuthenticated ? (
                            <div className="flex flex-col items-center gap-4">
                                <div className="flex items-center gap-3">
                                    <UserCircleIcon className="w-7 h-7 text-gray-300" />
                                    <span className="text-lg text-gray-200 font-semibold" title={currentUser?.email || ''}>{currentUser?.username}</span>
                                </div>
                                <button onClick={() => { logout(); setIsMenuOpen(false); }} className="w-full max-w-sm bg-white/10 text-white font-bold py-3 px-6 rounded-md hover:bg-white/20 transition-colors">
                                    Logout
                                </button>
                            </div>
                        ) : (
                             <div className="flex justify-center">
                                <button onClick={() => { openAuthModal(); setIsMenuOpen(false); }} className="bg-brand-secondary text-brand-dark font-bold py-3 px-8 rounded-md hover:bg-opacity-80 transition-colors">
                                    Login / Signup
                                </button>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </header>
    );
};

export default Header;