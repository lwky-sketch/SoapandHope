
import React from 'react';
import { useCart } from '../context/CartContext';
import { NavLink } from 'react-router-dom';

const XMarkIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
    </svg>
);

const TrashIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M14.74 9l-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 01-2.244 2.077H8.084a2.25 2.25 0 01-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 00-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 013.478-.397m7.5 0v-.916c0-1.18-.91-2.134-2.033-2.134H8.033C6.91 2.75 6 3.664 6 4.874v.916m7.5 0a48.667 48.667 0 00-7.5 0" />
    </svg>
);


const CartSidebar: React.FC = () => {
    const { isCartOpen, toggleCart, cartItems, cartTotal, removeFromCart, updateQuantity, isFreebieEarned } = useCart();

    const originalTotal = cartItems.reduce((acc, item) => acc + item.price * item.quantity, 0);

    return (
        <>
            <div 
                className={`fixed inset-0 bg-black/60 z-40 transition-opacity duration-300 ${isCartOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}
                onClick={toggleCart}
            ></div>
            <div className={`fixed top-0 right-0 h-full w-full max-w-md bg-white dark:bg-gray-800 shadow-2xl z-50 transform transition-transform duration-300 ease-in-out ${isCartOpen ? 'translate-x-0' : 'translate-x-full'}`}>
                <div className="flex flex-col h-full">
                    <div className="flex items-center justify-between p-6 border-b dark:border-gray-700">
                        <h2 className="text-2xl font-serif font-bold text-brand-dark dark:text-brand-light">Your Cart</h2>
                        <button onClick={toggleCart} className="text-gray-500 dark:text-gray-300 hover:text-gray-800 dark:hover:text-white">
                            <XMarkIcon className="w-6 h-6" />
                        </button>
                    </div>

                    {cartItems.length === 0 ? (
                        <div className="flex-grow flex flex-col items-center justify-center p-6 text-center">
                            <p className="text-gray-600 dark:text-gray-300 text-lg mb-4">Your cart is empty.</p>
                            <NavLink to="/products" onClick={toggleCart} className="bg-brand-primary text-white font-bold py-3 px-6 rounded-md hover:bg-opacity-80 transition-colors">
                                Start Shopping
                            </NavLink>
                        </div>
                    ) : (
                        <>
                            <div className="flex-grow overflow-y-auto p-6 space-y-4">
                                {isFreebieEarned && (
                                    <div className="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 rounded-md" role="alert">
                                        <p className="font-bold">Loyalty Reward Applied!</p>
                                        <p>Your most expensive item is free.</p>
                                    </div>
                                )}
                                {cartItems.map(item => (
                                    <div key={item.id} className="flex items-start gap-4">
                                        <img src={item.images[0]} alt={item.name} className="w-24 h-24 object-cover rounded-md" />
                                        <div className="flex-grow">
                                            <h3 className="font-semibold text-brand-dark dark:text-brand-light">{item.name}</h3>
                                            <p className="text-sm text-gray-500 dark:text-gray-400">Ksh {item.price.toLocaleString()}</p>
                                            <div className="flex items-center mt-2">
                                                <input 
                                                    type="number" 
                                                    value={item.quantity} 
                                                    onChange={(e) => updateQuantity(item.id, parseInt(e.target.value))}
                                                    className="w-16 text-center border rounded-md dark:bg-gray-700 dark:border-gray-600 dark:text-gray-200"
                                                    min="1"
                                                />
                                            </div>
                                        </div>
                                        <button onClick={() => removeFromCart(item.id)} className="text-gray-400 hover:text-red-500 transition-colors">
                                            <TrashIcon className="w-5 h-5" />
                                        </button>
                                    </div>
                                ))}
                            </div>

                            <div className="p-6 border-t dark:border-gray-700 bg-gray-50 dark:bg-gray-900/50">
                                {isFreebieEarned && (
                                     <div className="flex justify-between text-gray-600 dark:text-gray-300 mb-2">
                                        <span>Subtotal</span>
                                        <span className="line-through">Ksh {originalTotal.toLocaleString()}</span>
                                    </div>
                                )}
                                <div className="flex justify-between font-bold text-xl text-brand-dark dark:text-brand-light mb-4">
                                    <span>Total</span>
                                    <span>Ksh {cartTotal.toLocaleString()}</span>
                                </div>
                                <NavLink to="/checkout" onClick={toggleCart} className="w-full text-center bg-brand-primary text-white font-bold py-3 px-6 rounded-md hover:bg-opacity-80 transition-colors block">
                                    Proceed to Checkout
                                </NavLink>
                            </div>
                        </>
                    )}
                </div>
            </div>
        </>
    );
};

export default CartSidebar;