import React from 'react';
import { NavLink } from 'react-router-dom';

const WaterDropIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg viewBox="0 0 24 24" fill="currentColor" {...props}>
        <path d="M12,2c-5.33,4.55-8,8.48-8,11.42,0,4.42,3.58,8,8,8s8-3.58,8-8c0-2.94-2.67-6.87-8-11.42Z"/>
    </svg>
);

const Logo: React.FC = () => (
    <NavLink 
      to="/" 
      className="flex items-center gap-2 text-brand-dark dark:text-brand-light hover:text-brand-primary dark:hover:text-brand-secondary transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-brand-primary rounded-md"
      aria-label="Soap & Hope Homepage"
    >
        <div className="w-8 h-8">
            <WaterDropIcon className="text-brand-primary dark:text-brand-secondary"/>
        </div>
        <span className="text-2xl md:text-3xl font-serif font-bold tracking-tight">
            Soap & Hope
        </span>
    </NavLink>
);

export default Logo;