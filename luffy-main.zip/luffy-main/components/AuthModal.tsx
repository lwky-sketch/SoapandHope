import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import Logo from './Logo';

// --- ICONS ---
const XMarkIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="http://www.w3.org/2000/svg" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
    </svg>
);
const GoogleIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg viewBox="0 0 24 24" {...props}><path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"></path><path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"></path><path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"></path><path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"></path></svg>
);
const FacebookIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg viewBox="0 0 24 24" {...props}><path d="M12 2.04C6.5 2.04 2 6.53 2 12.06c0 5.52 4.5 10.02 10 10.02s10-4.5 10-10.02C22 6.53 17.5 2.04 12 2.04z" fill="#1877F2"></path><path d="M16.57 16.57h-2.14v-5.26h2.14v-1.8c0-1.74 1.04-2.8 2.8-2.8h1.2v2.14h-1.2c-.87 0-.91.42-.91.91v1.55h2.14l-.28 2.14h-1.86v5.26z" fill="#FFFFFF"></path></svg>
);
const EnvelopeIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}><path strokeLinecap="round" strokeLinejoin="round" d="M21.75 6.75v10.5a2.25 2.25 0 01-2.25 2.25h-15a2.25 2.25 0 01-2.25-2.25V6.75m19.5 0A2.25 2.25 0 0019.5 4.5h-15a2.25 2.25 0 00-2.25 2.25m19.5 0v.243a2.25 2.25 0 01-1.07 1.916l-7.5 4.615a2.25 2.25 0 01-2.36 0L3.32 8.91a2.25 2.25 0 01-1.07-1.916V6.75" /></svg>
);
const LockClosedIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M16.5 10.5V6.75a4.5 4.5 0 00-9 0v3.75m-.75 11.25h10.5a2.25 2.25 0 002.25-2.25v-6.75a2.25 2.25 0 00-2.25-2.25H6.75a2.25 2.25 0 00-2.25 2.25v6.75a2.25 2.25 0 002.25 2.25z" />
  </svg>
);
const UserIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 6a3.75 3.75 0 11-7.5 0 3.75 3.75 0 017.5 0zM4.501 20.118a7.5 7.5 0 0114.998 0A17.933 17.933 0 0112 21.75c-2.676 0-5.216-.584-7.499-1.632z" />
  </svg>
);
const PhoneIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}><path strokeLinecap="round" strokeLinejoin="round" d="M10.5 1.5H8.25A2.25 2.25 0 006 3.75v16.5a2.25 2.25 0 002.25 2.25h7.5A2.25 2.25 0 0018 20.25V3.75a2.25 2.25 0 00-2.25-2.25H13.5m-3 0V3h3V1.5m-3 0h3m-3 18h3" /></svg>
);
const EyeIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}><path strokeLinecap="round" strokeLinejoin="round" d="M2.036 12.322a1.012 1.012 0 010-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.432 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178z" /><path strokeLinecap="round" strokeLinejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /></svg>
);
const EyeSlashIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}><path strokeLinecap="round" strokeLinejoin="round" d="M3.98 8.223A10.477 10.477 0 001.934 12C3.226 16.338 7.244 19.5 12 19.5c.993 0 1.953-.138 2.863-.395M6.228 6.228A10.45 10.45 0 0112 4.5c4.756 0 8.773 3.162 10.065 7.498a10.523 10.523 0 01-4.293 5.572M15 12a3 3 0 11-6 0 3 3 0 016 0z" /><path strokeLinecap="round" strokeLinejoin="round" d="M2 2l20 20" /></svg>
);

const PasswordStrengthMeter: React.FC<{ password: string }> = ({ password }) => {
    const checkPasswordStrength = (pass: string) => {
        let score = 0;
// FIX: The original return object was missing the 'width' property, causing a type error on destructuring.
        if (!pass) return { score: 0, text: '', color: '', width: '0%' };

        if (pass.length >= 8) score++;
        if (pass.length >= 12) score++;
        if (/[A-Z]/.test(pass) && /[a-z]/.test(pass)) score++;
        if (/\d/.test(pass)) score++;
        if (/[^A-Za-z0-9]/.test(pass)) score++;
        
        const strength = {
            0: { text: '', color: 'bg-gray-200 dark:bg-gray-600', width: '0%' },
            1: { text: 'Weak', color: 'bg-red-500', width: '20%' },
            2: { text: 'Weak', color: 'bg-red-500', width: '40%' },
            3: { text: 'Medium', color: 'bg-yellow-500', width: '60%' },
            4: { text: 'Strong', color: 'bg-green-500', width: '80%' },
            5: { text: 'Very Strong', color: 'bg-green-500', width: '100%' },
        }[score] || { text: '', color: 'bg-gray-200', width: '0%' };
        
        return { score, ...strength };
    };

// FIX: The 'score' variable was not destructured from the function call, making it unavailable in the JSX.
    const { score, text, color, width } = checkPasswordStrength(password);
    
    if (!password) return null;

    return (
        <div className="flex items-center gap-2 text-xs">
            <div className="w-full bg-gray-200 dark:bg-gray-600 rounded-full h-1.5">
                <div className={`h-1.5 rounded-full ${color} transition-all duration-300`} style={{ width }}></div>
            </div>
            <span className={`font-semibold ${score < 3 ? 'text-red-500' : score < 4 ? 'text-yellow-500' : 'text-green-500'}`}>{text}</span>
        </div>
    );
};


const AuthModal: React.FC = () => {
  const { isAuthModalOpen, closeAuthModal, login, signup } = useAuth();
  const [mode, setMode] = useState<'login' | 'signup' | 'forgot'>('login');
  const [socialSignupProvider, setSocialSignupProvider] = useState<'google' | 'facebook' | null>(null);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [username, setUsername] = useState('');
  const [phone, setPhone] = useState('');
  const [rememberMe, setRememberMe] = useState(true);
  const [error, setError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  useEffect(() => {
    if (isAuthModalOpen) {
      document.body.style.overflow = 'hidden';
      // Reset state on open
      setError('');
      setSuccessMessage('');
      setEmail('');
      setPassword('');
      setConfirmPassword('');
      setUsername('');
      setPhone('');
      setMode('login');
      setRememberMe(true);
      setShowPassword(false);
      setSocialSignupProvider(null);
    } else {
      document.body.style.overflow = 'unset';
    }
    
    return () => {
      document.body.style.overflow = 'unset';
    }
  }, [isAuthModalOpen]);
  
  const checkPasswordStrength = (pass: string) => {
    let score = 0;
    if (pass.length >= 8) score++;
    if (/[A-Z]/.test(pass) && /[a-z]/.test(pass)) score++;
    if (/\d/.test(pass)) score++;
    return score;
  }

  const handleAuth = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (mode === 'login') {
      if (!email || !password) {
        setError("Please fill in all fields.");
        return;
      }
      const success = login(email, rememberMe);
      if (!success) {
        setError('Invalid credentials or user does not exist.');
      }
    } else { // signup mode
      if (socialSignupProvider) {
          if (!email || !username || !phone) {
              setError("Please complete your profile details.");
              return;
          }
      } else {
        if (!email || !password || !username || !phone || !confirmPassword) {
          setError("Please fill in all fields.");
          return;
        }
        if (password !== confirmPassword) {
            setError("Passwords do not match.");
            return;
        }
        if (checkPasswordStrength(password) < 2) {
            setError("Password is too weak. Please include at least 8 characters, with letters and numbers.");
            return;
        }
      }
      const result = signup(email, username, phone, rememberMe);
      if (result !== 'success') {
        if (result === 'email') {
            setError('This email is already registered. Please log in.');
        } else if (result === 'username') {
            setError('This username is already taken. Please choose another one.');
        } else if (result === 'phone') {
            setError('This phone number is already associated with an account.');
        } else {
            setError('An unexpected error occurred. Please try again.');
        }
      }
    }
  };

  const handleForgotPasswordRequest = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (!email) {
      setError('Please enter your email address.');
      return;
    }
    // Simulate API call to send reset link
    console.log(`Password reset requested for: ${email}`);
    setSuccessMessage('If an account with that email exists, a password reset link has been sent.');
    setEmail('');
    setTimeout(() => setSuccessMessage(''), 6000); // Hide message after 6 seconds
  };


  const handleSocialAuth = (provider: 'google' | 'facebook') => {
    const socialEmail = provider === 'google' ? 'larry.page@google.com' : 'mark.zuckerberg@facebook.com';
    
    if (login(socialEmail, true)) {
        return;
    }

    setMode('signup');
    setSocialSignupProvider(provider);
    setEmail(socialEmail);
    const suggestedUsername = socialEmail.split('@')[0].replace(/[._-]/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
    setUsername(suggestedUsername);
    setError('');
  };

  if (!isAuthModalOpen) return null;

  return (
    <div className="fixed inset-0 bg-brand-dark/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in-down" style={{animationDuration: '0.3s'}} aria-modal="true" role="dialog">
      <div 
        className="fixed inset-0"
        onClick={closeAuthModal}
        aria-hidden="true"
      ></div>
      <div className="relative w-full max-w-sm md:max-w-4xl max-h-[90vh] bg-white dark:bg-gray-800 rounded-2xl shadow-[0_0_15px_rgba(56,168,145,0.6),_0_0_5px_rgba(34,87,73,0.4)] overflow-y-auto">
        <div className="relative flex flex-col md:flex-row rounded-2xl h-full">
            <button onClick={closeAuthModal} className="absolute top-4 right-4 text-gray-400 hover:text-gray-800 dark:hover:text-white z-20 bg-white/30 dark:bg-black/30 rounded-full p-1.5 backdrop-blur-sm">
                <XMarkIcon className="w-6 h-6" />
                <span className="sr-only">Close modal</span>
            </button>

            {/* Branding Panel */}
            <div className={`flex flex-col items-center justify-center w-full md:w-1/2 bg-brand-dark p-6 md:p-12 text-center 
                md:absolute md:top-0 md:h-full 
                transition-[left] duration-700 ease-in-out ${
                mode === 'signup' ? 'md:left-0' : 'md:left-1/2'
            }`}>
                 <div className="scale-110 mb-6 [&_span]:text-white animate-fade-in-up" key={`${mode}-brand`}>
                    <Logo />
                 </div>
                 <h2 className="text-2xl font-serif mt-4 text-white animate-fade-in-up" style={{animationDelay: '0.1s'}} key={`${mode}-h2`}>A Fresh Start for Your Home.</h2>
                 <p className="mt-2 text-brand-light/80 animate-fade-in-up" style={{animationDelay: '0.2s'}} key={`${mode}-p`}>Join our community to enjoy loyalty rewards, faster checkout, and order tracking.</p>
                 <div className="relative w-48 h-48 mt-4 md:w-full md:h-auto md:aspect-square md:mt-8 animate-fade-in-up" style={{animationDelay: '0.3s'}} key={`${mode}-img`}>
                    <img src="https://images.unsplash.com/photo-1620916566398-39f1143ab7be?q=80&w=800&auto=format&fit=crop" alt="Soap & Hope product bottle" className="absolute inset-0 w-full h-full rounded-full border-4 border-brand-secondary object-cover"/>
                 </div>
            </div>

            {/* Form Panel */}
            <div className={`w-full md:w-1/2 p-6 sm:p-8 flex flex-col 
                md:absolute md:top-0 md:h-full 
                transition-[left] duration-700 ease-in-out ${
                mode === 'signup' ? 'md:left-1/2' : 'md:left-0'
            }`}>
                <div className="w-full" key={mode}>
                  {mode === 'forgot' ? (
                      <div className="animate-fade-in-down">
                          <h2 className="text-2xl sm:text-3xl font-serif font-bold text-brand-dark dark:text-brand-light mb-2">
                              Reset Password
                          </h2>
                          <p className="text-gray-600 dark:text-gray-300 mb-6">
                              Enter your email to receive a reset link.
                          </p>
                          {successMessage ? (
                              <div className="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 rounded-md my-4" role="alert">
                                  <p className="font-bold">Check your inbox!</p>
                                  <p>{successMessage}</p>
                              </div>
                          ) : (
                              <form onSubmit={handleForgotPasswordRequest} className="space-y-4">
                                  <div className="relative">
                                      <EnvelopeIcon className="w-5 h-5 text-gray-400 absolute top-1/2 left-4 -translate-y-1/2" />
                                      <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Email Address" required className="w-full pl-11 pr-4 py-3 text-gray-800 dark:text-gray-200 bg-gray-100 dark:bg-gray-700/50 border-2 border-transparent rounded-md focus:outline-none focus:bg-white dark:focus:bg-gray-700 focus:border-brand-secondary transition-colors" />
                                  </div>
                                  {error && <p className="text-red-500 text-sm font-medium">{error}</p>}
                                  <button type="submit" className="w-full bg-brand-primary hover:bg-opacity-80 text-white font-bold py-3 px-6 rounded-md transition-colors transform hover:scale-105">
                                      Send Reset Link
                                  </button>
                              </form>
                          )}
                           <p className="text-center text-sm text-gray-600 dark:text-gray-300 mt-6">
                              <button onClick={() => { setMode('login'); setError(''); setSuccessMessage(''); }} className="font-semibold text-brand-primary dark:text-brand-secondary hover:underline ml-1">
                                  &larr; Back to Login
                              </button>
                          </p>
                      </div>
                  ) : (
                    <>
                      <div className="animate-fade-in-down">
                          <h2 className="text-2xl sm:text-3xl font-serif font-bold text-brand-dark dark:text-brand-light mb-2">
                            {socialSignupProvider ? `Complete Your ${socialSignupProvider.charAt(0).toUpperCase() + socialSignupProvider.slice(1)} Signup` : (mode === 'login' ? 'Welcome Back!' : 'Create an Account')}
                          </h2>
                          <p className="text-gray-600 dark:text-gray-300 mb-6">
                            {socialSignupProvider ? 'Just a few more details to get you started.' : (mode === 'login' ? 'Log in to continue.' : 'Sign up to get started.')}
                          </p>
                      </div>
                      
                      {!socialSignupProvider && (
                        <div className="animate-fade-in-up" style={{animationDelay: '0.1s'}}>
                          <div className="space-y-3">
                              <button onClick={() => handleSocialAuth('google')} className="w-full flex items-center justify-center gap-3 py-3 px-4 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors font-semibold text-gray-700 dark:text-gray-200">
                                  <GoogleIcon className="w-5 h-5" /> Continue with Google
                              </button>
                              <button onClick={() => handleSocialAuth('facebook')} className="w-full flex items-center justify-center gap-3 py-3 px-4 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors font-semibold text-gray-700 dark:text-gray-200">
                                  <FacebookIcon className="w-6 h-6" /> Continue with Facebook
                              </button>
                          </div>
                          
                          <div className="flex items-center my-6">
                            <hr className="flex-grow border-gray-200 dark:border-gray-600" />
                            <span className="mx-4 text-xs font-semibold text-gray-400">OR</span>
                            <hr className="flex-grow border-gray-200 dark:border-gray-600" />
                          </div>
                        </div>
                      )}

                      <form onSubmit={handleAuth} className="space-y-4 animate-fade-in-up" style={{animationDelay: '0.2s'}}>
                        {mode === 'signup' && (
                          <>
                            <div className="relative">
                              <UserIcon className="w-5 h-5 text-gray-400 absolute top-1/2 left-4 -translate-y-1/2" />
                              <input type="text" value={username} onChange={(e) => setUsername(e.target.value)} placeholder="Username" required className="w-full pl-11 pr-4 py-3 text-gray-800 dark:text-gray-200 bg-gray-100 dark:bg-gray-700/50 border-2 border-transparent rounded-md focus:outline-none focus:bg-white dark:focus:bg-gray-700 focus:border-brand-secondary transition-colors" />
                            </div>
                            <div className="relative">
                              <PhoneIcon className="w-5 h-5 text-gray-400 absolute top-1/2 left-4 -translate-y-1/2" />
                              <input type="tel" value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="Phone Number" required className="w-full pl-11 pr-4 py-3 text-gray-800 dark:text-gray-200 bg-gray-100 dark:bg-gray-700/50 border-2 border-transparent rounded-md focus:outline-none focus:bg-white dark:focus:bg-gray-700 focus:border-brand-secondary transition-colors" />
                            </div>
                          </>
                        )}
                        <div className="relative">
                          <EnvelopeIcon className="w-5 h-5 text-gray-400 absolute top-1/2 left-4 -translate-y-1/2" />
                          <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Email Address" required disabled={!!socialSignupProvider} className="w-full pl-11 pr-4 py-3 text-gray-800 dark:text-gray-200 bg-gray-100 dark:bg-gray-700/50 border-2 border-transparent rounded-md focus:outline-none focus:bg-white dark:focus:bg-gray-700 focus:border-brand-secondary transition-colors disabled:bg-gray-200 dark:disabled:bg-gray-700/30 disabled:cursor-not-allowed" />
                        </div>
                        {!socialSignupProvider && (
                          <>
                            <div className="relative">
                              <LockClosedIcon className="w-5 h-5 text-gray-400 absolute top-1/2 left-4 -translate-y-1/2" />
                              <input type={showPassword ? 'text' : 'password'} value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Password" required className="w-full pl-11 pr-12 py-3 text-gray-800 dark:text-gray-200 bg-gray-100 dark:bg-gray-700/50 border-2 border-transparent rounded-md focus:outline-none focus:bg-white dark:focus:bg-gray-700 focus:border-brand-secondary transition-colors" />
                              <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute top-1/2 right-4 -translate-y-1/2 text-gray-500 hover:text-gray-800 dark:hover:text-white">
                                  {showPassword ? <EyeSlashIcon className="w-5 h-5"/> : <EyeIcon className="w-5 h-5"/>}
                              </button>
                            </div>
                            {mode === 'signup' && <PasswordStrengthMeter password={password} />}
                            {mode === 'signup' && (
                                <div className="relative">
                                    <LockClosedIcon className="w-5 h-5 text-gray-400 absolute top-1/2 left-4 -translate-y-1/2" />
                                    <input type={showPassword ? 'text' : 'password'} value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} placeholder="Confirm Password" required className="w-full pl-11 pr-12 py-3 text-gray-800 dark:text-gray-200 bg-gray-100 dark:bg-gray-700/50 border-2 border-transparent rounded-md focus:outline-none focus:bg-white dark:focus:bg-gray-700 focus:border-brand-secondary transition-colors" />
                                </div>
                            )}
                          </>
                        )}
                        
                        {mode === 'login' && !socialSignupProvider && (
                          <div className="flex items-center justify-between text-sm">
                            <label className="flex items-center text-gray-600 dark:text-gray-300 cursor-pointer">
                              <input type="checkbox" checked={rememberMe} onChange={(e) => setRememberMe(e.target.checked)} className="h-4 w-4 rounded border-gray-300 dark:border-gray-500 text-brand-secondary focus:ring-brand-secondary/50" />
                              <span className="ml-2">Remember Me</span>
                            </label>
                            <button type="button" onClick={() => { setMode('forgot'); setError(''); }} className="font-semibold text-brand-primary dark:text-brand-secondary hover:underline">
                              Forgot Password?
                            </button>
                          </div>
                        )}

                        {mode === 'signup' && (
                           <div className="text-sm">
                            <label className="flex items-center text-gray-600 dark:text-gray-300 cursor-pointer">
                              <input type="checkbox" checked={rememberMe} onChange={(e) => setRememberMe(e.target.checked)} className="h-4 w-4 rounded border-gray-300 dark:border-gray-500 text-brand-secondary focus:ring-brand-secondary/50" />
                              <span className="ml-2">Remember Me</span>
                            </label>
                          </div>
                        )}

                        {error && <p className="text-red-500 text-sm font-medium">{error}</p>}
                        
                        <button type="submit" className="w-full bg-brand-primary hover:bg-opacity-80 text-white font-bold py-3 px-6 rounded-md transition-colors transform hover:scale-105">
                          {mode === 'login' ? 'Log In' : 'Create Account'}
                        </button>
                      </form>

                      <div className="animate-fade-in-up" style={{animationDelay: '0.3s'}}>
                          {!socialSignupProvider ? (
                              <p className="text-center text-sm text-gray-600 dark:text-gray-300 mt-6">
                              {mode === 'login' ? "Don't have an account?" : "Already have an account?"}
                              <button onClick={() => { setMode(mode === 'login' ? 'signup' : 'login'); setError(''); }} className="font-semibold text-brand-primary dark:text-brand-secondary hover:underline ml-1">
                                  {mode === 'login' ? 'Sign up' : 'Log in'}
                              </button>
                              </p>
                          ) : (
                              <p className="text-center text-sm text-gray-600 dark:text-gray-300 mt-6">
                                  <button onClick={() => { setSocialSignupProvider(null); setMode('signup'); setError(''); }} className="font-semibold text-brand-primary dark:text-brand-secondary hover:underline ml-1">
                                    &larr; Use another method
                                  </button>
                              </p>
                          )}
                      </div>
                    </>
                  )}
                </div>
            </div>
        </div>
      </div>
    </div>
  );
};

export default AuthModal;