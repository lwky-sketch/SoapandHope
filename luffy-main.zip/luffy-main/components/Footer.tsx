import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';

const LockClosedIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M16.5 10.5V6.75a4.5 4.5 0 00-9 0v3.75m-.75 11.25h10.5a2.25 2.25 0 002.25-2.25v-6.75a2.25 2.25 0 00-2.25-2.25H6.75a2.25 2.25 0 00-2.25 2.25v6.75a2.25 2.25 0 002.25 2.25z" />
  </svg>
);

const ShieldCheckIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75L11.25 15 15 9.75m-3-7.036A11.959 11.959 0 013.598 6 11.99 11.99 0 003 9.749c0 5.592 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.31-.21-2.571-.598-3.751h-.152c-3.196 0-6.1-1.248-8.25-3.286zm0 13.036h.008v.017h-.008v-.017z" />
  </svg>
);

const CreditCardIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 8.25h19.5M2.25 9h19.5m-16.5 5.25h6m-6 2.25h3m-3.75 3h15a2.25 2.25 0 002.25-2.25V6.75A2.25 2.25 0 0019.5 4.5h-15A2.25 2.25 0 002.25 6.75v10.5A2.25 2.25 0 004.5 19.5z" />
  </svg>
);

const FacebookIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg fill="currentColor" viewBox="0 0 24 24" {...props}><path d="M22 12c0-5.52-4.48-10-10-10S2 6.48 2 12c0 4.84 3.44 8.87 8 9.8V15H8v-3h2V9.5C10 7.57 11.57 6 13.5 6H16v3h-2c-.55 0-1 .45-1 1v2h3l-.5 3h-2.5v6.8c4.56-.93 8-4.96 8-9.8z"/></svg>
);

const TwitterIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg fill="currentColor" viewBox="0 0 24 24" {...props}><path d="M22.46 6c-.77.35-1.6.58-2.46.67.88-.53 1.56-1.37 1.88-2.38-.83.49-1.75.85-2.72 1.05C18.37 4.5 17.26 4 16 4c-2.35 0-4.27 1.92-4.27 4.29 0 .34.04.67.11.98-3.56-.18-6.73-1.89-8.84-4.48-.37.63-.58 1.37-.58 2.15 0 1.49.76 2.81 1.91 3.58-.7-.02-1.37-.21-1.95-.5v.03c0 2.08 1.48 3.82 3.44 4.21-.36.1-.74.15-1.14.15-.28 0-.55-.03-.81-.08.55 1.7 2.14 2.94 4.03 2.97-1.47 1.15-3.33 1.84-5.35 1.84-.35 0-.69-.02-1.03-.06 1.9 1.23 4.16 1.94 6.58 1.94 7.9 0 12.23-6.54 12.23-12.23 0-.19 0-.37-.01-.56.84-.6 1.56-1.36 2.14-2.22z"/></svg>
);

const InstagramIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg fill="currentColor" viewBox="0 0 24 24" {...props}><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.85s-.012 3.584-.07 4.85c-.148 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07s-3.584-.012-4.85-.07c-3.252-.148-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.85s.012-3.584.07-4.85c.148-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.85-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948s.014 3.667.072 4.947c.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072s3.667-.014 4.947-.072c4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.947s-.014-3.667-.072-4.947c-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.072-4.948-.072zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.162 6.162 6.162 6.162-2.759 6.162-6.162-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4s1.791-4 4-4 4 1.79 4 4-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/></svg>
);


const Footer: React.FC = () => {
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      const username = email.split('@')[0].replace(/[._-]/g, ' ').replace(/\b\w/g, l => l.toUpperCase());

      const welcomeEmail = `
--------------------------------------------------
TO: ${email}
FROM: hello@soapandhope.com
SUBJECT: Welcome to Soap & Hope!
--------------------------------------------------

Hi ${username} — thanks for signing up!

If you need any help, or have any comments, you can use the Feedback link from most pages on Soap & Hope, you can drop us an email at hello@soapandhope.com or <orders@soapandhope.com >, or you can post on our forums. We'd love to hear from you!

We try to keep email to a minimum, so for the latest Soap & Hope news, check out:

- Our Twitter account, @SoapAndHope
- Our blog

We'll send you a separate email to confirm your email address -- make sure you do that, otherwise we won't be able to do things like reset your password if you forget it.

We hope everything goes well, and once again, if you need help, please don't hesitate to get in touch.

- The Soap & Hope Team

---
Legal Information:
We will provide you with a Soap & Hope account, which allows you to shop on our website, including creating one or more purchased order. This is to remind you that, if you are a Soap & Hope consumer, you may have the right to cancel the contract (that is, to delete your account) within 14 days of concluding the contract. (This right does not apply in certain circumstances, e.g. contracts which are completed.) You must send us a clear statement saying that you wish to cancel via email to hello@soapandhope.com or <orders@soapandhope.com >. For full details, please see our terms and conditions. This is separate from our (actually more generous) 30-day no-questions-asked money-back guarantee.
`;
      console.log("--- SIMULATED WELCOME EMAIL ---");
      console.log(welcomeEmail.trim());

      setSubscribed(true);
      setEmail('');
      setTimeout(() => setSubscribed(false), 5000);
    }
  };
  
  return (
    <footer id="footer" className="bg-brand-dark text-brand-light">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          
          <div className="md:col-span-2">
            <h3 className="text-xl font-serif font-bold mb-4 text-white">Get 5% Off Your First Order</h3>
            <p className="text-gray-400 mb-4">Join our newsletter for exclusive deals, cleaning tips, and new product announcements.</p>
            {subscribed ? (
              <p className="text-brand-secondary font-semibold">Thank you for subscribing! Check the developer console for your welcome email.</p>
            ) : (
              <form onSubmit={handleSubscribe} className="flex flex-col sm:flex-row gap-2">
                <input 
                  type="email" 
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Enter your email"
                  className="w-full px-4 py-2 text-gray-800 bg-brand-light dark:bg-gray-700 dark:text-gray-200 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-brand-primary"
                  required
                />
                <button type="submit" className="bg-brand-primary hover:bg-opacity-80 text-white font-bold py-2 px-6 rounded-md transition-colors">
                  Subscribe
                </button>
              </form>
            )}
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4 text-white">Shop</h3>
            <ul className="space-y-2">
              <li><NavLink to="/products?category=laundry" className="text-gray-400 hover:text-white transition-colors">Laundry</NavLink></li>
              <li><NavLink to="/products?category=hand" className="text-gray-400 hover:text-white transition-colors">Hand Soap</NavLink></li>
              <li><NavLink to="/products?category=dish" className="text-gray-400 hover:text-white transition-colors">Dishwashing</NavLink></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4 text-white">Company</h3>
            <ul className="space-y-2">
              <li><NavLink to="/about" className="text-gray-400 hover:text-white transition-colors">About Us</NavLink></li>
              <li><NavLink to="/blog" className="text-gray-400 hover:text-white transition-colors">Blog</NavLink></li>
              <li><NavLink to="/wishlist" className="text-gray-400 hover:text-white transition-colors">Wishlist</NavLink></li>
              <li><NavLink to="/contact" className="text-gray-400 hover:text-white transition-colors">Contact</NavLink></li>
              <li><NavLink to="/return-policy" className="text-gray-400 hover:text-white transition-colors">Return Policy</NavLink></li>
            </ul>
            <div className="flex items-center space-x-4 mt-6">
                <a href="https://facebook.com" target="_blank" rel="noopener noreferrer" aria-label="Facebook page" className="text-gray-400 hover:text-white transition-colors">
                  <FacebookIcon className="h-6 w-6" />
                </a>
                <a href="https://twitter.com" target="_blank" rel="noopener noreferrer" aria-label="Twitter page" className="text-gray-400 hover:text-white transition-colors">
                  <TwitterIcon className="h-6 w-6" />
                </a>
                <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" aria-label="Instagram page" className="text-gray-400 hover:text-white transition-colors">
                  <InstagramIcon className="h-6 w-6" />
                </a>
            </div>
          </div>

        </div>
        <div className="mt-12 border-t border-gray-700 pt-8">
            <div className="flex flex-wrap items-center justify-center gap-x-8 gap-y-4 text-gray-400">
                <div className="flex items-center gap-2 text-sm">
                    <LockClosedIcon className="w-5 h-5" />
                    <span>SSL Secure Connection</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                    <ShieldCheckIcon className="w-5 h-5" />
                    <span>100% Money-Back Guarantee</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                    <CreditCardIcon className="w-5 h-5" />
                    <span>Secure Payments</span>
                </div>
            </div>
            <div className="mt-8 text-center text-gray-500">
                <p>&copy; {new Date().getFullYear()} Soap & Hope. All Rights Reserved.</p>
            </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;