import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';

interface User {
  email: string;
  username: string;
  phone: string;
}

interface AuthContextType {
  isAuthenticated: boolean;
  currentUser: User | null;
  login: (email: string, rememberMe: boolean) => boolean;
  signup: (email: string, username: string, phone: string, rememberMe: boolean) => string;
  logout: () => void;
  isAuthModalOpen: boolean;
  openAuthModal: () => void;
  closeAuthModal: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

interface AuthProviderProps {
  children: ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);

  useEffect(() => {
    try {
      const storedUserJSON = localStorage.getItem('currentUser') || sessionStorage.getItem('currentUser');
      if (storedUserJSON) {
        setCurrentUser(JSON.parse(storedUserJSON));
      }
    } catch (error) {
      console.error("Error reading current user from storage", error);
    }
  }, []);
  
  const isAuthenticated = !!currentUser;

  const login = (email: string, rememberMe: boolean): boolean => {
    try {
      const storedUsers = localStorage.getItem('users');
      const users: User[] = storedUsers ? JSON.parse(storedUsers) : [];
      const foundUser = users.find(user => user.email.toLowerCase() === email.toLowerCase());

      if (foundUser) {
        const storage = rememberMe ? localStorage : sessionStorage;
        storage.setItem('currentUser', JSON.stringify(foundUser));
        setCurrentUser(foundUser);
        closeAuthModal();
        return true;
      }
      return false;
    } catch (error)      {
      console.error("Error during login", error);
      return false;
    }
  };

  const signup = (email: string, username: string, phone: string, rememberMe: boolean): string => {
    try {
      const storedUsers = localStorage.getItem('users');
      const users: User[] = storedUsers ? JSON.parse(storedUsers) : [];
      
      if (users.some(user => user.email.toLowerCase() === email.toLowerCase())) {
        return "email";
      }
      if (users.some(user => user.username.toLowerCase() === username.toLowerCase())) {
        return "username";
      }
      if (users.some(user => user.phone === phone)) {
        return "phone";
      }

      const newUser: User = { email, username, phone };
      const newUsers = [...users, newUser];
      localStorage.setItem('users', JSON.stringify(newUsers));
      
      const storage = rememberMe ? localStorage : sessionStorage;
      storage.setItem('currentUser', JSON.stringify(newUser));
      setCurrentUser(newUser);
      closeAuthModal();
      return "success";
    } catch (error) {
      console.error("Error during signup", error);
      return "error";
    }
  };

  const logout = () => {
    try {
      localStorage.removeItem('currentUser');
      sessionStorage.removeItem('currentUser');
      setCurrentUser(null);
    } catch (error) {
      console.error("Error during logout", error);
    }
  };
  
  const openAuthModal = () => setIsAuthModalOpen(true);
  const closeAuthModal = () => setIsAuthModalOpen(false);

  const value = {
    isAuthenticated,
    currentUser,
    login,
    signup,
    logout,
    isAuthModalOpen,
    openAuthModal,
    closeAuthModal
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};
