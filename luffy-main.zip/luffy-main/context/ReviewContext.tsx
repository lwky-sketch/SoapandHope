import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Review } from '../types';
import { PRODUCTS } from '../constants';

// The new review data from the form won't have id or date yet.
export type NewReviewData = {
  productId: number;
  author: string;
  rating: number;
  comment: string;
}

// Augment the Review type internally for our state
type ProductReview = {
  id: number;
  author: string;
  rating: number;
  comment: string;
  date: string;
  productId: number;
};

interface ReviewContextType {
  getReviewsByProductId: (productId: number) => ProductReview[];
  addReview: (reviewData: NewReviewData) => void;
  productAverageRating: (productId: number) => number;
}

const ReviewContext = createContext<ReviewContextType | undefined>(undefined);

export const useReviews = () => {
  const context = useContext(ReviewContext);
  if (!context) {
    throw new Error('useReviews must be used within a ReviewProvider');
  }
  return context;
};

const initializeReviews = (): ProductReview[] => {
  try {
    const localData = localStorage.getItem('productReviews');
    if (localData) {
      return JSON.parse(localData);
    }
  } catch (error) {
    console.error('Error reading reviews from localStorage', error);
  }

  // If no local data, seed from constants.ts
  const initialReviews: ProductReview[] = [];
  PRODUCTS.forEach(product => {
    product.reviews.forEach(review => {
      // Add productId to each review
      initialReviews.push({
        id: review.id,
        author: review.author,
        rating: review.rating,
        comment: review.comment,
        date: review.date,
        productId: product.id
      });
    });
  });

  try {
    localStorage.setItem('productReviews', JSON.stringify(initialReviews));
  } catch (error) {
    console.error('Error saving initial reviews to localStorage', error);
  }

  return initialReviews;
}


export const ReviewProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [reviews, setReviews] = useState<ProductReview[]>(initializeReviews);

  useEffect(() => {
    try {
      localStorage.setItem('productReviews', JSON.stringify(reviews));
    } catch (error) {
      console.error('Error saving reviews to localStorage', error);
    }
  }, [reviews]);

  const getReviewsByProductId = (productId: number) => {
    return reviews.filter(review => review.productId === productId).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  };

  const addReview = (reviewData: NewReviewData) => {
    const newReview: ProductReview = {
      ...reviewData,
      id: Date.now(),
      date: new Date().toISOString().split('T')[0], // YYYY-MM-DD
    };
    setReviews(prevReviews => [newReview, ...prevReviews]);
  };

  const productAverageRating = (productId: number) => {
      const productReviews = getReviewsByProductId(productId);
      if (productReviews.length === 0) return 0;
      const totalRating = productReviews.reduce((acc, review) => acc + review.rating, 0);
      const average = totalRating / productReviews.length;
      return Math.round(average * 10) / 10; // Round to one decimal place
  };

  const value = { getReviewsByProductId, addReview, productAverageRating };

  return <ReviewContext.Provider value={value}>{children}</ReviewContext.Provider>;
};