import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Order } from '../types';
import { MOCK_ORDERS } from '../constants';
import { useAuth } from './AuthContext';

interface OrderContextType {
  orders: Order[];
}

const OrderContext = createContext<OrderContextType | undefined>(undefined);

export const useOrder = () => {
  const context = useContext(OrderContext);
  if (!context) {
    throw new Error('useOrder must be used within an OrderProvider');
  }
  return context;
};

export const OrderProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const { currentUser } = useAuth();
  const [orders, setOrders] = useState<Order[]>([]);

  useEffect(() => {
    if (currentUser) {
      const userOrders = MOCK_ORDERS.filter(order => order.userEmail === currentUser.email)
        .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
      setOrders(userOrders);
    } else {
      setOrders([]);
    }
  }, [currentUser]);

  const value = { orders };

  return <OrderContext.Provider value={value}>{children}</OrderContext.Provider>;
};
