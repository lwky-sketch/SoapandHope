import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Product, CartItem } from '../types';

interface CartContextType {
  cartItems: CartItem[];
  addToCart: (product: Product, quantity?: number) => void;
  removeFromCart: (productId: number) => void;
  updateQuantity: (productId: number, quantity: number) => void;
  clearCart: () => void;
  cartCount: number;
  cartTotal: number;
  isCartOpen: boolean;
  toggleCart: () => void;
  purchaseCount: number;
  completePurchase: () => void;
  isFreebieEarned: boolean;
  promoDiscount: number;
  finalTotal: number;
  appliedPromoCode: string;
  promoError: string;
  applyPromoCode: (code: string) => void;
  removePromoCode: () => void;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

export const useCart = () => {
  const context = useContext(CartContext);
  if (!context) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
};

interface CartProviderProps {
  children: ReactNode;
}

export const CartProvider: React.FC<CartProviderProps> = ({ children }) => {
  const [cartItems, setCartItems] = useState<CartItem[]>(() => {
    try {
      const localData = localStorage.getItem('cartItems');
      return localData ? JSON.parse(localData) : [];
    } catch (error) {
      return [];
    }
  });

  const [isCartOpen, setIsCartOpen] = useState(false);

  const [purchaseCount, setPurchaseCount] = useState<number>(() => {
    try {
      const localData = localStorage.getItem('purchaseCount');
      return localData ? parseInt(localData, 10) : 0;
    } catch (error) {
      return 0;
    }
  });
  
  const [appliedPromoCode, setAppliedPromoCode] = useState<string>('');
  const [promoError, setPromoError] = useState<string>('');
  
  const isFreebieEarned = purchaseCount >= 6;

  useEffect(() => {
    localStorage.setItem('cartItems', JSON.stringify(cartItems));
  }, [cartItems]);

  useEffect(() => {
    localStorage.setItem('purchaseCount', purchaseCount.toString());
  }, [purchaseCount]);

  const applyPromoCode = (code: string) => {
    if (code.trim().toUpperCase() === 'NI4196') {
      setAppliedPromoCode('NI4196');
      setPromoError('');
    } else {
      setAppliedPromoCode('');
      setPromoError('Invalid or expired promo code.');
    }
  };

  const removePromoCode = () => {
    setAppliedPromoCode('');
    setPromoError('');
  };

  const addToCart = (product: Product, quantity: number = 1) => {
    setCartItems(prevItems => {
      const existingItem = prevItems.find(item => item.id === product.id);
      if (existingItem) {
        return prevItems.map(item =>
          item.id === product.id ? { ...item, quantity: item.quantity + quantity } : item
        );
      }
      return [...prevItems, { ...product, quantity }];
    });
    setIsCartOpen(true);
  };

  const removeFromCart = (productId: number) => {
    setCartItems(prevItems => prevItems.filter(item => item.id !== productId));
  };

  const updateQuantity = (productId: number, quantity: number) => {
    if (quantity < 1) {
      removeFromCart(productId);
    } else {
      setCartItems(prevItems =>
        prevItems.map(item =>
          item.id === productId ? { ...item, quantity } : item
        )
      );
    }
  };
  
  const clearCart = () => {
    setCartItems([]);
    removePromoCode();
  };

  const completePurchase = () => {
    setPurchaseCount(prev => (prev + 1) % 7);
    clearCart();
  }

  const cartCount = cartItems.reduce((acc, item) => acc + item.quantity, 0);
  
  let cartTotal = cartItems.reduce((acc, item) => acc + item.price * item.quantity, 0);

  if (isFreebieEarned && cartItems.length > 0) {
    const mostExpensiveItem = [...cartItems].sort((a, b) => b.price - a.price)[0];
    cartTotal -= mostExpensiveItem.price;
  }

  let promoDiscount = 0;
  if (appliedPromoCode === 'NI4196' && cartTotal > 0) {
      promoDiscount = cartTotal * 0.067;
  }

  const finalTotal = cartTotal - promoDiscount;


  const toggleCart = () => setIsCartOpen(!isCartOpen);

  const value = {
    cartItems,
    addToCart,
    removeFromCart,
    updateQuantity,
    clearCart,
    cartCount,
    cartTotal,
    isCartOpen,
    toggleCart,
    purchaseCount,
    completePurchase,
    isFreebieEarned,
    promoDiscount,
    finalTotal,
    appliedPromoCode,
    promoError,
    applyPromoCode,
    removePromoCode,
  };

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
};
