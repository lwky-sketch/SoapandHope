import { Product, Category, Review, HeroSlide, BlogPost, Order } from './types';

export const CATEGORIES: Category[] = [
  { id: 'laundry', name: 'Laundry Detergents', image: 'https://picsum.photos/seed/laundry/400/400' },
  { id: 'hand', name: 'Hand Soaps', image: 'https://picsum.photos/seed/handsoap/400/400' },
  { id: 'dish', name: 'Dishwashing Liquids', image: 'https://picsum.photos/seed/dishwash/400/400' },
];

export const REVIEWS: Review[] = [
    { id: 1, author: 'Jane D.', rating: 5, comment: "Absolutely love this laundry detergent! My clothes have never smelled better.", date: '2023-10-15' },
    { id: 2, author: 'Mike S.', rating: 4, comment: "Great scent and it cleans really well. The bottle is huge and lasts a long time. Will buy again!", date: '2023-10-12' },
    { id: 3, author: 'Emily R.', rating: 5, comment: "I'm on my 5th purchase! The loyalty program is a great bonus.", date: '2023-10-10' },
    { id: 4, author: 'Sarah K.', rating: 5, comment: "My hands feel so soft after using this. The lemon scent is very natural and not overpowering. A must-have for every kitchen!", date: '2023-10-20' },
    { id: 5, author: 'David L.', rating: 4, comment: "This dish soap is fantastic. It tackles greasy pans with ease. I just wish it came in a bigger bottle.", date: '2023-10-18' },
    { id: 6, author: 'Jessica M.', rating: 5, comment: "The lavender scent is heavenly. It's so relaxing to wash my hands with this soap. It doesn't dry out my skin either.", date: '2023-10-25' },
    { id: 7, author: 'Ben C.', rating: 5, comment: "A staple in our home. We buy it in bulk. Great value for a high-quality hand soap.", date: '2023-10-22' },
    { id: 8, author: 'Laura T.', rating: 4, comment: "This fabric softener is a game changer. My towels have never been softer. The linen scent is subtle and clean.", date: '2023-10-19' },
    { id: 9, author: 'Kevin H.', rating: 5, comment: "Huge value! This lasts our family of five for months. It works just as well as the more expensive brands.", date: '2023-10-17' },
    { id: 10, author: 'Chloe G.', rating: 5, comment: "Perfect for my purse. The minty smell is so refreshing and it doesn't leave my hands sticky like other sanitizers.", date: '2023-10-28' },
    { id: 11, author: 'Daniel W.', rating: 4, comment: "Works great and smells clean. The eucalyptus is a nice touch. I keep one in my car and one at my desk.", date: '2023-10-26' },
    { id: 12, author: 'Olivia P.', rating: 5, comment: "We're a family with sensitive skin and this detergent has been a lifesaver. No irritations, just clean, fresh clothes.", date: '2023-10-29' }
];

export const PRODUCTS: Product[] = [
  {
    id: 1,
    name: '5 liters liquid laundry soap',
    category: 'laundry',
    price: 470,
    description: 'A powerful, plant-based laundry detergent that leaves your clothes fresh and clean. Tough on stains, gentle on fabrics.',
    images: ['https://picsum.photos/seed/ocean1/800/800', 'https://picsum.photos/seed/ocean2/800/800', 'https://picsum.photos/seed/ocean3/800/800'],
    scent: 'Fresh',
    size: '5L',
    ingredients: ['Plant-derived surfactants', 'Natural enzymes', 'Essential oils', 'Water'],
    rating: 4.8,
    reviewCount: 125,
    reviews: [REVIEWS[0], REVIEWS[11]]
  },
  {
    id: 3,
    name: 'Sparkling unperfumed Dish Liquid soap',
    category: 'dish',
    price: 120,
    description: 'Cuts through grease and grime effortlessly. This biodegradable, unperfumed dishwashing liquid is tough on messes but gentle on your hands and the environment.',
    images: ['https://picsum.photos/seed/lemon1/800/800'],
    scent: 'Unperfumed',
    size: '750ml',
    ingredients: ['Anionic surfactants', 'Amphoteric surfactants', 'Water'],
    rating: 4.7,
    reviewCount: 150,
    reviews: [REVIEWS[3], REVIEWS[4]]
  },
  {
    id: 4,
    name: '1 Liter Lavender Soap',
    category: 'hand',
    price: 100,
    description: 'Unwind with the calming scent of lavender. Our liquid soap creates a rich lather that cleanses and nourishes the skin.',
    images: ['https://picsum.photos/seed/lavender1/800/800', 'https://picsum.photos/seed/lavender2/800/800'],
    scent: 'Lavender',
    size: '1L',
    ingredients: ['Saponified olive oil', 'Coconut oil', 'Shea butter', 'Lavender essential oil'],
    rating: 4.9,
    reviewCount: 210,
    reviews: [REVIEWS[5], REVIEWS[6]]
  },
  {
    id: 5,
    name: '10 liters of laundry Soap',
    category: 'laundry',
    price: 960,
    description: 'A large container of our effective laundry soap for ultimate softness and a long-lasting fresh linen scent. Reduces static and makes ironing easier.',
    images: ['https://picsum.photos/seed/linen1/800/800'],
    scent: 'Linen',
    size: '10L',
    ingredients: ['Cationic surfactants', 'Fragrance', 'Water'],
    rating: 4.5,
    reviewCount: 88,
    reviews: [REVIEWS[7], REVIEWS[8]]
  },
  {
    id: 6,
    name: '125ml Mint Hand Sanitizer',
    category: 'hand',
    price: 120,
    description: 'A refreshing and invigorating hand sanitizer. The blend of eucalyptus and mint essential oils provides a clean feeling on the go.',
    images: ['https://picsum.photos/seed/mint1/800/800'],
    scent: 'Mint',
    size: '125ml',
    ingredients: ['Alcohol', 'Glycerin', 'Eucalyptus globulus leaf oil', 'Mentha piperita (Peppermint) oil', 'Water'],
    rating: 4.8,
    reviewCount: 112,
    reviews: [REVIEWS[9], REVIEWS[10]]
  }
];

export const HERO_SLIDES: HeroSlide[] = [
  {
    id: 1,
    title: 'Purely Clean, Naturally Fresh',
    subtitle: 'Premium cleaning products that care for your home while rewarding your trust. Join thousands of families who choose Soap & Hope for quality and loyalty.',
    image: 'https://picsum.photos/seed/hero1/1920/1080',
    buttonText: 'Shop Laundry',
    buttonLink: '/products?category=laundry'
  },
  {
    id: 2,
    title: 'The 7th Is On Us!',
    subtitle: 'Join our loyalty program and get your 7th product absolutely free. Start saving today!',
    image: 'https://picsum.photos/seed/hero2/1920/1080',
    buttonText: 'Learn More',
    buttonLink: '/loyalty'
  },
  {
    id: 3,
    title: '5% Off Your First Order',
    subtitle: 'Sign up for our newsletter and enjoy an exclusive discount on your first purchase.',
    image: 'https://picsum.photos/seed/hero3/1920/1080',
    buttonText: 'Sign Up Now',
    buttonLink: '#footer'
  }
];

export const BLOG_CATEGORIES = ['Eco-Friendly', 'DIY', 'Health & Wellness', 'Tips & Tricks'];

export const BLOG_POSTS: BlogPost[] = [
  {
    id: 1,
    title: "5 Eco-Friendly Laundry Tips That Save Money & The Planet",
    author: "Jane Austin",
    date: "October 26, 2023",
    image: "https://picsum.photos/seed/blog1/1200/800",
    summary: "Doing laundry is a household necessity, but it can have a significant environmental impact. From water usage to energy consumption and chemical detergents, the traditional way of washing clothes isn't always green. The good news is that with a few simple changes, you can make your laundry routine more eco-friendly...",
    content: [
      "Doing laundry is a household necessity, but it can have a significant environmental impact. From water usage to energy consumption and chemical detergents, the traditional way of washing clothes isn't always green. The good news is that with a few simple changes, you can make your laundry routine more eco-friendly, save money on utility bills, and extend the life of your clothes.",
      "1. Wash with Cold Water: About 90% of the energy your washing machine uses goes towards heating the water. By switching to cold water, you can drastically reduce your energy consumption. Modern detergents are formulated to work just as effectively in cold water, so you won't be sacrificing cleanliness.",
      "2. Use a Green Detergent: Conventional detergents can contain phosphates and other chemicals that are harmful to aquatic ecosystems. Look for plant-based, biodegradable detergents like ours. They are gentle on the environment and your skin.",
      "3. Ditch the Dryer: Air-drying your clothes is the most energy-efficient method. If you have outdoor space, a clothesline is fantastic. If not, an indoor drying rack works just as well. Your clothes will last longer, and you'll save a significant amount on your electricity bill.",
      "4. Wash Full Loads: Make the most of every cycle by waiting until you have a full load. This conserves both water and energy. If you must wash a smaller load, be sure to adjust the water level settings on your machine accordingly.",
      "5. Make Your Own Fabric Softener: Instead of commercial fabric softeners that contain synthetic fragrances and chemicals, try using a half-cup of white vinegar in the rinse cycle. It acts as a natural softener and helps remove any lingering detergent residue. Don't worry, the vinegar smell will dissipate as the clothes dry!"
    ],
    tags: ['Eco-Friendly', 'Tips & Tricks'],
  },
  {
    id: 2,
    title: "The Surprising Benefits of Switching to Natural Bar Soap",
    author: "Mark Evans",
    date: "October 22, 2023",
    image: "https://picsum.photos/seed/blog2/1200/800",
    summary: "In a world of liquid body washes and foaming hand soaps, the humble bar soap has been making a major comeback. And for good reason! Natural bar soaps, especially those made with high-quality oils and butters, offer a wealth of benefits for your skin, your wallet, and the planet...",
    content: [
      "In a world of liquid body washes and foaming hand soaps, the humble bar soap has been making a major comeback. And for good reason! Natural bar soaps, especially those made with high-quality oils and butters, offer a wealth of benefits for your skin, your wallet, and the planet.",
      "One of the biggest advantages is the ingredient list. Our Lavender Fields Bar Soap, for instance, is made with saponified olive oil, coconut oil, and shea butter. These ingredients are incredibly moisturizing and nourishing for the skin, unlike many commercial body washes that can contain stripping sulfates and synthetic fragrances.",
      "Natural bar soaps also retain glycerin, a natural byproduct of the soap-making process. Glycerin is a humectant, meaning it draws moisture from the air to your skin, keeping it hydrated and soft long after you've stepped out of the shower.",
      "From an environmental perspective, bar soaps are a clear winner. They typically come with minimal, often paper-based, packaging, drastically reducing plastic waste compared to their liquid counterparts. They are also more concentrated, meaning a single bar lasts much longer, reducing the carbon footprint associated with transportation.",
      "So next time you're stocking up on toiletries, consider reaching for a natural bar soap. It's a small change that can make a big difference for your skin and the environment."
    ],
    tags: ['Health & Wellness', 'Eco-Friendly'],
  },
  {
    id: 3,
    title: "DIY Home Cleaning: A Simple Recipe for an All-Purpose Cleaner",
    author: "Sarah Chen",
    date: "October 18, 2023",
    image: "https://picsum.photos/seed/blog3/1200/800",
    summary: "Looking for a powerful, non-toxic way to clean your home? Making your own all-purpose cleaner is easier than you think. This simple DIY recipe uses just a few household ingredients and can be used on countertops, floors, and other surfaces...",
    content: [
      "Looking for a powerful, non-toxic way to clean your home? Making your own all-purpose cleaner is easier than you think. This simple DIY recipe uses just a few household ingredients and can be used on countertops, floors, and other surfaces (just be sure to spot-test on sensitive materials first!).",
      "What You'll Need: A clean spray bottle, 1 part white vinegar, 1 part water, a few drops of our Sparkling Lemon Dish Liquid, and 10-15 drops of your favorite essential oil (optional, for scent).",
      "Instructions: Simply combine all the ingredients in the spray bottle and shake well. The vinegar is a natural disinfectant and deodorizer, while the dish soap helps cut through grease and grime. The essential oil adds a pleasant, natural fragrance.",
      "This all-purpose cleaner is perfect for everyday messes and is a fantastic alternative to store-bought cleaners that can contain harsh chemicals. It's safe, effective, and incredibly affordable. Happy cleaning!"
    ],
    tags: ['DIY', 'Tips & Tricks'],
  },
  {
    id: 4,
    title: "How to Read Cleaning Product Labels Like a Pro",
    author: "Alex Johnson",
    date: "October 15, 2023",
    image: "https://picsum.photos/seed/blog4/1200/800",
    summary: "Decode the jargon on cleaning product labels. We'll guide you through what to look for and what to avoid to make healthier choices for your family and the environment.",
    content: [
      "Navigating the cleaning aisle can be overwhelming. Bright labels and bold claims can make it difficult to know what you're really bringing into your home. Understanding how to read labels is the first step towards making informed, healthier choices.",
      "Look for 'Signal Words': Words like 'Danger,' 'Warning,' or 'Caution' indicate the product's potential hazard level. 'Danger' is the most severe.",
      "Scan for Certifications: Look for trusted third-party certifications like the Leaping Bunny (cruelty-free) or EPA's Safer Choice, which indicates the product's ingredients are safer for human health and the environment.",
      "Avoid Vague Terms: Be wary of terms like 'natural' or 'eco-friendly' without specific substantiation. These terms are not regulated and can be misleading (a practice known as 'greenwashing').",
      "Check the Ingredient List: While not always fully disclosed, look for what is listed. Avoid products with phosphates, chlorine bleach, and ammonia, especially if you have children or pets.",
      "By becoming a savvy label-reader, you empower yourself to create a safer, cleaner home environment."
    ],
    tags: ['Tips & Tricks', 'Health & Wellness'],
  },
  {
    id: 5,
    title: "Creating a Relaxing Atmosphere with Natural Scents",
    author: "Maria Garcia",
    date: "October 10, 2023",
    image: "https://picsum.photos/seed/blog5/1200/800",
    summary: "Transform your home into a sanctuary using the power of essential oils and natural fragrances. Discover simple DIY methods to create a calming and inviting space.",
    content: [
      "The scent of your home has a profound impact on your mood and well-being. Instead of synthetic air fresheners, which can contain volatile organic compounds (VOCs), turn to nature for a healthier and more authentic aromatic experience.",
      "Simmer Pots: A simple and wonderful way to fill your home with fragrance. In a small pot of water, combine ingredients like citrus peels (orange, lemon), spices (cinnamon sticks, cloves), and herbs (rosemary). Let it simmer on low heat, adding water as needed.",
      "Essential Oil Diffusers: An ultrasonic diffuser is an excellent investment. Add a few drops of lavender for relaxation, peppermint for focus, or eucalyptus for a fresh, clean scent.",
      "DIY Linen Spray: In a spray bottle, combine distilled water, a splash of witch hazel or vodka (to help the oil and water mix), and 10-15 drops of your favorite essential oil like chamomile or cedarwood. Lightly mist on pillows and linens for a calming effect.",
      "By using natural scents, you're not just making your home smell good—you're creating a healthier, more harmonious living environment."
    ],
    tags: ['DIY', 'Health & Wellness'],
  }
];

export const MOCK_ORDERS: Order[] = [
    {
      id: 'SH-1004',
      date: '2023-10-30',
      status: 'Processing',
      userEmail: 'jane.doe@example.com',
      items: [
          { ...(PRODUCTS.find(p => p.id === 6)!), quantity: 1 },
          { ...(PRODUCTS.find(p => p.id === 3)!), quantity: 1 },
      ],
      shippingAddress: {
          name: 'Jane Doe',
          address: '456 Park Road',
          city: 'Nairobi',
          postalCode: '00200',
      },
      subtotal: 240,
      shippingCost: 150,
      tax: 38.4,
      discount: 0,
      total: 428.4,
      paymentMethod: 'M-Pesa',
      estimatedDelivery: 'November 3, 2023',
      statusUpdates: {
          processingDate: '2023-10-30',
      }
    },
    {
      id: 'SH-1003',
      date: '2023-10-28',
      status: 'Shipped',
      userEmail: 'jane.doe@example.com',
      items: [
        { ...(PRODUCTS.find(p => p.id === 5)!), quantity: 1 },
      ],
      shippingAddress: {
        name: 'Jane Doe',
        address: '123 Green Way',
        city: 'Nairobi',
        postalCode: '00100',
      },
      subtotal: 960,
      shippingCost: 200,
      tax: 153.6,
      discount: 0,
      total: 1313.6,
      paymentMethod: 'M-Pesa',
      trackingNumber: 'SNX987654321',
      estimatedDelivery: 'October 31, 2023',
      statusUpdates: {
          processingDate: '2023-10-28',
          shippedDate: '2023-10-29',
      }
    },
    {
      id: 'SH-1002',
      date: '2023-10-24',
      status: 'Delivered',
      userEmail: 'jane.doe@example.com',
      items: [
        { ...(PRODUCTS.find(p => p.id === 1)!), quantity: 1 },
        { ...(PRODUCTS.find(p => p.id === 4)!), quantity: 2 },
      ],
      shippingAddress: {
        name: 'Jane Doe',
        address: '123 Green Way',
        city: 'Nairobi',
        postalCode: '00100',
      },
      subtotal: 670,
      shippingCost: 150,
      tax: 107.2,
      discount: 0,
      total: 927.2,
      paymentMethod: 'M-Pesa',
      trackingNumber: 'SNX123456789',
      statusUpdates: {
          processingDate: '2023-10-24',
          shippedDate: '2023-10-25',
          deliveredDate: '2023-10-26',
      }
    },
  ];