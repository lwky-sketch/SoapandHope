import React from 'react';

// FIX: The original file contained invalid TSX. It has been converted into a valid React functional component.
// This includes changing 'class' to 'className', ensuring all data attributes are passed as strings,
// and fixing the multi-line 'data-url' attribute.
const LoginForm = () => {
  return (
    <div
      className="vsme_d"
      data-title="Webinar Registration Form"
      data-url="g7ddqxx0-untitled-project?fullPage=true"
      data-domain="forms"
      data-full-page="true"
      data-min-height="100vh"
      data-form-id="1333190"
    ></div>
  );
};

export default LoginForm;
