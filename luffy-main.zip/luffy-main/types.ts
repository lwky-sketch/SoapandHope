
export interface Product {
  id: number;
  name: string;
  category: string;
  price: number;
  description: string;
  images: string[];
  scent: string;
  size: string;
  ingredients: string[];
  rating: number;
  reviewCount: number;
  reviews: Review[];
}

export interface CartItem extends Product {
  quantity: number;
}

export interface Review {
  id: number;
  author: string;
  rating: number;
  comment: string;
  date: string;
}

export interface Category {
  id: string;
  name: string;
  image: string;
}

export interface HeroSlide {
  id: number;
  title: string;
  subtitle: string;
  image: string;
  buttonText: string;
  buttonLink: string;
}

export interface BlogPost {
  id: number;
  title: string;
  author: string;
  date: string;
  image: string;
  summary: string;
  content: string[];
  tags: string[];
}

export interface Order {
  id: string;
  date: string;
  status: 'Processing' | 'Shipped' | 'Delivered';
  items: CartItem[];
  shippingAddress: {
    name: string;
    address: string;
    city: string;
    postalCode: string;
  };
  userEmail: string;
  subtotal: number;
  shippingCost: number;
  tax: number;
  discount: number;
  total: number;
  paymentMethod: string;
  trackingNumber?: string;
  estimatedDelivery?: string;
  statusUpdates: {
    processingDate: string;
    shippedDate?: string;
    deliveredDate?: string;
  };
}
